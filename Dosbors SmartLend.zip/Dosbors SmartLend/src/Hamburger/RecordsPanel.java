package Hamburger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class RecordsPanel extends javax.swing.JPanel {
    private Connection connection;
    private DefaultTableModel tableModel;

    public RecordsPanel() {
        initComponents();
        connectToDatabase();
        initializeTableModel();
        loadLoanRecords();
    }

    private void connectToDatabase() {
        try {
            // Update these credentials to match your database
            String url = "jdbc:mysql://localhost:3306/java_user_database";
            String username = "root"; // Your MySQL username
            String password = ""; // Your MySQL password
            
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(this, "Error connecting to database: " + e.getMessage(), 
                    "Database Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }

    private void initializeTableModel() {
        tableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table cells non-editable
            }
        };
        
        // Add columns to the table model
        tableModel.addColumn("Reference No");
        tableModel.addColumn("Borrower");
        tableModel.addColumn("Loan Type");
        tableModel.addColumn("Amount");
        tableModel.addColumn("Status");
        tableModel.addColumn("Date Created");
        
        jTable1.setModel(tableModel);
    }

    private void loadLoanRecords() {
        try {
            // Clear existing data
            tableModel.setRowCount(0);
            
            // SQL query to join loan_list with borrowers and loan_types
            String sql = "SELECT l.ref_no, CONCAT(b.firstname, ' ', b.lastname) as borrower_name, " +
                         "lt.type_name as loan_type, l.amount, " +
                         "CASE l.status " +
                         "WHEN 0 THEN 'Request' " +
                         "WHEN 1 THEN 'Confirmed' " +
                         "WHEN 2 THEN 'Released' " +
                         "WHEN 3 THEN 'Completed' " +
                         "WHEN 4 THEN 'Denied' " +
                         "END as status, " +
                         "l.date_created " +
                         "FROM loan_list l " +
                         "JOIN borrowers b ON l.borrower_id = b.id " +
                         "JOIN loan_types lt ON l.loan_type_id = lt.id " +
                         "ORDER BY l.date_created DESC";
            
            PreparedStatement pst = connection.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            while (rs.next()) {
                Object[] row = {
                    rs.getString("ref_no"),
                    rs.getString("borrower_name"),
                    rs.getString("loan_type"),
                    rs.getDouble("amount"),
                    rs.getString("status"),
                    rs.getTimestamp("date_created")
                };
                tableModel.addRow(row);
            }
            
            rs.close();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(this, "Error loading records: " + e.getMessage(), 
                    "Database Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        jPanel1.setBackground(new java.awt.Color(0, 255, 204));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Records");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(16, 16, 16))
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Name", "Lend Details", "Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 542, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 424, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents
 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
