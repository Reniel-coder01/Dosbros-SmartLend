package Hamburger;

import java.sql.*;
import java.time.LocalDate;
import java.time.Month;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * Requires the MySQL JDBC Driver (Connector/J)
 * Add to your project library: https://dev.mysql.com/downloads/connector/j/
 */
public class Ledger extends javax.swing.JPanel {

    // Database connection parameters -- adjust as needed for your environment
    private static final String DB_URL = "jdbc:mysql://localhost:3306/java_user_database";
    private static final String DB_USER = "root";
    private static final String DB_PASS = ""; // your password

    public Ledger() {
        initComponents();
        fillMonthsComboBox();
        loadLedgerData();
        ComboBoxMonths.addActionListener(e -> loadLedgerData());
    }

    private void fillMonthsComboBox() {
        ComboBoxMonths.removeAllItems();
        for (Month m : Month.values()) {
            ComboBoxMonths.addItem(m.name());
        }
        ComboBoxMonths.setSelectedIndex(LocalDate.now().getMonthValue() - 1);
    }

    private void loadLedgerData() {
        String selectedMonth = (String) ComboBoxMonths.getSelectedItem();
        int monthNumber = ComboBoxMonths.getSelectedIndex() + 1;
        int year = LocalDate.now().getYear();
        if (selectedMonth == null) return;

        // Get ledger data
        Vector<Vector<Object>> tableData = new Vector<>();
        double totalEarned = 0.0;

        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            // Query loan_schedules for current month/year, group by status
            String sql =
                "SELECT status, SUM(total_amount) as amount, COUNT(*) as cnt " +
                "FROM loan_schedules " +
                "WHERE MONTH(due_date) = ? AND YEAR(due_date) = ? " +
                "GROUP BY status";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, monthNumber);
            ps.setInt(2, year);
            ResultSet rs = ps.executeQuery();

            // Default: Unpaid, Partially Paid, Fully Paid
            double unpaid = 0, partial = 0, full = 0;
            while (rs.next()) {
                int status = rs.getInt("status");
                double amount = rs.getDouble("amount");
                if (status == 0) unpaid = amount;
                if (status == 1) partial = amount;
                if (status == 2) full = amount;
            }

            // For accumulated total earnings (fully paid for that month)
            String sqlTotal =
                "SELECT SUM(total_amount) as total_earned FROM loan_schedules " +
                "WHERE MONTH(due_date) = ? AND YEAR(due_date) = ? AND status = 2";
            PreparedStatement ps2 = con.prepareStatement(sqlTotal);
            ps2.setInt(1, monthNumber);
            ps2.setInt(2, year);
            ResultSet rs2 = ps2.executeQuery();
            if (rs2.next()) {
                totalEarned = rs2.getDouble("total_earned");
            }

            // Prepare table data
            Vector<Object> row = new Vector<>();
            row.add(unpaid);
            row.add(partial);
            row.add(full);
            tableData.add(row);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
            ex.printStackTrace();
        }

        // Update JTable
        DefaultTableModel model = new DefaultTableModel(
            new Object[][] {},
            new String[] { "Unpaid", "Partially Paid", "Fully Paid" }
        );
        for (Vector<Object> r : tableData) {
            model.addRow(r);
        }
        jTable1.setModel(model);

        // Update total earned text field
        totalEarnedField.setText(String.format("%.2f", totalEarned));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        searchFunction1 = new Function.SearchFunction();
        ComboBoxMonths = new javax.swing.JComboBox<>();
        totalEarnedField = new javax.swing.JTextField();
        totalEarnedLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        ComboBoxMonths.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { }));

        totalEarnedLabel.setText("Total Earned This Month:");
        totalEarnedField.setEditable(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addGap(17, 17, 17)
                    .addComponent(ComboBoxMonths, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(totalEarnedLabel)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(totalEarnedField, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                    .addComponent(searchFunction1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addContainerGap(35, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(ComboBoxMonths, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(searchFunction1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(totalEarnedField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(totalEarnedLabel))
                    .addContainerGap())
        );

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
            },
            new String [] {
                "Unpaid", "Partially Paid", "Fully Paid"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(18, 18, 18)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 607, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(40, 40, 40))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>

    // Variables declaration - do not modify
    private javax.swing.JComboBox<String> ComboBoxMonths;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private Function.SearchFunction searchFunction1;
    private javax.swing.JTextField totalEarnedField;
    private javax.swing.JLabel totalEarnedLabel;
    // End of variables declaration
}