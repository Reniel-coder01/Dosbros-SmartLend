package Hamburger;

import javax.swing.*;
import java.awt.*;

public class navbar extends JPanel {
    private Color primaryColor = new Color(41, 128, 185);
    private Color textColor = Color.WHITE;
    private Font brandFont = new Font("Arial", Font.BOLD, 18);

    private JLabel brandLabel;
    private JButton hamburgerButton;
    private JPopupMenu popupMenu;

    public navbar() {
        setLayout(new BorderLayout());
        setBackground(primaryColor);
        setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Create brand panel
        JPanel brandPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        brandPanel.setOpaque(false);
        brandLabel = new JLabel("Dosbros SmartLend");
        brandLabel.setFont(brandFont);
        brandLabel.setForeground(textColor);
        brandPanel.add(brandLabel);

        // Create hamburger button
        hamburgerButton = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(textColor);
                int width = getWidth();
                int height = getHeight();
                int lineWidth = width / 2;
                int lineHeight = 3;
                int space = 6;
                int x = (width - lineWidth) / 2;
                int yStart = (height - (lineHeight * 3 + space * 2)) / 2;
                for (int i = 0; i < 3; i++) {
                    g2.fillRect(x, yStart + i * (lineHeight + space), lineWidth, lineHeight);
                }
                g2.dispose();
            }
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(40, 30);
            }
        };
        hamburgerButton.setOpaque(false);
        hamburgerButton.setContentAreaFilled(false);
        hamburgerButton.setBorder(BorderFactory.createEmptyBorder());
        hamburgerButton.setFocusPainted(false);

        // Popup menu
        popupMenu = new JPopupMenu();
        JMenuItem recordsItem = new JMenuItem("Records");
        JMenuItem ledgerItem = new JMenuItem("Ledger");

        // Ledger first, then records (optional order)
        ledgerItem.addActionListener(e -> showLedgerDialog());
        recordsItem.addActionListener(e -> showRecordsDialog());

        popupMenu.add(ledgerItem);
        popupMenu.add(recordsItem);

        hamburgerButton.addActionListener(e -> popupMenu.show(hamburgerButton, 0, hamburgerButton.getHeight()));

        add(brandPanel, BorderLayout.WEST);
        add(hamburgerButton, BorderLayout.EAST);
    }

    private void showRecordsDialog() {
        JDialog recordsDialog = new JDialog();
        recordsDialog.setTitle("Records");
        recordsDialog.setModal(true);
        recordsDialog.setSize(600, 400);
        recordsDialog.setLocationRelativeTo(this);

        JPanel recordsPanel = new JPanel();
        recordsPanel.add(new JLabel("Records Panel"));
        recordsDialog.add(recordsPanel, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> recordsDialog.dispose());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(closeButton);
        recordsDialog.add(buttonPanel, BorderLayout.SOUTH);

        recordsDialog.setVisible(true);
    }

    private void showLedgerDialog() {
        // Correct: Specify BorderLayout.CENTER for Ledger panel
        JDialog ledgerDialog = new JDialog();
        ledgerDialog.setTitle("Ledger");
        ledgerDialog.setModal(true);
        ledgerDialog.setSize(900, 600);
        ledgerDialog.setLocationRelativeTo(this);

        JPanel ledgerPanel = new Ledger();
        ledgerDialog.add(ledgerPanel, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> ledgerDialog.dispose());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(closeButton);
        ledgerDialog.add(buttonPanel, BorderLayout.SOUTH);

        ledgerDialog.setVisible(true);
    }
}