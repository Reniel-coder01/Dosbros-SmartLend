package Round;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Area;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JPanel;

import Item.LoanIcon;
import Item.PaymentIcon;
import Item.Borrowers;
import Item.PlanIcon;
import Item.TypeIcon;
import Item.UserIcon;
import Item.Logout;
import Item.Home;
import System.SystemColor;

public class RoundPanel extends JPanel {
    private int round;
    private boolean hover = false;
    private boolean adminOnly = false;
    
    // Colors for logout
    private static final Color LOGOUT_COLOR = new Color(220, 53, 69); // Red color
    private static final Color LOGOUT_HOVER_COLOR = new Color(248, 108, 107); // Lighter red for hover

    public void setAdminOnly(boolean adminOnly) {
        this.adminOnly = adminOnly;
    }

    public boolean isAdminOnly() {
        return adminOnly;
    }

    public RoundPanel() {
        setOpaque(false);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hover = true;
                updateLoanIconsHover(true);
                repaint();
            }
            @Override
            public void mouseExited(MouseEvent e) {
                hover = false;
                updateLoanIconsHover(false);
                repaint();
            }
        });
    }

  // In RoundPanel.java
private void updateLoanIconsHover(boolean isHover) {
    for (Component comp : getComponents()) {
        if (comp instanceof LoanIcon) {
            ((LoanIcon) comp).setHover(isHover);
        } else if (comp instanceof PaymentIcon) {
            ((PaymentIcon) comp).setHover(isHover);
        } else if (comp instanceof Borrowers) {
            ((Borrowers) comp).setHover(isHover);
        } else if (comp instanceof PlanIcon) {
            ((PlanIcon) comp).setHover(isHover);
        } else if (comp instanceof TypeIcon) {
            ((TypeIcon) comp).setHover(isHover);
        } else if (comp instanceof UserIcon) {
            ((UserIcon) comp).setHover(isHover);
        } else if (comp instanceof Logout) {
            // Special handling for Logout button
            Logout logout = (Logout) comp;
            logout.setHover(isHover);
            if (isHover) {
                setBackground(new Color(255, 102, 102)); // Lighter red on hover
            } else {
                setBackground(new Color(204, 0, 0)); // Darker red normally
            }
        } else if (comp instanceof Home) {
            ((Home) comp).setHover(isHover);
        }
    }
    revalidate();
    repaint();
}

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Area area = new Area(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), round, round));
        if (hover) {
            g2.setColor(Color.WHITE);
            g2.fill(area);
        } else {
            g2.setColor(getBackground());
            g2.fill(area);
            area.subtract(new Area(new Rectangle2D.Double(0, 0, getWidth(), getHeight() - 3)));
        }
            g2.setPaint(new GradientPaint(0, 0, SystemColor.MAIN_COLOR_1, getWidth(), 0, SystemColor.MAIN_COLOR_2));
            g2.fill(area);
        g2.dispose();
        super.paintComponent(g);
    }
}