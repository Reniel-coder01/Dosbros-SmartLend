package Icon;

import java.awt.*;
import java.util.*;
import javax.swing.*;

public class JavaPieChart extends JPanel {
    
    private java.util.List<Slice> slices;
    private String title;
    private boolean showPercentages;
    
    public JavaPieChart() {
        this("Micro Lending Status");
    }
    
    public JavaPieChart(String title) {
        this.title = title;
        this.slices = new ArrayList<>();
        this.showPercentages = true;
        setPreferredSize(new Dimension(300, 250));
        setBackground(Color.WHITE);
        initializeMicroLendingData();
    }
    
    private void initializeMicroLendingData() {
        // Initialize with default data (can be updated later)
        addSlice("For Approval", 25, new Color(255, 193, 7));  // Amber
        addSlice("Approved", 35, new Color(76, 175, 80));      // Green
        addSlice("Released", 20, new Color(33, 150, 243));     // Blue
        addSlice("Complete", 15, new Color(0, 150, 136));      // Teal
        addSlice("Denied", 5, new Color(244, 67, 54));         // Red
    }
    
    public void addSlice(String label, double value, Color color) {
        slices.add(new Slice(label, value, color));
        repaint();
    }
    
    public void updateSlice(String label, double value) {
        for (Slice slice : slices) {
            if (slice.label.equals(label)) {
                slice.value = value;
                repaint();
                return;
            }
        }
        // If slice doesn't exist, add it with a default color
        addSlice(label, value, new Color(150, 150, 150));
    }
    
    public void clearSlices() {
        slices.clear();
        repaint();
    }
    
    public void setTitle(String title) {
        this.title = title;
        repaint();
    }
    
    public void setShowPercentages(boolean showPercentages) {
        this.showPercentages = showPercentages;
        repaint();
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        int width = getWidth();
        int height = getHeight();
        
        // Draw title
        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("SansSerif", Font.BOLD, 14));
        FontMetrics fm = g2d.getFontMetrics();
        int titleWidth = fm.stringWidth(title);
        g2d.drawString(title, (width - titleWidth) / 2, 20);
        
        // Calculate total value for all slices
        double total = 0;
        for (Slice slice : slices) {
            total += slice.value;
        }
        
        // Don't draw if no data
        if (total <= 0 || slices.isEmpty()) {
            g2d.setColor(Color.GRAY);
            g2d.drawOval(width/4, height/4, width/2, height/2);
            g2d.dispose();
            return;
        }
        
        // Draw pie chart
        int pieSize = Math.min(width, height - 80);
        int pieX = (width - pieSize) / 2;
        int pieY = 30;
        
        double currentAngle = 0;
        
        // Draw each slice
        for (Slice slice : slices) {
            // Calculate angle for this slice
            double sliceAngle = 360 * (slice.value / total);
            
            // Draw the slice
            g2d.setColor(slice.color);
            g2d.fillArc(pieX, pieY, pieSize, pieSize, (int) currentAngle, (int) sliceAngle);
            
            // Draw slice border
            g2d.setColor(Color.WHITE);
            g2d.drawArc(pieX, pieY, pieSize, pieSize, (int) currentAngle, (int) sliceAngle);
            
            // Calculate position for percentage label if needed
            if (showPercentages && sliceAngle > 10) {
                double middleAngle = Math.toRadians(currentAngle + sliceAngle/2);
                int labelX = pieX + pieSize/2 + (int)((pieSize/3) * Math.cos(middleAngle));
                int labelY = pieY + pieSize/2 + (int)((pieSize/3) * Math.sin(middleAngle));
                
                String percentText = String.format("%.1f%%", (slice.value/total)*100);
                g2d.setColor(Color.WHITE);
                g2d.setFont(new Font("SansSerif", Font.BOLD, 10));
                g2d.drawString(percentText, labelX-15, labelY+5);
            }
            
            currentAngle += sliceAngle;
        }
        
        // Draw legend
        int legendX = 10;
        int legendY = pieY + pieSize + 10;
        int legendWidth = width - 20;
        int legendHeight = 20;
        int itemsPerRow = 3;
        int itemWidth = legendWidth / itemsPerRow;
        
        g2d.setFont(new Font("SansSerif", Font.PLAIN, 11));
        
        for (int i = 0; i < slices.size(); i++) {
            Slice slice = slices.get(i);
            int row = i / itemsPerRow;
            int col = i % itemsPerRow;
            
            int x = legendX + (col * itemWidth);
            int y = legendY + (row * legendHeight);
            
            g2d.setColor(slice.color);
            g2d.fillRect(x, y, 10, 10);
            
            g2d.setColor(Color.BLACK);
            String legendText = slice.label + " (" + Math.round(slice.value) + ")";
            g2d.drawString(legendText, x + 15, y + 9);
        }
        
        g2d.dispose();
    }
    
    // Inner class to represent a slice of the pie
    private static class Slice {
        String label;
        double value;
        Color color;
        
        public Slice(String label, double value, Color color) {
            this.label = label;
            this.value = value;
            this.color = color;
        }
    }
    
    // Example usage
    public static void main(String[] args) {
        JFrame frame = new JFrame("Micro Lending Status");
        JavaPieChart pieChart = new JavaPieChart();
        
        // Data can be updated with real values
        pieChart.clearSlices();
        pieChart.addSlice("For Approval", 42, new Color(255, 193, 7));
        pieChart.addSlice("Approved", 28, new Color(76, 175, 80));
        pieChart.addSlice("Released", 15, new Color(33, 150, 243));
        pieChart.addSlice("Complete", 10, new Color(0, 150, 136));
        pieChart.addSlice("Denied", 5, new Color(244, 67, 54));
        
        frame.add(pieChart);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(350, 300);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
