package Icon;

import javax.swing.*;
import java.awt.*;

public class UserIcon extends JLabel {
    
    public UserIcon() {
        // Create user icon
        ImageIcon icon = new ImageIcon("user_icon.png");
        this.setIcon(icon);
    }
    // Add to both UserIcon and LockIcon classes
@Override
public void paintComponent(Graphics g) {
    super.paintComponent(g);
    if (getIcon() == null) {
        // Set a default size if no icon
        setPreferredSize(new Dimension(24, 24));
    }
}

    // Method to resize the icon
    public void resizeIcon(int width, int height) {
        ImageIcon originalIcon = (ImageIcon) this.getIcon();
        if (originalIcon != null) {
            Image originalImage = originalIcon.getImage();
            Image resizedImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            this.setIcon(new ImageIcon(resizedImage));
        }
    }
    
    // Method to add this icon to a container with GridBagConstraints
    public void addToContainer(Container container, GridBagConstraints gbc, int gridx, int gridy) {
        gbc.gridx = gridx;
        gbc.gridy = gridy;
        container.add(this, gbc);
    }
}
