package Icon;

import java.awt.*;
import javax.swing.*;

public class Receivable extends JLabel {
    
    private Color iconColor;
    
    public Receivable() {
        this(new Color(0, 150, 136)); // Teal color
    }
    
    public Receivable(Color iconColor) {
        this.iconColor = iconColor;
        setPreferredSize(new Dimension(47, 46));
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        int width = getWidth();
        int height = getHeight();
        
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw document shape
        g2d.setColor(iconColor);
        int docWidth = width - 10;
        int docHeight = height - 10;
        g2d.fillRoundRect(5, 5, docWidth, docHeight, 4, 4);
        
        // Draw folded corner
        int cornerSize = 8;
        g2d.setColor(new Color(0, 121, 107)); // Darker teal for corner
        int[] xPoints = {width - 5 - cornerSize, width - 5, width - 5};
        int[] yPoints = {5, 5, 5 + cornerSize};
        g2d.fillPolygon(xPoints, yPoints, 3);
        
        // Draw peso sign (₱)
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 16));
        FontMetrics fm = g2d.getFontMetrics();
        String pesoSign = "₱";
        
        // If the peso sign isn't available in the font, use "P" as fallback
        if (!g2d.getFont().canDisplay('₱')) {
            pesoSign = "P";
        }
        
        int textX = width/2 - fm.stringWidth(pesoSign)/2;
        int textY = height/2 + fm.getAscent()/2 - 2;
        g2d.drawString(pesoSign, textX, textY);
        
        // Draw horizontal lines (receipt lines)
        g2d.setColor(new Color(240, 240, 240));
        g2d.fillRoundRect(10, height - 18, docWidth - 10, 2, 1, 1);
        g2d.fillRoundRect(10, height - 14, docWidth - 10, 2, 1, 1);
        
        // Draw incoming arrow (indicating receivables)
        g2d.setColor(Color.WHITE);
        g2d.setStroke(new BasicStroke(2));
        int arrowX = width/2;
        int arrowY = 12;
        int arrowSize = 8;
        
        // Arrow shaft
        g2d.drawLine(arrowX, arrowY, arrowX, arrowY + arrowSize);
        
        // Arrow head
        g2d.drawLine(arrowX, arrowY + arrowSize, arrowX - 4, arrowY + arrowSize - 4);
        g2d.drawLine(arrowX, arrowY + arrowSize, arrowX + 4, arrowY + arrowSize - 4);
        
        g2d.dispose();
    }
    
    // Optional: Custom method to manually draw a peso sign if needed
    private void drawPesoSign(Graphics2D g2d, int x, int y) {
        g2d.setStroke(new BasicStroke(2));
        
        // Vertical line
        g2d.drawLine(x, y - 8, x, y + 8);
        
        // Horizontal lines
        g2d.drawLine(x - 4, y - 4, x + 4, y - 4);
        g2d.drawLine(x - 4, y, x + 4, y);
        
        // P curve
        g2d.drawArc(x - 4, y - 8, 8, 8, 270, 180);
    }
}
