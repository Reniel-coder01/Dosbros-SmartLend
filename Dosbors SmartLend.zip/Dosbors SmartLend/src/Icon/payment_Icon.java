package Icon;

import java.awt.*;
import javax.swing.*;

public class payment_Icon extends JLabel {
    
    private Color cardColor;
    
    public payment_Icon() {
        this(new Color(0, 120, 212));
    }
    
    public payment_Icon(Color cardColor) {
        this.cardColor = cardColor;
        setPreferredSize(new Dimension(47, 46));
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        int width = getWidth();
        int height = getHeight();
        
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw credit card shape
        g2d.setColor(cardColor);
        g2d.fillRoundRect(1, 4, width - 2, height - 8, 4, 4);
        
        // Draw magnetic stripe
        g2d.setColor(new Color(50, 50, 50));
        g2d.fillRect(1, 9, width - 2, 4);
        
        // Draw chip
        g2d.setColor(new Color(255, 215, 0));
        g2d.fillRoundRect(6, 15, 8, 6, 2, 2);
        
        // Draw payment lines
        g2d.setColor(Color.WHITE);
        g2d.fillRoundRect(18, 15, width - 24, 2, 1, 1);
        g2d.fillRoundRect(18, 19, width - 24, 2, 1, 1);
        
        g2d.dispose();
    }
}
