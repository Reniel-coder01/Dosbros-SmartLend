package Icon;

import java.awt.*;
import javax.swing.*;

public class Borrowers_Icon extends JLabel {
    
    private Color iconColor;
    
    public Borrowers_Icon() {
        this(new Color(76, 175, 80)); // Default green color
    }
    
    public Borrowers_Icon(Color iconColor) {
        this.iconColor = iconColor;
        setPreferredSize(new Dimension(47, 46));
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        int width = getWidth();
        int height = getHeight();
        
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw folder shape
        g2d.setColor(iconColor);
        int folderWidth = width - 2;
        int folderHeight = height - 10;
        g2d.fillRoundRect(1, 8, folderWidth, folderHeight, 4, 4);
        
        // Draw folder tab
        int tabWidth = folderWidth / 3;
        g2d.fillRoundRect(1, 4, tabWidth, 6, 2, 2);
        
        // Draw person silhouette
        g2d.setColor(Color.WHITE);
        // Head
        int headSize = 8;
        int centerX = width / 2;
        int headY = 14;
        g2d.fillOval(centerX - headSize/2, headY, headSize, headSize);
        
        // Body
        int bodyWidth = 12;
        int bodyHeight = 14;
        int bodyY = headY + headSize - 1;
        g2d.fillRoundRect(centerX - bodyWidth/2, bodyY, bodyWidth, bodyHeight, 3, 3);
        
        // Document lines
        g2d.setColor(new Color(240, 240, 240));
        g2d.fillRoundRect(width/2 - 15, 32, 30, 2, 1, 1);
        g2d.fillRoundRect(width/2 - 15, 36, 30, 2, 1, 1);
        
        g2d.dispose();
    }
}
