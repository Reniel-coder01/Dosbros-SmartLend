package Icon;

import java.awt.*;
import javax.swing.*;

public class lends_Icon extends JLabel {
    
    private Color iconColor;
    
    public lends_Icon() {
        this(new Color(255, 193, 7)); // Default yellow color
    }
    
    public lends_Icon(Color iconColor) {
        this.iconColor = iconColor;
        setPreferredSize(new Dimension(47, 46));
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        int width = getWidth();
        int height = getHeight();
        
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw book shape
        g2d.setColor(iconColor);
        int bookWidth = width - 10;
        int bookHeight = height - 14;
        g2d.fillRoundRect(5, 7, bookWidth, bookHeight, 3, 3);
        
        // Draw book spine
        g2d.setColor(iconColor.darker());
        g2d.fillRoundRect(3, 7, 4, bookHeight, 2, 2);
        
        // Draw book pages
        g2d.setColor(Color.WHITE);
        g2d.fillRect(7, 9, bookWidth - 4, bookHeight - 4);
        
        // Draw arrow (lending symbol)
        int arrowWidth = 20;
        int arrowHeight = 8;
        int arrowX = width/2 - arrowWidth/2;
        int arrowY = height/2;
        
        // Arrow body
        g2d.setColor(iconColor.darker());
        g2d.fillRect(arrowX, arrowY, arrowWidth, 2);
        
        // Arrow head
        int[] xPoints = {arrowX + arrowWidth, arrowX + arrowWidth, arrowX + arrowWidth + 5};
        int[] yPoints = {arrowY - arrowHeight/2, arrowY + arrowHeight/2, arrowY};
        g2d.fillPolygon(xPoints, yPoints, 3);
        
        // Draw lines representing text in the book
        g2d.setColor(new Color(220, 220, 220));
        g2d.fillRoundRect(10, 15, bookWidth - 10, 2, 1, 1);
        g2d.fillRoundRect(10, 20, bookWidth - 15, 2, 1, 1);
        g2d.fillRoundRect(10, 25, bookWidth - 12, 2, 1, 1);
        g2d.fillRoundRect(10, 30, bookWidth - 18, 2, 1, 1);
        
        g2d.dispose();
    }
}
