package Function;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;
import javax.swing.JTable;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class SearchFunction extends javax.swing.JPanel {
    private JTable targetTable;
    private TableRowSorter<DefaultTableModel> sorter;
    
    public SearchFunction() {
        initComponents();
        setupRealTimeSearch();
    }
    
    // Method to connect this search function to a JTable
    public void setTargetTable(JTable table) {
        this.targetTable = table;
        if (table.getModel() instanceof DefaultTableModel) {
            this.sorter = new TableRowSorter<>((DefaultTableModel) table.getModel());
            table.setRowSorter(sorter);
        }
    }
    
    // Add real-time search as user types
    private void setupRealTimeSearch() {
        TextFieldSeach.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { performSearch(); }
            
            @Override
            public void removeUpdate(DocumentEvent e) { performSearch(); }
            
            @Override
            public void changedUpdate(DocumentEvent e) { performSearch(); }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        TextFieldSeach = new javax.swing.JTextField();
        SearchButton = new javax.swing.JButton();

        TextFieldSeach.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldSeachActionPerformed(evt);
            }
        });

        SearchButton.setBackground(new java.awt.Color(0, 255, 0));
        SearchButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        SearchButton.setText("Search");
        SearchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(TextFieldSeach, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SearchButton, javax.swing.GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE)
                .addGap(18, 18, 18))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextFieldSeach, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SearchButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void SearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchButtonActionPerformed
        performSearch();
    }//GEN-LAST:event_SearchButtonActionPerformed

    private void TextFieldSeachActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldSeachActionPerformed
        performSearch();
    }//GEN-LAST:event_TextFieldSeachActionPerformed
       private void performSearch() {
    if (sorter == null) return;
    
    String searchText = TextFieldSeach.getText().trim();
    
    if (searchText.isEmpty()) {
        sorter.setRowFilter(null);
    } else {
        try {
            // Create a more comprehensive filter that searches multiple columns including the sequence number
            RowFilter<DefaultTableModel, Object> filter = RowFilter.orFilter(
                java.util.Arrays.asList(
                    RowFilter.regexFilter("(?i)" + searchText, 0), // Sequence number column (#)
                    RowFilter.regexFilter("(?i)" + searchText, 1), // Lenders column
                    RowFilter.regexFilter("(?i)" + searchText, 2), // Current Lend column
                    RowFilter.regexFilter("(?i)" + searchText, 3)  // Next Payment Schedule column
                )
            );
            sorter.setRowFilter(filter);
        } catch (java.util.regex.PatternSyntaxException e) {
            // If regex is invalid, fall back to simple text search across all searchable columns
            RowFilter<DefaultTableModel, Object> fallbackFilter = RowFilter.orFilter(
                java.util.Arrays.asList(
                    RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(searchText), 0),
                    RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(searchText), 1),
                    RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(searchText), 2),
                    RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(searchText), 3)
                )
            );
            sorter.setRowFilter(fallbackFilter);
        }
    }
}

    // Method to clear search
    public void clearSearch() {
        TextFieldSeach.setText("");
        if (sorter != null) {
            sorter.setRowFilter(null);
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton SearchButton;
    private javax.swing.JTextField TextFieldSeach;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
