package Function;
import java.sql.*;
import javax.swing.*;
import java.awt.event.KeyEvent;
import java.text.NumberFormat;
import java.util.Locale;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.swing.BorderFactory;
import java.awt.Color;
import Content.Loan;
import java.awt.Component;

public class CreateNewApplication extends javax.swing.JPanel {

    private Connection connection;
    private NumberFormat currencyFormat;

    // Loan calculation variables
    private double loanAmount = 0.0;
    private int loanMonths = 0;
    private double interestRate = 0.0;
    private double penaltyRate = 0.0;
    private double interestAmount = 0.0; // new

    public CreateNewApplication() {
        initComponents();
        initializeDatabase();
        setupComponents();
        loadComboBoxData();
    }

    private void initializeDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/java_user_database",
                "root",
                ""
            );
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Database connection failed: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
        // Initialize currency formatter
        currencyFormat = NumberFormat.getCurrencyInstance(new Locale("en", "PH"));
    }

    private void setupComponents() {
        ComboBoxLender.removeAllItems();
        ComboBoxLendType.removeAllItems();
        ComboBoxLendPlan.removeAllItems();

        ComboBoxLender.addItem("Select Lender...");
        ComboBoxLendType.addItem("Select Loan Type...");
        ComboBoxLendPlan.addItem("Select Loan Plan...");

        ComboBoxLender.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        updateCalculationDisplay(0.0, 0.0, 0.0);

        TextFieldLendAmount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!Character.isDigit(c) && c != '.' && c != KeyEvent.VK_BACK_SPACE) {
                    evt.consume();
                }
            }
        });
    }

    private void loadComboBoxData() {
        loadBorrowers();
        loadLoanTypes();
        loadLoanPlans();
    }

    private void loadBorrowers() {
        try {
            String sql = "SELECT b.id, b.firstname, b.middlename, b.lastname, b.tax_id " +
                    "FROM borrowers b " +
                    "WHERE b.id NOT IN (SELECT borrower_id FROM loan_list WHERE status IN (0,1,2)) " +
                    "ORDER BY b.lastname, b.firstname";
            PreparedStatement pst = connection.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String fullName = String.format("%s, %s %s",
                        rs.getString("lastname"),
                        rs.getString("firstname"),
                        rs.getString("middlename") != null ? rs.getString("middlename") : ""
                ).trim();

                String taxId = rs.getString("tax_id") != null ? rs.getString("tax_id") : "N/A";
                String displayText = String.format(
                        "<html><div style='border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; padding: 5px;'>%s<br>Tax ID: %s</div></html>",
                        fullName, taxId
                );

                ComboBoxLender.addItem(displayText);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading lenders: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadLoanTypes() {
        try {
            String sql = "SELECT id, type_name FROM loan_types ORDER BY type_name";
            PreparedStatement pst = connection.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String displayText = rs.getString("type_name");
                ComboBoxLendType.addItem(displayText);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading loan types: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadLoanPlans() {
        try {
            String sql = "SELECT id, months, interest_percentage, penalty_rate FROM loan_plan ORDER BY months";
            PreparedStatement pst = connection.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                int months = rs.getInt("months");
                double interest = rs.getDouble("interest_percentage");
                double penalty = rs.getDouble("penalty_rate");

                String displayText = String.format("%d Month/s [%.0f%%, %.0f%%]",
                        months, interest, penalty);
                ComboBoxLendPlan.addItem(displayText);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading loan plans: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private int getSelectedId(JComboBox<String> comboBox) {
        String selected = (String) comboBox.getSelectedItem();
        if (selected == null || selected.startsWith("Select")) {
            return -1;
        }
        try {
            if (comboBox == ComboBoxLender) {
                return getBorrowerIdByDisplay(selected);
            } else if (comboBox == ComboBoxLendType) {
                return getLoanTypeIdByName(selected);
            } else if (comboBox == ComboBoxLendPlan) {
                return getLoanPlanIdByDisplay(selected);
            }
        } catch (Exception e) {
            return -1;
        }
        return -1;
    }

    private int getBorrowerIdByDisplay(String displayText) {
        try {
            String cleanText = displayText.replaceAll("<[^>]*>", "").trim();
            int taxIdIndex = cleanText.indexOf("Tax ID: ");
            if (taxIdIndex == -1) {
                return -1;
            }
            String taxId = cleanText.substring(taxIdIndex + 8).trim();
            String sql = "SELECT id FROM borrowers WHERE tax_id = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, taxId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int getLoanTypeIdByName(String typeName) {
        try {
            String sql = "SELECT id FROM loan_types WHERE type_name = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, typeName);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int getLoanPlanIdByDisplay(String displayText) {
        try {
            String monthsStr = displayText.split(" ")[0];
            int months = Integer.parseInt(monthsStr);
            String sql = "SELECT id FROM loan_plan WHERE months = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, months);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    private String getSelectedText(JComboBox<String> comboBox) {
        String selected = (String) comboBox.getSelectedItem();
        return selected;
    }

    private String getSelectedTaxId() {
        String selected = (String) ComboBoxLender.getSelectedItem();
        if (selected != null && selected.contains("Tax ID:")) {
            String[] parts = selected.split("Tax ID:");
            if (parts.length > 1) {
                return parts[1].trim();
            }
        }
        return "N/A";
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        LabelEditUser = new javax.swing.JLabel();
        LabelLender = new javax.swing.JLabel();
        LabelLendPlan = new javax.swing.JLabel();
        LabelPurpose = new javax.swing.JLabel();
        LabelLendType = new javax.swing.JLabel();
        LabelLendAmount = new javax.swing.JLabel();
        ButtonCancel = new javax.swing.JButton();
        ButtonSave = new javax.swing.JButton();
        TextFieldPurpose = new javax.swing.JTextField();
        ComboBoxLender = new javax.swing.JComboBox<>();
        ComboBoxLendType = new javax.swing.JComboBox<>();
        ComboBoxLendPlan = new javax.swing.JComboBox<>();
        TextFieldLendAmount = new javax.swing.JTextField();
        CalculateButton = new javax.swing.JButton();
        LabelTotalPayableAmount = new javax.swing.JLabel();
        LabelMonthlyPayableAmount = new javax.swing.JLabel();
        LabelPenaltyAmount = new javax.swing.JLabel();
        LabelTotalPayable = new javax.swing.JLabel();
        LabelMonthlyPayable = new javax.swing.JLabel();
        LabelPenalty = new javax.swing.JLabel();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(51, 255, 204));

        LabelEditUser.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelEditUser.setText("New Lend Application");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(LabelEditUser, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LabelEditUser, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        LabelLender.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelLender.setText("Lender");

        LabelLendPlan.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelLendPlan.setText("Lend plan");

        LabelPurpose.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelPurpose.setText("Purpose");

        LabelLendType.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelLendType.setText("Lend Type");

        LabelLendAmount.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelLendAmount.setText("Lend Amount");

        ButtonCancel.setBackground(new java.awt.Color(255, 0, 0));
        ButtonCancel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonCancel.setForeground(new java.awt.Color(255, 255, 255));
        ButtonCancel.setText("Cancel");
        ButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCancelActionPerformed(evt);
            }
        });

        ButtonSave.setBackground(new java.awt.Color(0, 255, 0));
        ButtonSave.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonSave.setText("Save");
        ButtonSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonSaveActionPerformed(evt);
            }
        });

        TextFieldPurpose.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TextFieldPurpose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldPurposeActionPerformed(evt);
            }
        });

        ComboBoxLender.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ComboBoxLender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ComboBoxLender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxLenderActionPerformed(evt);
            }
        });

        ComboBoxLendType.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ComboBoxLendType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ComboBoxLendType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxLendTypeActionPerformed(evt);
            }
        });

        ComboBoxLendPlan.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ComboBoxLendPlan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ComboBoxLendPlan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxLendPlanActionPerformed(evt);
            }
        });

        TextFieldLendAmount.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TextFieldLendAmount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldLendAmountActionPerformed(evt);
            }
        });

        CalculateButton.setBackground(new java.awt.Color(0, 153, 255));
        CalculateButton.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        CalculateButton.setForeground(new java.awt.Color(255, 255, 255));
        CalculateButton.setText("Calculate");
        CalculateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CalculateButtonActionPerformed(evt);
            }
        });

        LabelTotalPayableAmount.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        LabelTotalPayableAmount.setText("Total Payable Amount");

        LabelMonthlyPayableAmount.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        LabelMonthlyPayableAmount.setText("Monthly Payable Amount");

        LabelPenaltyAmount.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        LabelPenaltyAmount.setText("Penalty Amount");

        LabelTotalPayable.setText("0.00");

        LabelMonthlyPayable.setText("0.00");

        LabelPenalty.setText("0.00");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(LabelLender)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(ComboBoxLender, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(15, 15, 15)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(LabelLendType)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(ComboBoxLendType, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(LabelPurpose)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                            .addGap(6, 6, 6)
                                            .addComponent(ComboBoxLendPlan, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(LabelLendPlan))
                                .addGap(15, 15, 15)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(LabelLendAmount)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(TextFieldLendAmount)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addComponent(TextFieldPurpose))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(LabelTotalPayableAmount)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CalculateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(LabelMonthlyPayableAmount)
                                        .addGap(39, 39, 39)
                                        .addComponent(LabelPenaltyAmount))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ButtonSave)
                        .addGap(18, 18, 18)
                        .addComponent(ButtonCancel)
                        .addGap(10, 10, 10)))
                .addGap(17, 17, 17))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(LabelTotalPayable)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(LabelMonthlyPayable)
                .addGap(202, 202, 202)
                .addComponent(LabelPenalty)
                .addGap(67, 67, 67))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelLender)
                    .addComponent(LabelLendType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ComboBoxLender, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ComboBoxLendType, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelLendPlan)
                    .addComponent(LabelLendAmount))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextFieldLendAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ComboBoxLendPlan, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addComponent(LabelPurpose)
                .addGap(18, 18, 18)
                .addComponent(TextFieldPurpose, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelTotalPayableAmount)
                    .addComponent(LabelMonthlyPayableAmount)
                    .addComponent(LabelPenaltyAmount))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelTotalPayable)
                    .addComponent(LabelMonthlyPayable)
                    .addComponent(LabelPenalty))
                .addGap(18, 18, 18)
                .addComponent(CalculateButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ButtonSave)
                    .addComponent(ButtonCancel))
                .addContainerGap(56, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    // Generated code for GUI and event handlers...

    private void ButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {
        closeConnection();
        clearForm();
        java.awt.Window window = SwingUtilities.getWindowAncestor(this);
        if (window instanceof JDialog) {
            window.dispose();
        }
    }

    private void ButtonSaveActionPerformed(java.awt.event.ActionEvent evt) {
        System.out.println("Save button clicked!");
        try {
            String selectedLender = (String) ComboBoxLender.getSelectedItem();
            if (selectedLender == null || selectedLender.equals("Select Lender...") || ComboBoxLender.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Please select a lender", "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int borrowerId = getBorrowerIdByDisplay(selectedLender);
            if (borrowerId == -1) {
                JOptionPane.showMessageDialog(this, "Please select a valid lender", "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String selectedType = (String) ComboBoxLendType.getSelectedItem();
            String selectedPlan = (String) ComboBoxLendPlan.getSelectedItem();
            String amountText = TextFieldLendAmount.getText().trim();
            String purpose = TextFieldPurpose.getText().trim();

            if (selectedType == null || selectedType.equals("Select Loan Type...") || ComboBoxLendType.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Please select a loan type", "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (selectedPlan == null || selectedPlan.equals("Select Loan Plan...") || ComboBoxLendPlan.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "Please select a loan plan", "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (amountText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter loan amount", "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int loanTypeId = getLoanTypeIdByName(selectedType);
            int planId = getLoanPlanIdByDisplay(selectedPlan);
            if (loanTypeId == -1 || planId == -1) {
                JOptionPane.showMessageDialog(this, "Error getting loan details", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            double amount = Double.parseDouble(amountText);

            // Get plan details for interest and months
            double planInterest = 0.0, planPenalty = 0.0;
            int planMonths = 0;
            String sqlPlan = "SELECT months, interest_percentage, penalty_rate FROM loan_plan WHERE id = ?";
            PreparedStatement pstPlan = connection.prepareStatement(sqlPlan);
            pstPlan.setInt(1, planId);
            ResultSet rsPlan = pstPlan.executeQuery();
            if (rsPlan.next()) {
                planMonths = rsPlan.getInt("months");
                planInterest = rsPlan.getDouble("interest_percentage");
                planPenalty = rsPlan.getDouble("penalty_rate");
            }
            // Calculate interest_amount and total_payable
            double interestAmount = amount * (planInterest / 100.0);
            double totalPayable = amount + interestAmount;

            // Insert into loan_list
            String sql = "INSERT INTO loan_list (borrower_id, loan_type_id, plan_id, amount, interest_amount, total_payable, purpose, status, date_created) VALUES (?, ?, ?, ?, ?, ?, ?, 0, NOW())";
            PreparedStatement pst = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pst.setInt(1, borrowerId);
            pst.setInt(2, loanTypeId);
            pst.setInt(3, planId);
            pst.setDouble(4, amount);
            pst.setDouble(5, interestAmount);
            pst.setDouble(6, totalPayable);
            pst.setString(7, purpose);

            int result = pst.executeUpdate();

            if (result > 0) {
                ResultSet generatedKeys = pst.getGeneratedKeys();
                int loanId = 0;
                if (generatedKeys.next()) {
                    loanId = generatedKeys.getInt(1);
                }
                createLoanSchedules(loanId, amount, planMonths, planInterest);

                JOptionPane.showMessageDialog(this,
                    "Loan application saved successfully!\n\n" +
                            "Loan ID: " + loanId +
                            "\nBorrower: " + selectedLender +
                            "\nAmount: " + currencyFormat.format(amount) +
                            "\nInterest: " + currencyFormat.format(interestAmount) +
                            "\nTotal Payable: " + currencyFormat.format(totalPayable),
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
                );

                java.awt.Window window = SwingUtilities.getWindowAncestor(this);
                if (window instanceof JDialog) {
                    window.dispose();
                }
                // If you have a Loan table, refresh it here (optional)
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Error saving loan: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void ComboBoxLendPlanActionPerformed(java.awt.event.ActionEvent evt) {
        loadPlanDetails();
        if (isFormReadyForCalculation()) {
            calculateLoan();
        }
    }

    private void TextFieldPurposeActionPerformed(java.awt.event.ActionEvent evt) {
        if (isFormReadyForCalculation()) {
            calculateLoan();
        }
    }

    private void CalculateButtonActionPerformed(java.awt.event.ActionEvent evt) {
        if (ComboBoxLender.getSelectedIndex() == 0 ||
            ComboBoxLendType.getSelectedIndex() == 0 ||
            ComboBoxLendPlan.getSelectedIndex() == 0 ||
            TextFieldLendAmount.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(this,
                "Please fill in all required fields",
                "Missing Information",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        loadPlanDetails();
        calculateLoan();
    }

    private void ComboBoxLendTypeActionPerformed(java.awt.event.ActionEvent evt) {}
    private void TextFieldLendAmountActionPerformed(java.awt.event.ActionEvent evt) {
        if (isFormReadyForCalculation()) {
            calculateLoan();
        }
    }
    private void ComboBoxLenderActionPerformed(java.awt.event.ActionEvent evt) {}

    private void loadPlanDetails() {
        int planId = getSelectedId(ComboBoxLendPlan);
        if (planId > 0) {
            try {
                String sql = "SELECT months, interest_percentage, penalty_rate FROM loan_plan WHERE id = ?";
                PreparedStatement pst = connection.prepareStatement(sql);
                pst.setInt(1, planId);
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    loanMonths = rs.getInt("months");
                    interestRate = rs.getDouble("interest_percentage");
                    penaltyRate = rs.getDouble("penalty_rate");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,
                    "Error loading plan details: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private boolean isFormReadyForCalculation() {
        return getSelectedId(ComboBoxLender) > 0 &&
               getSelectedId(ComboBoxLendType) > 0 &&
               getSelectedId(ComboBoxLendPlan) > 0 &&
               !TextFieldLendAmount.getText().trim().isEmpty();
    }

    private void calculateLoan() {
        try {
            String amountText = TextFieldLendAmount.getText().trim();
            if (amountText.isEmpty()) {
                return;
            }
            loanAmount = Double.parseDouble(amountText);
            if (loanAmount <= 0) {
                JOptionPane.showMessageDialog(this,
                    "Please enter a valid loan amount greater than 0",
                    "Invalid Amount",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            // Calculate loan details
            interestAmount = loanAmount * (interestRate / 100.0);
            double totalPayable = loanAmount + interestAmount;
            double monthlyPayment = totalPayable / loanMonths;
            double penaltyAmount = monthlyPayment * (penaltyRate / 100.0);

            // Update display
            updateCalculationDisplay(totalPayable, monthlyPayment, penaltyAmount);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                "Please enter a valid numeric amount",
                "Invalid Input",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void updateCalculationDisplay(double totalPayable, double monthlyPayment, double penalty) {
        LabelTotalPayable.setText(currencyFormat.format(totalPayable));
        LabelMonthlyPayable.setText(currencyFormat.format(monthlyPayment));
        LabelPenalty.setText(currencyFormat.format(penalty));
    }

    private void createLoanSchedules(int loanId, double amount, int months, double interestRate) {
        try {
            double totalInterest = amount * (interestRate / 100);
            double totalAmount = amount + totalInterest;
            double monthlyPayment = totalAmount / months;
            double principalPerMonth = amount / months;
            double interestPerMonth = totalInterest / months;

            String sql = """
                INSERT INTO loan_schedules
                (loan_id, installment_number, due_date, principal_amount, interest_amount,
                 total_amount, remaining_amount, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 0, NOW())
                """;

            PreparedStatement pst = connection.prepareStatement(sql);

            java.util.Calendar calendar = java.util.Calendar.getInstance();
            calendar.add(java.util.Calendar.MONTH, 1); // Start from next month

            for (int i = 1; i <= months; i++) {
                pst.setInt(1, loanId);
                pst.setInt(2, i);
                pst.setDate(3, new java.sql.Date(calendar.getTimeInMillis()));
                pst.setBigDecimal(4, new BigDecimal(principalPerMonth).setScale(2, RoundingMode.HALF_UP));
                pst.setBigDecimal(5, new BigDecimal(interestPerMonth).setScale(2, RoundingMode.HALF_UP));
                pst.setBigDecimal(6, new BigDecimal(monthlyPayment).setScale(2, RoundingMode.HALF_UP));
                pst.setBigDecimal(7, new BigDecimal(monthlyPayment).setScale(2, RoundingMode.HALF_UP));
                pst.addBatch();
                calendar.add(java.util.Calendar.MONTH, 1);
            }
            pst.executeBatch();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error creating loan schedules: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void clearForm() {
        ComboBoxLender.setSelectedIndex(0);
        ComboBoxLendType.setSelectedIndex(0);
        ComboBoxLendPlan.setSelectedIndex(0);
        TextFieldLendAmount.setText("");
        TextFieldPurpose.setText("");
        updateCalculationDisplay(0.0, 0.0, 0.0);
        loanAmount = 0.0;
        loanMonths = 0;
        interestRate = 0.0;
        penaltyRate = 0.0;
        interestAmount = 0.0;
    }

    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ... (rest of your class, helper methods, etc.)

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonCancel;
    private javax.swing.JButton ButtonSave;
    private javax.swing.JButton CalculateButton;
    private javax.swing.JComboBox<String> ComboBoxLendPlan;
    private javax.swing.JComboBox<String> ComboBoxLendType;
    private javax.swing.JComboBox<String> ComboBoxLender;
    private javax.swing.JLabel LabelEditUser;
    private javax.swing.JLabel LabelLendAmount;
    private javax.swing.JLabel LabelLendPlan;
    private javax.swing.JLabel LabelLendType;
    private javax.swing.JLabel LabelLender;
    private javax.swing.JLabel LabelMonthlyPayable;
    private javax.swing.JLabel LabelMonthlyPayableAmount;
    private javax.swing.JLabel LabelPenalty;
    private javax.swing.JLabel LabelPenaltyAmount;
    private javax.swing.JLabel LabelPurpose;
    private javax.swing.JLabel LabelTotalPayable;
    private javax.swing.JLabel LabelTotalPayableAmount;
    private javax.swing.JTextField TextFieldLendAmount;
    private javax.swing.JTextField TextFieldPurpose;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}