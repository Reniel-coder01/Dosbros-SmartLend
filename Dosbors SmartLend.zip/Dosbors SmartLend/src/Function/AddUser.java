
package Function;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.sql.ResultSet;
import java.sql.Statement;


public class AddUser extends javax.swing.JPanel {
    
    public AddUser() {
        initComponents();
        // Update the label text for Add User
        LabelEditUser.setText("Add User");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        LabelEditUser = new javax.swing.JLabel();
        LabelName = new javax.swing.JLabel();
        TextFieldName = new javax.swing.JTextField();
        LabelUsername = new javax.swing.JLabel();
        TextFieldUsername = new javax.swing.JTextField();
        LabelPasswords = new javax.swing.JLabel();
        TextFieldPassword = new javax.swing.JTextField();
        LabelType = new javax.swing.JLabel();
        ComboBoxType = new javax.swing.JComboBox<>();
        ButtonSave = new javax.swing.JButton();
        ButtonCancel = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(51, 255, 204));

        LabelEditUser.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelEditUser.setText("Edit User");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(LabelEditUser, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(274, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LabelEditUser, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        LabelName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelName.setText("Name:");

        TextFieldName.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        TextFieldName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldNameActionPerformed(evt);
            }
        });

        LabelUsername.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelUsername.setText("Username:");

        TextFieldUsername.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        TextFieldUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldUsernameActionPerformed(evt);
            }
        });

        LabelPasswords.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelPasswords.setText("Password:");

        TextFieldPassword.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        TextFieldPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldPasswordActionPerformed(evt);
            }
        });

        LabelType.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelType.setText("User Type");

        ComboBoxType.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ComboBoxType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Admin", "Staff" }));
        ComboBoxType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxTypeActionPerformed(evt);
            }
        });

        ButtonSave.setBackground(new java.awt.Color(0, 255, 0));
        ButtonSave.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonSave.setText("Save");
        ButtonSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonSaveActionPerformed(evt);
            }
        });

        ButtonCancel.setBackground(new java.awt.Color(255, 0, 0));
        ButtonCancel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonCancel.setForeground(new java.awt.Color(255, 255, 255));
        ButtonCancel.setText("Cancel");
        ButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LabelType)
                    .addComponent(LabelPasswords)
                    .addComponent(LabelName)
                    .addComponent(LabelUsername)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(ComboBoxType, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextFieldPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextFieldName, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextFieldUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(127, 127, 127)
                    .addComponent(ButtonSave)
                    .addGap(18, 18, 18)
                    .addComponent(ButtonCancel)
                    .addContainerGap(122, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(LabelName)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldName, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(LabelUsername)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(LabelPasswords)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(LabelType)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ComboBoxType, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 70, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap(482, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ButtonSave)
                        .addComponent(ButtonCancel))
                    .addGap(17, 17, 17)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void TextFieldNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldNameActionPerformed

    }//GEN-LAST:event_TextFieldNameActionPerformed

    private void TextFieldUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldUsernameActionPerformed

    }//GEN-LAST:event_TextFieldUsernameActionPerformed

    private void TextFieldPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldPasswordActionPerformed

    }//GEN-LAST:event_TextFieldPasswordActionPerformed

    private void ComboBoxTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxTypeActionPerformed

    }//GEN-LAST:event_ComboBoxTypeActionPerformed

    private void ButtonSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonSaveActionPerformed
        String name = TextFieldName.getText().trim();
    String username = TextFieldUsername.getText().trim();
    String password = TextFieldPassword.getText().trim();
    String selectedType = (String) ComboBoxType.getSelectedItem();
    
    // Validation
    if (name.isEmpty() || username.isEmpty() || password.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Validation Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    // Convert user type to integer (1 for Admin, 2 for Staff)
    int userType = selectedType.equals("Admin") ? 1 : 2;
    
    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_user_database", "root", "");
        
        // Let's first check what columns exist in your table
        String checkTableSQL = "DESCRIBE user";
        PreparedStatement checkStmt = con.prepareStatement(checkTableSQL);
        ResultSet rs = checkStmt.executeQuery();
        
        System.out.println("Table structure:");
        while (rs.next()) {
            System.out.println("Column: " + rs.getString("Field") + ", Type: " + rs.getString("Type"));
        }
        
        // Use backticks around column names in case any are reserved words
        String sql = "INSERT INTO `user` (`full_name`, `email`, `password`, `type`) VALUES (?, ?, ?, ?)";
        PreparedStatement pst = con.prepareStatement(sql);
        
        pst.setString(1, name);
        pst.setString(2, username);
        pst.setString(3, password);
        pst.setInt(4, userType);
        
        // Debug: Print the SQL and values
        System.out.println("Executing SQL: " + sql);
        System.out.println("Values: " + name + ", " + username + ", " + password + ", " + userType);
        
        int result = pst.executeUpdate();
        
        if (result > 0) {
            JOptionPane.showMessageDialog(this, "User added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            
            // Clear the form
            TextFieldName.setText("");
            TextFieldUsername.setText("");
            TextFieldPassword.setText("");
            ComboBoxType.setSelectedIndex(0);
            
            // Close the dialog
            JDialog dialog = (JDialog) SwingUtilities.getWindowAncestor(this);
            if (dialog != null) {
                dialog.dispose();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add user.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        con.close();
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    }//GEN-LAST:event_ButtonSaveActionPerformed

    private void ButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonCancelActionPerformed
     // Close the dialog without saving
        JDialog dialog = (JDialog) SwingUtilities.getWindowAncestor(this);
        if (dialog != null) {
            dialog.dispose();
        }
    }//GEN-LAST:event_ButtonCancelActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonCancel;
    private javax.swing.JButton ButtonSave;
    private javax.swing.JComboBox<String> ComboBoxType;
    private javax.swing.JLabel LabelEditUser;
    private javax.swing.JLabel LabelName;
    private javax.swing.JLabel LabelPasswords;
    private javax.swing.JLabel LabelType;
    private javax.swing.JLabel LabelUsername;
    private javax.swing.JTextField TextFieldName;
    private javax.swing.JTextField TextFieldPassword;
    private javax.swing.JTextField TextFieldUsername;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
