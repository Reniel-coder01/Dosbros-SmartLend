package Function;
import java.sql.*;
import javax.swing.*;

public class EditFunction extends javax.swing.JPanel {
    
    private int currentUserId;
    
    public EditFunction(int userId, String fullName, String email, int type) {
        initComponents();
        this.currentUserId = userId;
        populateFields(userId, fullName, email, type);
        loadUserPassword(userId);
    }
    
    private void populateFields(int userId, String fullName, String email, int type) {
        TextFieldName.setText(fullName);
        TextFieldUsername.setText(email);
        ComboBoxType.setSelectedIndex(type == 1 ? 0 : 1);
    }
    
    private void loadUserPassword(int userId) {
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_user_database", "root", "");
            PreparedStatement ps = con.prepareStatement("SELECT password FROM user WHERE id = ?");
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                TextFieldPassword.setText(rs.getString("password"));
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void saveUserChanges() {
        try {
            String name = TextFieldName.getText().trim();
            String email = TextFieldUsername.getText().trim();
            String password = TextFieldPassword.getText().trim();
            
            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                return;
            }
            
            int type = ComboBoxType.getSelectedIndex() == 0 ? 1 : 2;
            
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_user_database", "root", "");
            PreparedStatement ps = con.prepareStatement(
                "UPDATE user SET full_name = ?, email = ?, password = ?, type = ? WHERE id = ?"
            );
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setInt(4, type);
            ps.setInt(5, currentUserId);
            
            ps.executeUpdate();
            con.close();
            
            SwingUtilities.getWindowAncestor(this).dispose();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        LabelEditUser = new javax.swing.JLabel();
        LabelName = new javax.swing.JLabel();
        TextFieldUsername = new javax.swing.JTextField();
        LabelPasswords = new javax.swing.JLabel();
        TextFieldName = new javax.swing.JTextField();
        LabelUsername = new javax.swing.JLabel();
        LabelType = new javax.swing.JLabel();
        TextFieldPassword = new javax.swing.JTextField();
        ComboBoxType = new javax.swing.JComboBox<>();
        ButtonSave = new javax.swing.JButton();
        ButtonCancel = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(51, 255, 204));

        LabelEditUser.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelEditUser.setText("New User");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(LabelEditUser, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LabelEditUser, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        LabelName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelName.setText("Name:");

        TextFieldUsername.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        TextFieldUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldUsernameActionPerformed(evt);
            }
        });

        LabelPasswords.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelPasswords.setText("Password:");

        TextFieldName.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        TextFieldName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldNameActionPerformed(evt);
            }
        });

        LabelUsername.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelUsername.setText("Username:");

        LabelType.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelType.setText("User Type");

        TextFieldPassword.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        TextFieldPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldPasswordActionPerformed(evt);
            }
        });

        ComboBoxType.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ComboBoxType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Admin", "Staff" }));
        ComboBoxType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxTypeActionPerformed(evt);
            }
        });

        ButtonSave.setBackground(new java.awt.Color(0, 255, 0));
        ButtonSave.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonSave.setText("Save");
        ButtonSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonSaveActionPerformed(evt);
            }
        });

        ButtonCancel.setBackground(new java.awt.Color(255, 0, 0));
        ButtonCancel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonCancel.setForeground(new java.awt.Color(255, 255, 255));
        ButtonCancel.setText("Cancel");
        ButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelType)
                            .addComponent(LabelPasswords)
                            .addComponent(LabelName)
                            .addComponent(LabelUsername)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(ComboBoxType, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TextFieldPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TextFieldName, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TextFieldUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(ButtonSave)
                        .addGap(18, 18, 18)
                        .addComponent(ButtonCancel)))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(LabelName)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldName, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(LabelUsername)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(LabelPasswords)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(LabelType)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ComboBoxType, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ButtonSave)
                    .addComponent(ButtonCancel))
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void TextFieldUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldUsernameActionPerformed
   
    }//GEN-LAST:event_TextFieldUsernameActionPerformed

    private void TextFieldPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldPasswordActionPerformed
      
    }//GEN-LAST:event_TextFieldPasswordActionPerformed

    private void ComboBoxTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxTypeActionPerformed
      
    }//GEN-LAST:event_ComboBoxTypeActionPerformed

    private void TextFieldNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldNameActionPerformed
       
    }//GEN-LAST:event_TextFieldNameActionPerformed

    private void ButtonSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonSaveActionPerformed
         saveUserChanges();
    }//GEN-LAST:event_ButtonSaveActionPerformed

    private void ButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonCancelActionPerformed
         SwingUtilities.getWindowAncestor(this).dispose();
    }//GEN-LAST:event_ButtonCancelActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonCancel;
    private javax.swing.JButton ButtonSave;
    private javax.swing.JComboBox<String> ComboBoxType;
    private javax.swing.JLabel LabelEditUser;
    private javax.swing.JLabel LabelName;
    private javax.swing.JLabel LabelPasswords;
    private javax.swing.JLabel LabelType;
    private javax.swing.JLabel LabelUsername;
    private javax.swing.JTextField TextFieldName;
    private javax.swing.JTextField TextFieldPassword;
    private javax.swing.JTextField TextFieldUsername;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
