package Function;

import javax.swing.*;
import java.sql.*;

public class DeleteLenders extends javax.swing.JPanel {
    private int id;
    private boolean isLender;
    
    // Existing constructor for lenders (backward compatible)
    public DeleteLenders(int id) {
        this(id, true); // Default to lender mode
    }
    
    // New constructor for loans/lenders
    public DeleteLenders(int id, boolean isLender) {
        this.id = id;
        this.isLender = isLender;
        initComponents();
        updateLabels();
    }
    
    private void updateLabels() {
        String type = isLender ? "Lender" : "Loan";
        LabelConfirmation.setText("Delete " + type + " Confirmation");
        LabelQuestionConfirmation.setText("Are you sure you want to delete this " + type + "?");
    }
    
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/java_user_database", 
            "root", 
            ""
        );
    }
    
    // Unified deletion method
    private void deleteRecord() {
        String table = isLender ? "borrowers" : "loan_list";
        String type = isLender ? "Lender" : "Loan";
        
        try (Connection conn = getConnection()) {
            String sql = "DELETE FROM " + table + " WHERE id = ?";
            try (PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setInt(1, id);
                
                if (pst.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(this, 
                        type + " deleted successfully!");
                    closeDialog();
                } else {
                    JOptionPane.showMessageDialog(this,
                        "Failed to delete " + type.toLowerCase(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Database error: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Static method for direct loan deletion (no UI)
    public static boolean deleteLoanDirectly(int loanId) {
        try (Connection conn = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/java_user_database", 
            "root", 
            "")) {
            
            String sql = "DELETE FROM loan_list WHERE id = ?";
            try (PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setInt(1, loanId);
                return pst.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,
                "Error deleting loan: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private void closeDialog() {
        SwingUtilities.getWindowAncestor(this).dispose();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        LabelConfirmation = new javax.swing.JLabel();
        LabelQuestionConfirmation = new javax.swing.JLabel();
        ButtonContinue = new javax.swing.JButton();
        ButtonCancel = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(51, 255, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        LabelConfirmation.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        LabelConfirmation.setText("Confirmation");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(LabelConfirmation)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(LabelConfirmation)
                .addGap(14, 14, 14))
        );

        LabelQuestionConfirmation.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelQuestionConfirmation.setText("Are you sure to delete this Lender?");

        ButtonContinue.setBackground(new java.awt.Color(0, 255, 0));
        ButtonContinue.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonContinue.setText("Continue");
        ButtonContinue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonContinueActionPerformed(evt);
            }
        });

        ButtonCancel.setBackground(new java.awt.Color(255, 0, 0));
        ButtonCancel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonCancel.setForeground(new java.awt.Color(255, 255, 255));
        ButtonCancel.setText("Cancel");
        ButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ButtonContinue)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ButtonCancel)
                .addGap(20, 20, 20))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(LabelQuestionConfirmation)
                .addContainerGap(133, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addComponent(LabelQuestionConfirmation)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ButtonCancel)
                    .addComponent(ButtonContinue))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonContinueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonContinueActionPerformed
     deleteRecord();
    }//GEN-LAST:event_ButtonContinueActionPerformed

    private void ButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonCancelActionPerformed
        closeDialog();
    }//GEN-LAST:event_ButtonCancelActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonCancel;
    private javax.swing.JButton ButtonContinue;
    private javax.swing.JLabel LabelConfirmation;
    private javax.swing.JLabel LabelQuestionConfirmation;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
