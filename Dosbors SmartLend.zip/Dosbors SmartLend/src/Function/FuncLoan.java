package Function;

import javax.swing.*;
import java.awt.*;

public class FuncLoan extends JFrame {
    private JTextField borrowerField, loanAmountField, interestRateField, loanTermField;
    private JTextArea resultArea;

    public FuncLoan() {
        setTitle("Loan Calculator");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 2));

        add(new JLabel("Borrower Name:"));
        borrowerField = new JTextField();
        add(borrowerField);

        add(new JLabel("Loan Amount:"));
        loanAmountField = new JTextField();
        add(loanAmountField);

        add(new JLabel("Interest Rate (%):"));
        interestRateField = new JTextField();
        add(interestRateField);

        add(new JLabel("Loan Term (months):"));
        loanTermField = new JTextField();
        add(loanTermField);

        JButton calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(e -> calculateLoan());
        add(calculateButton);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        add(new JScrollPane(resultArea));

        setVisible(true);
    }

    private void calculateLoan() {
        try {
            String borrowerName = borrowerField.getText();
            double loanAmount = Double.parseDouble(loanAmountField.getText());
            double interestRate = Double.parseDouble(interestRateField.getText());
            int loanTerm = Integer.parseInt(loanTermField.getText());

            double monthlyRate = interestRate / 12 / 100;
            double monthlyPayment = (loanAmount * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -loanTerm));

            resultArea.setText("Borrower: " + borrowerName + "\n" +
                               "Loan Amount: " + loanAmount + "\n" +
                               "Interest Rate: " + interestRate + "%\n" +
                               "Loan Term: " + loanTerm + " months\n" +
                               "Monthly Payment: " + monthlyPayment);
        } catch (NumberFormatException ex) {
            resultArea.setText("Please enter valid numeric values.");
        }
    }

    
}
