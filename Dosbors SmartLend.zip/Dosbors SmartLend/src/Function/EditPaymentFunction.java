package Function;

import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import javax.swing.JOptionPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.BorderLayout;
import java.awt.print.PrinterJob;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import java.text.SimpleDateFormat;
import java.sql.Timestamp;

public class EditPaymentFunction extends javax.swing.JPanel {
    private int paymentId;
    private int loanId;
    private double originalLoanAmount;
    private double remainingAmount;
    private Date dateReleased;
    private int planMonths;
    private double interestRate;
    private int penaltyRate;
    private String borrowerName;

    public EditPaymentFunction(int paymentId) {
        initComponents();
        this.paymentId = paymentId;

        // Setup document listener for real-time updates
        TextFieldAmount.getDocument().addDocumentListener(new DocumentListener() {
            private boolean updating = false;

            @Override
            public void insertUpdate(DocumentEvent e) { updatePayable(); }

            @Override
            public void removeUpdate(DocumentEvent e) { updatePayable(); }

            @Override
            public void changedUpdate(DocumentEvent e) { updatePayable(); }

            private void updatePayable() {
                if (updating) return;
                updating = true;
                try {
                    double amount = TextFieldAmount.getText().isEmpty() ? 0 :
                        Double.parseDouble(TextFieldAmount.getText());
                    double total = Double.parseDouble(TotalMonthlyAmount.getText());
                    PayableAmount.setText(String.format("%.2f", Math.max(0, total - amount)));
                } catch (Exception ex) {
                    PayableAmount.setText("0.00");
                } finally {
                    updating = false;
                }
            }
        });

        loadPaymentData();
        calculatePenalty();
    }

    private void loadPaymentData() {
        try (Connection conn = getConnection()) {
            String paymentQuery = "SELECT p.*, l.amount as loan_amount, l.date_released, "
                    + "lp.months, lp.interest_percentage, lp.penalty_rate, "
                    + "CONCAT(b.firstname, ' ', b.lastname) as borrower_name, "
                    + "b.tax_id, l.id as loan_id "
                    + "FROM payments p "
                    + "JOIN loan_list l ON p.loan_id = l.id "
                    + "JOIN loan_plan lp ON l.plan_id = lp.id "
                    + "JOIN borrowers b ON l.borrower_id = b.id "
                    + "WHERE p.id = ?";

            try (PreparedStatement stmt = conn.prepareStatement(paymentQuery)) {
                stmt.setInt(1, paymentId);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    loanId = rs.getInt("loan_id");
                    originalLoanAmount = rs.getDouble("loan_amount");
                    remainingAmount = rs.getDouble("loan_amount"); // Initialize with full amount
                    dateReleased = rs.getDate("date_released");
                    planMonths = rs.getInt("months");
                    interestRate = rs.getDouble("interest_percentage");
                    penaltyRate = rs.getInt("penalty_rate");
                    borrowerName = rs.getString("borrower_name");
                    String taxId = rs.getString("tax_id");
                    double paymentAmount = rs.getDouble("amount");

                    // Update UI components
                    TextFieldPayee.setEditable(false);
                    TextFieldPayee.setText(borrowerName + "\nTax ID: " + taxId);
                    TextFieldAmount.setText(String.format("%.2f", paymentAmount));
                    TotalMonthlyAmount.setText(String.format("%.2f", originalLoanAmount));
                    PayableAmount.setText(String.format("%.2f", paymentAmount));

                    // Get actual remaining amount from database
                    remainingAmount = getRemainingLoanAmount(conn, loanId);
                }
            }
        } catch (SQLException e) {
            handleDatabaseError(e, "Error loading payment data");
        }
    }

    private double getRemainingLoanAmount(Connection conn, int loanId) throws SQLException {
        String query = "SELECT amount FROM loan_list WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, loanId);
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getDouble("amount") : 0;
        }
    }

    private void calculatePenalty() {
        if (dateReleased == null) return;

        try (Connection conn = getConnection()) {
            LocalDate releaseDate = dateReleased.toLocalDate();
            LocalDate today = LocalDate.now();
            long daysSinceRelease = ChronoUnit.DAYS.between(releaseDate, today);
            int expectedPayments = (int) (daysSinceRelease / 30);
            int actualPayments = getPaymentCount(conn);
            int missedPayments = Math.max(0, expectedPayments - actualPayments);

            if (missedPayments > 0) {
                double penaltyAmount = remainingAmount * (penaltyRate / 100.0) * missedPayments;
                double dailyInterest = remainingAmount * (0.3 / 100.0) * daysSinceRelease;
                Penalty.setText(String.format("%.2f", penaltyAmount + dailyInterest));
            } else {
                Penalty.setText("0.00");
            }
        } catch (SQLException e) {
            handleDatabaseError(e, "Error getting payment count");
        }
    }

    // Updated: Use Connection parameter for accurate payment count on current DB transaction
    private int getPaymentCount(Connection conn) {
        try {
            String query = "SELECT COUNT(*) as count FROM payments WHERE loan_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setInt(1, loanId);
                ResultSet rs = stmt.executeQuery();
                return rs.next() ? rs.getInt("count") : 0;
            }
        } catch (SQLException e) {
            handleDatabaseError(e, "Error getting payment count");
            return 0;
        }
    }

    private int getRemainingMonthsFromDb(Connection conn) throws SQLException {
        String sql = "SELECT remaining_months FROM loan_list WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, loanId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("remaining_months");
        }
        return 0;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        LabelEditPayment = new javax.swing.JLabel();
        LabelPayee = new javax.swing.JLabel();
        LabelAmount = new javax.swing.JLabel();
        TextFieldAmount = new javax.swing.JTextField();
        LabelTotalMonthlyAmount = new javax.swing.JLabel();
        LabelPenalty = new javax.swing.JLabel();
        LabelPayableAmount = new javax.swing.JLabel();
        TotalMonthlyAmount = new javax.swing.JLabel();
        Penalty = new javax.swing.JLabel();
        PayableAmount = new javax.swing.JLabel();
        ButtonUpdate = new javax.swing.JButton();
        ButtonCancel = new javax.swing.JButton();
        TextFieldPayee = new javax.swing.JTextField();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(51, 255, 204));

        LabelEditPayment.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelEditPayment.setText("Edit Payment");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(LabelEditPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(529, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LabelEditPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        LabelPayee.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        LabelPayee.setText("Payee");

        LabelAmount.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        LabelAmount.setText("Amount");

        LabelTotalMonthlyAmount.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        LabelTotalMonthlyAmount.setText("Total Payable Amount");

        LabelPenalty.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        LabelPenalty.setText("Penalty:");

        LabelPayableAmount.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        LabelPayableAmount.setText("Payable Amount:");

        TotalMonthlyAmount.setText("0.0");

        Penalty.setText("0.0");

        PayableAmount.setText("0.0");

        ButtonUpdate.setBackground(new java.awt.Color(0, 255, 0));
        ButtonUpdate.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonUpdate.setText("Update");
        ButtonUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonUpdateActionPerformed(evt);
            }
        });

        ButtonCancel.setBackground(new java.awt.Color(255, 0, 0));
        ButtonCancel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonCancel.setForeground(new java.awt.Color(255, 255, 255));
        ButtonCancel.setText("Cancel");
        ButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(LabelAmount)
                    .addComponent(LabelPayee)
                    .addComponent(TextFieldAmount, javax.swing.GroupLayout.DEFAULT_SIZE, 255, Short.MAX_VALUE)
                    .addComponent(TextFieldPayee))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelTotalMonthlyAmount)
                            .addComponent(LabelPayableAmount)
                            .addComponent(LabelPenalty, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(62, 62, 62)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(TotalMonthlyAmount, javax.swing.GroupLayout.DEFAULT_SIZE, 143, Short.MAX_VALUE)
                            .addComponent(Penalty, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(PayableAmount, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ButtonUpdate)
                        .addGap(18, 18, 18)
                        .addComponent(ButtonCancel)
                        .addGap(20, 20, 20))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(LabelPayee)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelTotalMonthlyAmount)
                    .addComponent(TotalMonthlyAmount)
                    .addComponent(TextFieldPayee, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(LabelPenalty)
                            .addComponent(Penalty))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(PayableAmount)
                            .addComponent(LabelPayableAmount)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(LabelAmount)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TextFieldAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ButtonUpdate)
                    .addComponent(ButtonCancel))
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonUpdateActionPerformed
        try {
            double paymentAmount = Double.parseDouble(TextFieldAmount.getText());
            double penaltyAmount = Double.parseDouble(Penalty.getText());
            String payeeName = TextFieldPayee.getText().split("\n")[0];

            if (paymentAmount <= 0) {
                JOptionPane.showMessageDialog(this, "Payment amount must be positive",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try (Connection conn = getConnection()) {
                conn.setAutoCommit(false);

                try {
                    // Get current remaining amount
                    double currentRemaining = getRemainingLoanAmount(conn, loanId);

                    // Adjust payment if it exceeds remaining
                    paymentAmount = Math.min(paymentAmount, currentRemaining);

                    // Update payment record
                    updatePayment(conn, paymentAmount, penaltyAmount, payeeName);

                    // Update loan amount
                    updateLoan(conn, paymentAmount);

                    // Get updated remaining amount
                    double newRemaining = getRemainingLoanAmount(conn, loanId);

                    // Check if loan is fully paid
                    if (newRemaining <= 0) {
                        completeLoan(conn); // Update status to completed
                    }

                    conn.commit();

                    // Only show the receipt dialog (no more transaction details dialog)
                    generateAndShowReceipt(conn, paymentAmount, penaltyAmount);

                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for amount",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            handleDatabaseError(e, "Error updating payment");
        }
    }//GEN-LAST:event_ButtonUpdateActionPerformed

    private void generateAndShowReceipt(Connection conn, double paymentAmount, double penaltyAmount) throws SQLException {
        // Get all necessary data for receipt
        String query = "SELECT p.*, b.firstname, b.middlename, b.lastname, b.contact_no, " +
                "b.address, b.email, b.tax_id, l.ref_no, l.purpose, lt.type_name, " +
                "p.date_created, p.reference_number " +
                "FROM payments p " +
                "JOIN loan_list l ON p.loan_id = l.id " +
                "JOIN borrowers b ON l.borrower_id = b.id " +
                "JOIN loan_types lt ON l.loan_type_id = lt.id " +
                "WHERE p.id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, paymentId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Get data from database
                String receiptNumber = rs.getString("reference_number");
                Timestamp paymentTimestamp = rs.getTimestamp("date_created");
                Date paymentDate = new Date(paymentTimestamp.getTime()); // Convert to java.util.Date
                String lenderName = rs.getString("firstname") + " " +
                        (rs.getString("middlename") != null ? rs.getString("middlename") + " " : "") +
                        rs.getString("lastname");
                String contact = rs.getString("contact_no");
                String address = rs.getString("address");
                String email = rs.getString("email");
                String taxId = rs.getString("tax_id");
                String loanAccount = rs.getString("ref_no");
                String loanType = rs.getString("type_name");
                String loanPurpose = rs.getString("purpose");

                // Calculate values for receipt - or you can skip calculation and just show payment amount, penalty, etc.
                double principal = paymentAmount * 0.64; // You can skip these if you want to show only paymentAmount.
                double interest = paymentAmount * 0.36;  // You can skip these if you want to show only paymentAmount.
                double total = paymentAmount + penaltyAmount;
                double updatedBalance = getRemainingLoanAmount(conn, loanId);

                // Fetch the new remaining_months value from the database (real-time)
                int remainingMonths = getRemainingMonthsFromDb(conn);

                // Format date
                String formattedDate = new SimpleDateFormat("MMMM d, yyyy HH:mm:ss").format(paymentDate);

                // Build receipt (you can remove principal/interest if not needed)
                String receipt = buildReceipt(
                        receiptNumber, formattedDate, lenderName, contact, address,
                        email, taxId, loanAccount, loanType, loanPurpose,
                        principal, interest, penaltyAmount, total, updatedBalance, remainingMonths
                );

                // Show receipt dialog
                showReceiptDialog(receipt);
            }
        }
    }

    private String buildReceipt(String receiptNumber, String date, String lenderName,
                             String contact, String address, String email, String taxId,
                             String loanAccount, String loanType, String loanPurpose,
                             double principal, double interest, double penalty,
                             double total, double updatedBalance, int remainingMonths) {
        return String.format("""
            ==========================================
                      LEND PAYMENT RECEIPT
            ==========================================
            Receipt Number: %s
            Date of Payment: %s

            Lender Details:
            Name: %s
            Contact: %s
            Address: %s
            Email: %s
            Tax ID: %s

            Loan Account Number: %s
            Loan Type: %s
            Loan Purpose: %s

            Payment Details:
            ------------------------------------------
            Principal Amount: PHP %.2f
            Interest Amount: PHP %.2f
            Penalty Amount: PHP %.2f
            ------------------------------------------
            Total Amount Paid: PHP %.2f

            Updated Balance: PHP %.2f
            Remaining Months to Pay: %d
            ==========================================
                      THANK YOU FOR YOUR PAYMENT
            ==========================================
            """,
            receiptNumber, date, lenderName, contact, address, email, taxId,
            loanAccount, loanType, loanPurpose, principal, interest, penalty,
            total, updatedBalance, remainingMonths);
    }

    private void showReceiptDialog(String receipt) {
        JTextArea textArea = new JTextArea(receipt);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        textArea.setEditable(false);

        JButton printButton = new JButton("Print Receipt");
        printButton.addActionListener(e -> printReceipt(textArea));

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
        panel.add(printButton, BorderLayout.SOUTH);

        JOptionPane.showMessageDialog(this, panel, "Payment Receipt", JOptionPane.PLAIN_MESSAGE);
    }

    private void printReceipt(JTextArea textArea) {
        try {
            PrinterJob job = PrinterJob.getPrinterJob();
            job.setJobName("Loan Payment Receipt");

            job.setPrintable((graphics, pageFormat, pageIndex) -> {
                if (pageIndex > 0) {
                    return Printable.NO_SUCH_PAGE;
                }

                Graphics2D g2d = (Graphics2D) graphics;
                g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

                String[] lines = textArea.getText().split("\n");
                int y = 50;
                for (String line : lines) {
                    g2d.drawString(line, 50, y);
                    y += 15;
                }

                return Printable.PAGE_EXISTS;
            });

            if (job.printDialog()) {
                job.print();
            }
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(this, "Printing error: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void completeLoan(Connection conn) throws SQLException {
        // Update loan status to completed
        String sql = "UPDATE loan_list SET status=3 WHERE id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, loanId);
            stmt.executeUpdate();
        }
    }

    private void updatePayment(Connection conn, double amount, double penalty, String payee) throws SQLException {
        String sql = "UPDATE payments SET amount=?, penalty_amount=?, payee=? WHERE id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDouble(1, amount);
            stmt.setDouble(2, penalty);
            stmt.setString(3, payee);
            stmt.setInt(4, paymentId);
            stmt.executeUpdate();
        }
    }

    private void updateLoan(Connection conn, double amount) throws SQLException {
        // First update the amount
        String sql = "UPDATE loan_list SET amount=GREATEST(0, amount-?) WHERE id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDouble(1, amount);
            stmt.setInt(2, loanId);
            stmt.executeUpdate();
        }

        // Then check if amount is zero and update status if needed
        double newAmount = getRemainingLoanAmount(conn, loanId);
        if (newAmount <= 0) {
            String statusSql = "UPDATE loan_list SET status=3 WHERE id=? AND status != 3";
            try (PreparedStatement statusStmt = conn.prepareStatement(statusSql)) {
                statusStmt.setInt(1, loanId);
                statusStmt.executeUpdate();
            }
        }
    }

    private double getTotalPaidAmount(Connection conn) throws SQLException {
        String query = "SELECT SUM(amount) as total FROM payments WHERE loan_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, loanId);
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getDouble("total") : 0;
        }
    }

    private void ButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {
        java.awt.Window window = javax.swing.SwingUtilities.getWindowAncestor(this);
        if (window != null) {
            window.dispose();
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonCancel;
    private javax.swing.JButton ButtonUpdate;
    private javax.swing.JLabel LabelAmount;
    private javax.swing.JLabel LabelEditPayment;
    private javax.swing.JLabel LabelPayableAmount;
    private javax.swing.JLabel LabelPayee;
    private javax.swing.JLabel LabelPenalty;
    private javax.swing.JLabel LabelTotalMonthlyAmount;
    private javax.swing.JLabel PayableAmount;
    private javax.swing.JLabel Penalty;
    private javax.swing.JTextField TextFieldAmount;
    private javax.swing.JTextField TextFieldPayee;
    private javax.swing.JLabel TotalMonthlyAmount;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/java_user_database",
            "root",
            "");
    }

    private void handleDatabaseError(SQLException e, String message) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this,
            message + ": " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE);
    }
}