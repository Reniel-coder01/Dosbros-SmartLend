package Function;

import javax.swing.*;
import java.awt.*;

public class TextField extends JPanel {
    private JTextField textField;
    private JLabel iconLabel;
    
    public TextField() {
        this("%");
    }
    
    public TextField(String iconText) {
        setLayout(new BorderLayout());
        
        // Create components
        textField = new JTextField();
        iconLabel = new JLabel(iconText);
        
        // Style the icon label
        iconLabel.setOpaque(true);
        iconLabel.setBackground(new Color(230, 230, 230));
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        iconLabel.setPreferredSize(new Dimension(30, 25));
        iconLabel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        
        // Add components
        add(textField, BorderLayout.CENTER);
        add(iconLabel, BorderLayout.EAST);
    }
    
    public String getText() {
        return textField.getText();
    }
    
    public void setText(String text) {
        textField.setText(text);
    }
    
    public JTextField getTextField() {
        return textField;
    }
    
    // Simple demo
    public static void main(String[] args) {
        JFrame frame = new JFrame("TextField with Icon");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel(new GridLayout(3, 1, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        panel.add(new TextField("%"));
        panel.add(new TextField("$"));
        panel.add(new TextField("€"));
        
        frame.add(panel);
        frame.pack();
        frame.setSize(300, 150);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
