package Function;

import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import javax.swing.BorderFactory;
import java.util.Date;
import java.text.NumberFormat;
import java.util.Locale;
import java.awt.Window;

public class NewPayment extends javax.swing.JPanel {
    private Connection connection;
    private static final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("en", "PH"));
    private boolean paymentSuccess = false;

    public NewPayment() {
        initComponents();
        initializeDatabase();
        setupComboBoxPayee();
        loadPayees();
    }

    private void initializeDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/java_user_database",
                "root",
                ""
            );
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Database connection failed: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void setupComboBoxPayee() {
        ComboBoxPayee.removeAllItems();
        ComboBoxPayee.addItem("Select Payee...");
        ComboBoxPayee.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
    }

    private void loadPayees() {
        try {
            String sql = "SELECT DISTINCT b.id, b.firstname, b.middlename, b.lastname, b.tax_id " +
                    "FROM borrowers b " +
                    "JOIN loan_list l ON b.id = l.borrower_id " +
                    "LEFT JOIN payments p ON l.id = p.loan_id " +
                    "WHERE l.status = 2 " + // Only released loans
                    "AND p.id IS NULL " +  // No payments exist yet
                    "ORDER BY b.lastname, b.firstname";

            PreparedStatement pst = connection.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            ComboBoxPayee.removeAllItems();
            ComboBoxPayee.addItem("Select Payee...");

            while (rs.next()) {
                String fullName = String.format("%s, %s %s",
                        rs.getString("lastname"),
                        rs.getString("firstname"),
                        rs.getString("middlename") != null ? rs.getString("middlename") : ""
                ).trim();

                String taxId = rs.getString("tax_id") != null ? rs.getString("tax_id") : "N/A";

                String displayText = String.format(
                        "<html>" +
                                "<div style='border-top: 1px solid #ccc; border-bottom: 1px solid #ccc; padding: 5px;'>" +
                                "%s<br>Tax ID: %s" +
                                "</div>" +
                                "</html>",
                        fullName, taxId
                );

                ComboBoxPayee.addItem(displayText);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading payees: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private int getSelectedPayeeId() {
        String selected = (String) ComboBoxPayee.getSelectedItem();
        if (selected == null || selected.startsWith("Select")) {
            return -1;
        }
        return getBorrowerIdByDisplay(selected);
    }

    private int getBorrowerIdByDisplay(String displayText) {
        try {
            String cleanText = displayText.replaceAll("<[^>]*>", "").trim();
            int taxIdIndex = cleanText.indexOf("Tax ID: ");
            if (taxIdIndex == -1) return -1;

            String taxId = cleanText.substring(taxIdIndex + 8).trim();

            String sql = "SELECT id FROM borrowers WHERE tax_id = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, taxId);
            ResultSet rs = pst.executeQuery();

            return rs.next() ? rs.getInt("id") : -1;
        } catch (Exception e) {
            return -1;
        }
    }

    private int getLoanIdForBorrower(int borrowerId) throws SQLException {
        String sql = "SELECT id FROM loan_list WHERE borrower_id = ? AND status IN (2,3) LIMIT 1";
        PreparedStatement pst = connection.prepareStatement(sql);
        pst.setInt(1, borrowerId);
        ResultSet rs = pst.executeQuery();
        return rs.next() ? rs.getInt("id") : -1;
    }

    // Always use total_payable, not amount. Calculate monthly payment from total_payable/term
    private LoanDetails getLoanDetails(int loanId) throws SQLException {
        LoanDetails details = new LoanDetails();

        String loanSql = "SELECT l.total_payable, l.date_released, lp.months, lp.interest_percentage, lp.penalty_rate " +
                "FROM loan_list l JOIN loan_plan lp ON l.plan_id = lp.id " +
                "WHERE l.id = ?";
        PreparedStatement loanPst = connection.prepareStatement(loanSql);
        loanPst.setInt(1, loanId);
        ResultSet loanRs = loanPst.executeQuery();

        if (loanRs.next()) {
            details.totalPayable = loanRs.getDouble("total_payable");
            details.dateReleased = loanRs.getTimestamp("date_released");
            details.months = loanRs.getInt("months");
            details.interestRate = loanRs.getDouble("interest_percentage");
            details.penaltyRate = loanRs.getDouble("penalty_rate");

            details.nextPaymentAmount = details.totalPayable / details.months;
            details.penaltyPerMissed = details.nextPaymentAmount * (details.penaltyRate / 100.0);
        }
        return details;
    }

    // Only calculate penalty if borrower missed payment for 30 days
    private double calculatePenalty(int loanId, LoanDetails loanDetails) throws SQLException {
        double penalty = 0.0;

        // Find the earliest unpaid and overdue schedule more than 30 days
        String overdueSql = "SELECT id, due_date, total_amount, DATEDIFF(CURDATE(), due_date) as days_overdue, " +
                "status, payment_date, total_amount - remaining_amount as paid_amount " +
                "FROM loan_schedules " +
                "WHERE loan_id = ? AND status < 2 AND due_date < CURDATE() " +
                "ORDER BY due_date ASC LIMIT 1";

        PreparedStatement overduePst = connection.prepareStatement(overdueSql);
        overduePst.setInt(1, loanId);
        ResultSet overdueRs = overduePst.executeQuery();

        if (overdueRs.next()) {
            int daysOverdue = overdueRs.getInt("days_overdue");
            double scheduleAmount = overdueRs.getDouble("total_amount");
            int status = overdueRs.getInt("status");
            Date paymentDate = overdueRs.getDate("payment_date");
            double paidAmount = scheduleAmount - overdueRs.getDouble("remaining_amount");

            // Only apply penalty if not paid, not partially paid, and overdue >= 30 days
            if (status == 0 && paymentDate == null && paidAmount == 0 && daysOverdue >= 30) {
                penalty = loanDetails.penaltyPerMissed;
            }
        }

        return penalty;
    }

    private void processPayment() {
        int payeeId = getSelectedPayeeId();

        if (payeeId <= 0) {
            JOptionPane.showMessageDialog(this,
                    "Please select a valid payee",
                    "Error",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int loanId = getLoanIdForBorrower(payeeId);
            if (loanId == -1) {
                JOptionPane.showMessageDialog(this,
                        "No active loan found for selected payee",
                        "Error",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            LoanDetails loanDetails = getLoanDetails(loanId);
            String payeeName = getPayeeName(payeeId);
            double penaltyAmount = calculatePenalty(loanId, loanDetails);
            double paymentAmount = loanDetails.nextPaymentAmount;
            double totalPayment = paymentAmount + penaltyAmount;

            // Show confirmation dialog
            String message = String.format(
                    "<html><div style='width: 300px;'>" +
                            "<h3>Payment Confirmation</h3>" +
                            "<table>" +
                            "<tr><td>Payee:</td><td><b>%s</b></td></tr>" +
                            "<tr><td>Total Payable:</td><td>%.2f</td></tr>" +
                            "<tr><td>Monthly Payment:</td><td>%.2f</td></tr>" +
                            "<tr><td>Penalty:</td><td>%.2f</td></tr>" +
                            "<tr><td><b>Total Payment:</b></td><td><b>%.2f</b></td></tr>" +
                            "</table><br>" +
                            "Confirm this payment?" +
                            "</div></html>",
                    payeeName,
                    loanDetails.totalPayable,
                    paymentAmount,
                    penaltyAmount,
                    totalPayment
            );

            int confirm = JOptionPane.showConfirmDialog(this,
                    message,
                    "Confirm Payment",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);

            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            // Record payment
            String sql = "INSERT INTO payments (loan_id, payee, amount, penalty_amount, overdue, payment_type, reference_number) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = connection.prepareStatement(sql);

            pst.setInt(1, loanId);
            pst.setString(2, payeeName);
            pst.setDouble(3, paymentAmount);
            pst.setDouble(4, penaltyAmount);
            pst.setInt(5, penaltyAmount > 0 ? 1 : 0);
            pst.setString(6, "regular");
            pst.setString(7, generateReferenceNumber());

            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                paymentSuccess = true;

                // Update loan status and schedule
                updateLoanStatus(loanId);
                updateLoanSchedule(loanId, paymentAmount, penaltyAmount);

                // Show receipt
                showReceipt(payeeName, loanId, paymentAmount, penaltyAmount, totalPayment);

                loadPayees();
                closeWindow();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Failed to record payment",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Database error: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateLoanStatus(int loanId) throws SQLException {
        // Use total_payable, not amount!
        String checkSql = "SELECT l.total_payable, COALESCE(SUM(p.amount), 0) as total_paid " +
                "FROM loan_list l LEFT JOIN payments p ON l.id = p.loan_id " +
                "WHERE l.id = ? GROUP BY l.id";

        PreparedStatement pst = connection.prepareStatement(checkSql);
        pst.setInt(1, loanId);
        ResultSet rs = pst.executeQuery();

        if (rs.next() && rs.getDouble("total_paid") >= rs.getDouble("total_payable")) {
            String updateSql = "UPDATE loan_list SET status = 3 WHERE id = ?";
            PreparedStatement updatePst = connection.prepareStatement(updateSql);
            updatePst.setInt(1, loanId);
            updatePst.executeUpdate();
        }
    }

    private void updateLoanSchedule(int loanId, double paymentAmount, double penaltyAmount) throws SQLException {
        // Find the earliest unpaid schedule
        String scheduleSql = "SELECT id, due_date, total_amount, remaining_amount, status " +
                "FROM loan_schedules " +
                "WHERE loan_id = ? AND status < 2 " +
                "ORDER BY due_date ASC LIMIT 1";

        PreparedStatement schedulePst = connection.prepareStatement(scheduleSql);
        schedulePst.setInt(1, loanId);
        ResultSet scheduleRs = schedulePst.executeQuery();

        if (scheduleRs.next()) {
            int scheduleId = scheduleRs.getInt("id");
            double totalAmount = scheduleRs.getDouble("total_amount");
            double remainingAmount = scheduleRs.getDouble("remaining_amount");
            int status = scheduleRs.getInt("status");
            Date dueDate = scheduleRs.getDate("due_date");

            double newPaidAmount = totalAmount - remainingAmount + paymentAmount;
            double newRemainingAmount = totalAmount - newPaidAmount;

            // Only update penalty if really overdue and penalty applied
            String updateSql = "UPDATE loan_schedules SET " +
                    "remaining_amount = ?, " +
                    "penalty_amount = penalty_amount + ?, " +
                    "status = CASE WHEN ? <= 0 THEN 2 ELSE 1 END, " +
                    "payment_date = CASE WHEN ? <= 0 THEN NOW() ELSE payment_date END, " +
                    "is_overdue = ? " +
                    "WHERE id = ?";

            PreparedStatement updatePst = connection.prepareStatement(updateSql);
            updatePst.setDouble(1, newRemainingAmount);
            updatePst.setDouble(2, penaltyAmount);
            updatePst.setDouble(3, newRemainingAmount);
            updatePst.setDouble(4, newRemainingAmount);
            updatePst.setBoolean(5, penaltyAmount > 0);
            updatePst.setInt(6, scheduleId);
            updatePst.executeUpdate();
        }
    }

    private String getPayeeName(int borrowerId) throws SQLException {
        String sql = "SELECT CONCAT(firstname, ' ', lastname) as name FROM borrowers WHERE id = ?";
        PreparedStatement pst = connection.prepareStatement(sql);
        pst.setInt(1, borrowerId);
        ResultSet rs = pst.executeQuery();
        return rs.next() ? rs.getString("name") : "Unknown Payee";
    }

    private String generateReferenceNumber() {
        return "PAY" + System.currentTimeMillis();
    }

    private void showReceipt(String payeeName, int loanId, double amount, double penalty, double total) {
        String receipt = String.format(
                "<html><div style=\"width: 300px;\">" +
                        "<h2 style=\"text-align: center;\">Payment Receipt</h2>" +
                        "<hr>" +
                        "<table width=\"100%%\">" +
                        "<tr><td>Date:</td><td>%s</td></tr>" +
                        "<tr><td>Loan ID:</td><td>%d</td></tr>" +
                        "<tr><td>Payee:</td><td>%s</td></tr>" +
                        "<tr><td>Reference:</td><td>%s</td></tr>" +
                        "</table>" +
                        "<hr>" +
                        "<table width=\"100%%\">" +
                        "<tr><td>Amount:</td><td align=\"right\">%s</td></tr>" +
                        "<tr><td>Penalty:</td><td align=\"right\">%s</td></tr>" +
                        "<tr><td><b>Total Paid:</b></td><td align=\"right\"><b>%s</b></td></tr>" +
                        "</table>" +
                        "<hr>" +
                        "<p style=\"text-align: center;\">Thank you for your payment!</p>" +
                        "</div></html>",
                new Date().toString(),
                loanId,
                payeeName,
                generateReferenceNumber(),
                currencyFormat.format(amount),
                currencyFormat.format(penalty),
                currencyFormat.format(total)
        );
        JOptionPane.showMessageDialog(this, receipt, "Payment Receipt", JOptionPane.INFORMATION_MESSAGE);
    }

    public boolean wasPaymentSuccessful() {
        return paymentSuccess;
    }

    private void closeWindow() {
        Window window = SwingUtilities.getWindowAncestor(this);
        if (window != null) {
            window.dispose();
        }
    }

    private void closeConnection() {
        try {
            if (connection != null) connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Helper class to store loan details
    private class LoanDetails {
        double totalPayable;
        Timestamp dateReleased;
        int months;
        double interestRate;
        double penaltyRate;
        double nextPaymentAmount;
        double penaltyPerMissed;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        LabelNewPayment = new javax.swing.JLabel();
        LabelPayee = new javax.swing.JLabel();
        ButtonCancel = new javax.swing.JButton();
        ButtonContinue = new javax.swing.JButton();
        ComboBoxPayee = new javax.swing.JComboBox<>();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(51, 255, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        LabelNewPayment.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        LabelNewPayment.setText("New Payment");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(22, 22, 22)
                    .addComponent(LabelNewPayment)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addContainerGap(18, Short.MAX_VALUE)
                    .addComponent(LabelNewPayment)
                    .addGap(14, 14, 14))
        );

        LabelPayee.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelPayee.setText("Payee");

        ButtonCancel.setBackground(new java.awt.Color(255, 0, 0));
        ButtonCancel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonCancel.setForeground(new java.awt.Color(255, 255, 255));
        ButtonCancel.setText("Cancel");
        ButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCancelActionPerformed(evt);
            }
        });

        ButtonContinue.setBackground(new java.awt.Color(0, 255, 0));
        ButtonContinue.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonContinue.setText("Continue");
        ButtonContinue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonContinueActionPerformed(evt);
            }
        });

        ComboBoxPayee.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ComboBoxPayee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxPayeeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(292, Short.MAX_VALUE)
                    .addComponent(ButtonContinue)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(ButtonCancel)
                    .addGap(20, 20, 20))
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(18, 18, 18)
                            .addComponent(LabelPayee))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(45, 45, 45)
                            .addComponent(ComboBoxPayee, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(LabelPayee)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(ComboBoxPayee, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ButtonCancel)
                        .addComponent(ButtonContinue))
                    .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void ComboBoxPayeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxPayeeActionPerformed

    }//GEN-LAST:event_ComboBoxPayeeActionPerformed

    private void ButtonContinueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonContinueActionPerformed
        processPayment();
        if (wasPaymentSuccessful()) {
            closeWindow();
        }
    }//GEN-LAST:event_ButtonContinueActionPerformed

    private void ButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonCancelActionPerformed
        closeWindow();
    }//GEN-LAST:event_ButtonCancelActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonCancel;
    private javax.swing.JButton ButtonContinue;
    private javax.swing.JComboBox<String> ComboBoxPayee;
    private javax.swing.JLabel LabelNewPayment;
    private javax.swing.JLabel LabelPayee;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}