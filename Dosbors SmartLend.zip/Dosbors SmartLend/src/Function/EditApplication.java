package Function;
import java.sql.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.text.NumberFormat;
import java.util.Locale;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.swing.BorderFactory;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Component;
import javax.swing.ListCellRenderer;
import javax.swing.JList;
import java.awt.Window;

public class EditApplication extends javax.swing.JPanel {
    
    private Connection connection;
    private NumberFormat currencyFormat;
    
    // Loan calculation variables
     private double loanAmount = 0.0;
    private int loanMonths = 0;
    private double interestRate = 0.0;
    private double penaltyRate = 0.0;
    private double dailyInterestRate = 0.3; // 0.3% daily interest for late payments
    private int editingLoanId = -1;
    private boolean isEditMode = false;
    
       private class TwoLineComboBoxRenderer extends JLabel implements ListCellRenderer<String> {
        @Override
        public Component getListCellRendererComponent(JList<? extends String> list, String value,
                int index, boolean isSelected, boolean cellHasFocus) {
            
            if (value != null && !value.startsWith("Select")) {
                String[] parts = value.split(" - ");
                if (parts.length == 2) {
                    String name = parts[0];
                    String taxId = parts[1];
                    
                    setText("<html><div style='padding:5px;'>" +
                           "<div style='font-weight:bold;'>" + name + "</div>" +
                           "<div style='color:gray; font-size:11px;'>Tax ID: " + taxId + "</div>" +
                           "</div></html>");
                } else {
                    setText(value);
                }
            } else {
                setText(value);
            }
            
            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            } else {
                setBackground(list.getBackground());
                setForeground(list.getForeground());
            }
            
            setOpaque(true);
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                BorderFactory.createEmptyBorder(2, 5, 2, 5)
            ));
            
            return this;
        }
    }



    public EditApplication() {
        initComponents();
        SwingUtilities.invokeLater(() -> {
            if (jPanel1.getParent() != null) {
                jPanel1.getParent().remove(jPanel1);
            }
            
            JScrollPane scrollPane = new JScrollPane(jPanel1);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
            scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

            this.setLayout(new BorderLayout());
            this.add(scrollPane, BorderLayout.CENTER);
            this.revalidate();
            this.repaint();
        });
        
        initializeDatabase();
        setupComponents();
        loadComboBoxData();
    }

    
   public void setEditingLoanId(int loanId) {
    this.editingLoanId = loanId;
    this.isEditMode = true;
    // Change the save button text to indicate update
    ButtonUpdate.setText("Update");
    // Load the loan data
    loadLoanData(loanId);
}

    // Method to check if in edit mode
public boolean isEditMode() {
    return isEditMode;
}
   private void initializeDatabase() {
    try {
        if (connection == null || connection.isClosed()) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/java_user_database?useSSL=false&serverTimezone=UTC",
                "root",
                ""
            );
        }
        currencyFormat = NumberFormat.getCurrencyInstance(new Locale("en", "PH"));
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
            "Database connection failed: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}

 private void setupComponents() {
    // Clear default combo box items
    ComboBoxLender.removeAllItems();
    ComboBoxLendType.removeAllItems();
    ComboBoxLendPlan.removeAllItems();
    ComboBoxStatus.removeAllItems();
             
    // Add placeholder items
    ComboBoxLender.addItem("Select Lender...");
    ComboBoxLendType.addItem("Select Loan Type...");
    ComboBoxLendPlan.addItem("Select Loan Plan...");
            
    ComboBoxStatus.addItem("Request");    // index 0 = status 0
    ComboBoxStatus.addItem("Confirmed");   // index 1 = status 1  
    ComboBoxStatus.addItem("Released");    // index 2 = status 2
    ComboBoxStatus.addItem("Completed");   // index 3 = status 3
    ComboBoxStatus.addItem("Denied");      // index 4 = status 4
           
    // Apply custom renderer to ComboBoxLender
    ComboBoxLender.setRenderer(new TwoLineComboBoxRenderer());
    ComboBoxLender.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
    
    // Set initial calculation display
    updateCalculationDisplay(0.0, 0.0, 0.0);
            
    // Add input validation for amount field 
    TextFieldLendAmount.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            char c = evt.getKeyChar();
            if (!Character.isDigit(c) && c != '.' && c != KeyEvent.VK_BACK_SPACE) {
                evt.consume();
            }
        }
    });
}


    
    private void loadComboBoxData() {
        loadBorrowers();
        loadLoanTypes();
        loadLoanPlans();
    }

 private void loadBorrowers() {
    try {
        String sql = "SELECT b.id, b.firstname, b.middlename, b.lastname, b.tax_id " +
                    "FROM borrowers b " +
                    "ORDER BY b.lastname, b.firstname";
        PreparedStatement pst = connection.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
                                
        while (rs.next()) {
            String fullName = String.format("%s, %s %s",
                rs.getString("lastname"),
                rs.getString("firstname"),
                rs.getString("middlename") != null ? rs.getString("middlename") : ""
            ).trim();
                                                
            String taxId = rs.getString("tax_id") != null ? rs.getString("tax_id") : "N/A";
            String displayText = String.format("%s - %s", fullName, taxId);
                                                
            ComboBoxLender.addItem(displayText);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Error loading lenders: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE);
    }
}




    private void loadLoanTypes() {
        try {
            String sql = "SELECT id, type_name FROM loan_types ORDER BY type_name";
            PreparedStatement pst = connection.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
                        
            while (rs.next()) {
                String displayText = rs.getString("type_name");
                ComboBoxLendType.addItem(displayText);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading loan types: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadLoanPlans() {
        try {
            String sql = "SELECT id, months, interest_percentage, penalty_rate FROM loan_plan ORDER BY months";
            PreparedStatement pst = connection.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
                        
            while (rs.next()) {
                int months = rs.getInt("months");
                double interest = rs.getDouble("interest_percentage");
                double penalty = rs.getDouble("penalty_rate");
                                    
                String displayText = String.format("%d Month/s [%.0f%%, %.0f%%]",
                    months, interest, penalty);
                                    
                ComboBoxLendPlan.addItem(displayText);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading loan plans: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Helper method to get ID from combo box item
    private int getSelectedId(JComboBox<String> comboBox) {
        String selected = (String) comboBox.getSelectedItem();
        if (selected == null || selected.startsWith("Select")) {
            return -1;
        }
        
        try {
            if (comboBox == ComboBoxLender) {
                return getBorrowerIdByDisplay(selected);
            } else if (comboBox == ComboBoxLendType) {
                return getLoanTypeIdByName(selected);
            } else if (comboBox == ComboBoxLendPlan) {
                return getLoanPlanIdByDisplay(selected);
            }
        } catch (Exception e) {
            return -1;
        }
        return -1;
    }
    
    // FIXED: Added missing method
  private int getBorrowerIdByDisplay(String displayText) {
    try {
        // Extract tax ID after " - "
        int dashIndex = displayText.lastIndexOf(" - ");
        if (dashIndex == -1) {
            return -1;
        }
        
        String taxId = displayText.substring(dashIndex + 3).trim();
        
        String sql = "SELECT id FROM borrowers WHERE tax_id = ?";
        PreparedStatement pst = connection.prepareStatement(sql);
        pst.setString(1, taxId);
        ResultSet rs = pst.executeQuery();
        
        if (rs.next()) {
            return rs.getInt("id");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return -1;
}




    
    private int getLoanTypeIdByName(String typeName) {
        try {
            String sql = "SELECT id FROM loan_types WHERE type_name = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, typeName);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int getLoanPlanIdByDisplay(String displayText) {
        try {
            // Extract months from "12 Month/s [5%, 2%]"
            String monthsStr = displayText.split(" ")[0];
            int months = Integer.parseInt(monthsStr);
            
            String sql = "SELECT id FROM loan_plan WHERE months = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, months);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }
    
    // FIXED: Updated method to work without ":" separator
    private String getSelectedText(JComboBox<String> comboBox) {
        String selected = (String) comboBox.getSelectedItem();
        return selected; // Return as-is since no ":" separator anymore
    }
    
    // Helper method to get tax ID from borrower selection
    private String getSelectedTaxId() {
        String selected = (String) ComboBoxLender.getSelectedItem();
        if (selected != null && selected.contains("Tax ID:")) {
            String[] parts = selected.split("Tax ID:");
            if (parts.length > 1) {
                return parts[1].trim();
            }
        }
        return "N/A";
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        LabelEditUser = new javax.swing.JLabel();
        LabelLender = new javax.swing.JLabel();
        LabelLendPlan = new javax.swing.JLabel();
        LabelPurpose = new javax.swing.JLabel();
        LabelLendType = new javax.swing.JLabel();
        LabelLendAmount = new javax.swing.JLabel();
        ButtonCancel = new javax.swing.JButton();
        ButtonUpdate = new javax.swing.JButton();
        TextFieldPurpose = new javax.swing.JTextField();
        ComboBoxLender = new javax.swing.JComboBox<>();
        ComboBoxLendType = new javax.swing.JComboBox<>();
        ComboBoxLendPlan = new javax.swing.JComboBox<>();
        TextFieldLendAmount = new javax.swing.JTextField();
        CalculateButton = new javax.swing.JButton();
        LabelTotalPayableAmount = new javax.swing.JLabel();
        LabelMonthlyPayableAmount = new javax.swing.JLabel();
        LabelPenaltyAmount = new javax.swing.JLabel();
        LabelTotalPayable = new javax.swing.JLabel();
        LabelMonthlyPayable = new javax.swing.JLabel();
        LabelPenalty = new javax.swing.JLabel();
        LabelStatus = new javax.swing.JLabel();
        ComboBoxStatus = new javax.swing.JComboBox<>();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(51, 255, 204));

        LabelEditUser.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelEditUser.setText("Edit Lend Application");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(LabelEditUser, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LabelEditUser, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        LabelLender.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelLender.setText("Lender");

        LabelLendPlan.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelLendPlan.setText("Lend plan");

        LabelPurpose.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelPurpose.setText("Purpose");

        LabelLendType.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelLendType.setText("Lend Type");

        LabelLendAmount.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelLendAmount.setText("Lend Amount");

        ButtonCancel.setBackground(new java.awt.Color(255, 0, 0));
        ButtonCancel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonCancel.setForeground(new java.awt.Color(255, 255, 255));
        ButtonCancel.setText("Cancel");
        ButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCancelActionPerformed(evt);
            }
        });

        ButtonUpdate.setBackground(new java.awt.Color(0, 255, 0));
        ButtonUpdate.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonUpdate.setText("Update");
        ButtonUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonUpdateActionPerformed(evt);
            }
        });

        TextFieldPurpose.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TextFieldPurpose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldPurposeActionPerformed(evt);
            }
        });

        ComboBoxLender.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ComboBoxLender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ComboBoxLender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxLenderActionPerformed(evt);
            }
        });

        ComboBoxLendType.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ComboBoxLendType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ComboBoxLendType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxLendTypeActionPerformed(evt);
            }
        });

        ComboBoxLendPlan.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ComboBoxLendPlan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ComboBoxLendPlan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxLendPlanActionPerformed(evt);
            }
        });

        TextFieldLendAmount.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TextFieldLendAmount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldLendAmountActionPerformed(evt);
            }
        });

        CalculateButton.setBackground(new java.awt.Color(0, 153, 255));
        CalculateButton.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        CalculateButton.setForeground(new java.awt.Color(255, 255, 255));
        CalculateButton.setText("Calculate");
        CalculateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CalculateButtonActionPerformed(evt);
            }
        });

        LabelTotalPayableAmount.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        LabelTotalPayableAmount.setText("Total Payable Amount");

        LabelMonthlyPayableAmount.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        LabelMonthlyPayableAmount.setText("Monthly Payable Amount");

        LabelPenaltyAmount.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        LabelPenaltyAmount.setText("Penalty Amount");

        LabelTotalPayable.setText("0.00");

        LabelMonthlyPayable.setText("0.00");

        LabelPenalty.setText("0.00");

        LabelStatus.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        LabelStatus.setText("Status");

        ComboBoxStatus.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ComboBoxStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ComboBoxStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxStatusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelLender)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(ComboBoxLender, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelLendType)
                            .addComponent(ComboBoxLendType, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(LabelPurpose)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addComponent(ComboBoxLendPlan, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(LabelLendPlan))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(LabelLendAmount)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(TextFieldLendAmount)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(TextFieldPurpose))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(LabelTotalPayableAmount)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CalculateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(LabelMonthlyPayableAmount)
                                .addGap(39, 39, 39)
                                .addComponent(LabelPenaltyAmount)))))
                .addGap(17, 17, 17))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(LabelTotalPayable)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(LabelMonthlyPayable)
                .addGap(202, 202, 202)
                .addComponent(LabelPenalty)
                .addGap(67, 67, 67))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ButtonUpdate)
                .addGap(18, 18, 18)
                .addComponent(ButtonCancel)
                .addGap(31, 31, 31))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LabelStatus)
                    .addComponent(ComboBoxStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelLender)
                    .addComponent(LabelLendType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ComboBoxLender, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ComboBoxLendType, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelLendPlan)
                    .addComponent(LabelLendAmount))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextFieldLendAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ComboBoxLendPlan, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addComponent(LabelPurpose)
                .addGap(18, 18, 18)
                .addComponent(TextFieldPurpose, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelTotalPayableAmount)
                    .addComponent(LabelMonthlyPayableAmount)
                    .addComponent(LabelPenaltyAmount))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelTotalPayable)
                    .addComponent(LabelMonthlyPayable)
                    .addComponent(LabelPenalty))
                .addGap(18, 18, 18)
                .addComponent(CalculateButton)
                .addGap(32, 32, 32)
                .addComponent(LabelStatus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ComboBoxStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ButtonUpdate)
                    .addComponent(ButtonCancel))
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonCancelActionPerformed
        clearForm();
    
    // Close the window/dialog
    java.awt.Window window = SwingUtilities.getWindowAncestor(this);
    if (window != null) {
        window.dispose();
    }
    
    // Fire property change to notify parent components
    firePropertyChange("operationCancelled", false, true);
    }//GEN-LAST:event_ButtonCancelActionPerformed

    private void ButtonUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonUpdateActionPerformed
    if (!validateForm()) return;
    
    try {
        // Disable auto-commit to use transactions
        connection.setAutoCommit(false);
        
        // Get current status
        int status = ComboBoxStatus.getSelectedIndex();
        
        // Update status immediately
        String statusUpdateSql = "UPDATE loan_list SET status = ? WHERE id = ?";
        PreparedStatement statusPst = connection.prepareStatement(statusUpdateSql);
        statusPst.setInt(1, status);
        statusPst.setInt(2, editingLoanId);
        int statusUpdateResult = statusPst.executeUpdate();
        
        if (statusUpdateResult <= 0) {
            connection.rollback();
            JOptionPane.showMessageDialog(this,
                "Failed to update status! No rows affected.",
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Update other fields
        String fullUpdateSql = "UPDATE loan_list SET " +
            "loan_type_id = ?, plan_id = ?, amount = ?, purpose = ? " +
            (status == 2 ? ", date_released = NOW() " : "") +
            "WHERE id = ?";
        
        PreparedStatement fullUpdatePst = connection.prepareStatement(fullUpdateSql);
        fullUpdatePst.setInt(1, getSelectedId(ComboBoxLendType));
        fullUpdatePst.setInt(2, getSelectedId(ComboBoxLendPlan));
        fullUpdatePst.setDouble(3, Double.parseDouble(TextFieldLendAmount.getText().trim()));
        fullUpdatePst.setString(4, TextFieldPurpose.getText().trim());
        fullUpdatePst.setInt(5, editingLoanId);
        
        int fullUpdateResult = fullUpdatePst.executeUpdate();
        
        if (fullUpdateResult > 0) {
            connection.commit();
            JOptionPane.showMessageDialog(this,
                "Update successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
            SwingUtilities.getWindowAncestor(this).dispose();
        } else {
            connection.rollback();
            JOptionPane.showMessageDialog(this,
                "Failed to update loan details!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        try {
            if (connection != null) connection.rollback();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        JOptionPane.showMessageDialog(this,
            "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    } catch (Exception e) {
        try {
            if (connection != null) connection.rollback();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        JOptionPane.showMessageDialog(this,
            "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    } finally {
        try {
            if (connection != null) connection.setAutoCommit(true);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    }//GEN-LAST:event_ButtonUpdateActionPerformed

    private void ComboBoxLendPlanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxLendPlanActionPerformed
        loadPlanDetails();
        if (isFormReadyForCalculation()) {
            calculateLoan();
        }
    }//GEN-LAST:event_ComboBoxLendPlanActionPerformed

    private void TextFieldPurposeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldPurposeActionPerformed
      if (isFormReadyForCalculation()) {
            calculateLoan();
        }
    }//GEN-LAST:event_TextFieldPurposeActionPerformed

    private void CalculateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CalculateButtonActionPerformed
    if (ComboBoxLender.getSelectedIndex() == 0 || 
        ComboBoxLendType.getSelectedIndex() == 0 || 
        ComboBoxLendPlan.getSelectedIndex() == 0 || 
        TextFieldLendAmount.getText().trim().isEmpty()) {
        
        JOptionPane.showMessageDialog(this,
            "Please fill in all required fields",
            "Missing Information",
            JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    loadPlanDetails();
    calculateLoan();
    }//GEN-LAST:event_CalculateButtonActionPerformed

    private void ComboBoxLendTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxLendTypeActionPerformed
 
    }//GEN-LAST:event_ComboBoxLendTypeActionPerformed

    private void TextFieldLendAmountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldLendAmountActionPerformed
      if (isFormReadyForCalculation()) {
            calculateLoan();
        }
    }//GEN-LAST:event_TextFieldLendAmountActionPerformed

    private void ComboBoxLenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxLenderActionPerformed
     
    }//GEN-LAST:event_ComboBoxLenderActionPerformed

    private void ComboBoxStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxStatusActionPerformed
            if (isEditMode && editingLoanId > 0) {
        // Just log the change, don't update database yet
        System.out.println("Status changed to: " + ComboBoxStatus.getSelectedItem());
    }
    }//GEN-LAST:event_ComboBoxStatusActionPerformed
   
private boolean verifyStatusUpdate(int loanId, int expectedStatus) {
    try (PreparedStatement pst = connection.prepareStatement(
            "SELECT status FROM loan_list WHERE id = ?")) {
        pst.setInt(1, loanId);
        ResultSet rs = pst.executeQuery();
        return rs.next() && rs.getInt("status") == expectedStatus;
    } catch (SQLException e) {
        return false;
    }
}    
    
    private boolean executeUpdateQuery(String sql, Object... params) throws SQLException {
    try (PreparedStatement pst = connection.prepareStatement(sql)) {
        for (int i = 0; i < params.length; i++) {
            pst.setObject(i + 1, params[i]);
        }
        return pst.executeUpdate() > 0;
    }
}


    
    
    private void loadLoanData(int loanId) {
    try {
        String sql = """
            SELECT ll.*, b.firstname, b.middlename, b.lastname, b.tax_id,
                   lt.type_name, lp.months, lp.interest_percentage, lp.penalty_rate
            FROM loan_list ll
            JOIN borrowers b ON ll.borrower_id = b.id
            JOIN loan_types lt ON ll.loan_type_id = lt.id
            JOIN loan_plan lp ON ll.plan_id = lp.id
            WHERE ll.id = ?
            """;
        
        PreparedStatement pst = connection.prepareStatement(sql);
        pst.setInt(1, loanId);
        ResultSet rs = pst.executeQuery();
        
        if (rs.next()) {
            // Set borrower
            String fullName = String.format("%s, %s %s",
                rs.getString("lastname"),
                rs.getString("firstname"),
                rs.getString("middlename") != null ? rs.getString("middlename") : ""
            ).trim();
            String taxId = rs.getString("tax_id") != null ? rs.getString("tax_id") : "N/A";
            selectBorrowerByTaxId(taxId);
            
            // Set loan type
            selectLoanType(rs.getInt("loan_type_id"));
            
            // Set loan plan
            selectLoanPlan(rs.getInt("plan_id"));
            
            // Set amount and purpose
            TextFieldLendAmount.setText(String.valueOf(rs.getDouble("amount")));
            TextFieldPurpose.setText(rs.getString("purpose"));
            
            // Set status (matches Loan class status values)
            int status = rs.getInt("status");
            ComboBoxStatus.setSelectedIndex(status);
            
            // Load plan details and calculate
            loadPlanDetails();
            calculateLoan();
            
            // Update date released if status is Released (2)
            if (status == 2) {
                updateDateReleased();
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Error loading loan data: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE);
    }
}
private void debugCurrentState() {
    System.out.println("=== DEBUG INFO ===");
    System.out.println("Edit Mode: " + isEditMode);
    System.out.println("Editing Loan ID: " + editingLoanId);
    System.out.println("Borrower ID: " + getSelectedId(ComboBoxLender));
    System.out.println("Loan Type ID: " + getSelectedId(ComboBoxLendType));
    System.out.println("Plan ID: " + getSelectedId(ComboBoxLendPlan));
    System.out.println("Amount: " + TextFieldLendAmount.getText());
    System.out.println("Purpose: " + TextFieldPurpose.getText());
    System.out.println("Status: " + ComboBoxStatus.getSelectedIndex());
    System.out.println("Database Connected: " + isDatabaseConnected());
    System.out.println("==================");
}

    private void updateDateReleased() {
    try {
        String sql = "UPDATE loan_list SET date_released = NOW() WHERE id = ? AND date_released IS NULL";
        PreparedStatement pst = connection.prepareStatement(sql);
        pst.setInt(1, editingLoanId);
        
        int result = pst.executeUpdate();
        if (result > 0) {
            System.out.println("Date released updated for loan ID: " + editingLoanId);
        }
        
    } catch (SQLException e) {
        System.out.println("Error updating date_released: " + e.getMessage());
        e.printStackTrace();
    }
}

   private void loadPlanDetails() {
    int planId = getSelectedId(ComboBoxLendPlan);
    if (planId > 0) {
        try {
            String sql = "SELECT months, interest_percentage, penalty_rate FROM loan_plan WHERE id = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, planId);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                loanMonths = rs.getInt("months");
                interestRate = rs.getDouble("interest_percentage");
                penaltyRate = rs.getDouble("penalty_rate");
                
                // Update calculation if amount is already entered
                if (!TextFieldLendAmount.getText().trim().isEmpty()) {
                    calculateLoan();
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading plan details: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
}    
    private boolean isFormReadyForCalculation() {
        return getSelectedId(ComboBoxLender) > 0 &&
               getSelectedId(ComboBoxLendType) > 0 &&
               getSelectedId(ComboBoxLendPlan) > 0 &&
               !TextFieldLendAmount.getText().trim().isEmpty();
    }
    
  private void calculateLoan() {
    try {
        String amountText = TextFieldLendAmount.getText().trim();
        if (amountText.isEmpty()) return;

        loanAmount = Double.parseDouble(amountText);

        if (loanAmount <= 0) {
            JOptionPane.showMessageDialog(this, 
                "Please enter a valid loan amount greater than 0", 
                "Invalid Amount", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        // ✅ Simple interest calculation
        double totalInterest = loanAmount * (interestRate / 100);
        double totalPayable = loanAmount + totalInterest;
        double monthlyPayment = totalPayable / loanMonths;

        // ✅ Optional: use penaltyRate here if needed
        double penalty = monthlyPayment * (penaltyRate / 100);

        updateCalculationDisplay(totalPayable, monthlyPayment, penalty);

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, 
            "Please enter a valid numeric amount", 
            "Invalid Input", 
            JOptionPane.WARNING_MESSAGE);
    }
}
    /**
     * Calculates the penalty for a missed payment including:
     * - 2% penalty of the monthly payment
     * - Daily interest of 0.3% on overdue amount
     * @param monthlyPayment The base monthly payment amount
     * @param daysLate Number of days the payment is late
     * @return Total penalty amount
     */
    public double calculateMissedPaymentPenalty(double monthlyPayment, int daysLate) {
        // 2% penalty of monthly payment
        double basePenalty = monthlyPayment * (penaltyRate / 100);
        
        // 0.3% daily interest on overdue amount
        double dailyInterest = monthlyPayment * (dailyInterestRate / 100) * daysLate;
        
        return basePenalty + dailyInterest;
    }
    
    
     private void updateCalculationDisplay(double totalPayable, double monthlyPayment, double penalty) {
        LabelTotalPayable.setText(currencyFormat.format(totalPayable));
        LabelMonthlyPayable.setText(currencyFormat.format(monthlyPayment));
        LabelPenalty.setText(currencyFormat.format(penalty));
    }
    
 private boolean validateForm() {
    // Check database connection first
    if (!validateDatabaseConnection()) {
        return false;
    }
    
    if (getSelectedId(ComboBoxLender) <= 0) {
        JOptionPane.showMessageDialog(this, "Please select a borrower", "Validation Error", JOptionPane.WARNING_MESSAGE);
        ComboBoxLender.requestFocus();
        return false;
    }
    
    if (getSelectedId(ComboBoxLendType) <= 0) {
        JOptionPane.showMessageDialog(this, "Please select a loan type", "Validation Error", JOptionPane.WARNING_MESSAGE);
        ComboBoxLendType.requestFocus();
        return false;
    }
    
    if (getSelectedId(ComboBoxLendPlan) <= 0) {
        JOptionPane.showMessageDialog(this, "Please select a loan plan", "Validation Error", JOptionPane.WARNING_MESSAGE);
        ComboBoxLendPlan.requestFocus();
        return false;
    }
    
    String amountText = TextFieldLendAmount.getText().trim();
    if (amountText.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter the loan amount", "Validation Error", JOptionPane.WARNING_MESSAGE);
        TextFieldLendAmount.requestFocus();
        return false;
    }
    
    try {
        double amount = Double.parseDouble(amountText);
        if (!validateLoanAmount(amount)) {
            TextFieldLendAmount.requestFocus();
            return false;
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Please enter a valid numeric amount", "Validation Error", JOptionPane.WARNING_MESSAGE);
        TextFieldLendAmount.requestFocus();
        return false;
    }
    
    if (TextFieldPurpose.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter the loan purpose", "Validation Error", JOptionPane.WARNING_MESSAGE);
        TextFieldPurpose.requestFocus();
        return false;
    }
    
    return true;
}

    
    private boolean validateDatabaseConnection() {
    try {
        if (connection == null || connection.isClosed()) {
            initializeDatabase();
        }
        return connection != null && !connection.isClosed();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Database connection error: " + e.getMessage(),
            "Connection Error",
            JOptionPane.ERROR_MESSAGE);
        return false;
    }
}

    
    private void saveLoanApplication() {
        try {
            int borrowerId = getSelectedId(ComboBoxLender);
            int loanTypeId = getSelectedId(ComboBoxLendType);
            int loanPlanId = getSelectedId(ComboBoxLendPlan);
            double amount = Double.parseDouble(TextFieldLendAmount.getText().trim());
            String purpose = TextFieldPurpose.getText().trim();
            
            String sql = """
                INSERT INTO loan_list 
                (ref_no, loan_type_id, borrower_id, purpose, amount, plan_id, status, date_created)
                VALUES (?, ?, ?, ?, ?, ?, 0, NOW())
                """;
            
            PreparedStatement pst = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            
            pst.setString(1, ""); // Let the trigger generate the ref_no
            pst.setInt(2, loanTypeId);
            pst.setInt(3, borrowerId);
            pst.setString(4, purpose);
            pst.setDouble(5, amount);
            pst.setInt(6, loanPlanId);
            
            int result = pst.executeUpdate();
            
            if (result > 0) {
                ResultSet generatedKeys = pst.getGeneratedKeys();
                int loanId = 0;
                if (generatedKeys.next()) {
                    loanId = generatedKeys.getInt(1);
                }
                
                createLoanSchedules(loanId, amount, loanMonths, interestRate);
                
                String borrowerInfo = getSelectedText(ComboBoxLender);
                String taxId = getSelectedTaxId();
                
                JOptionPane.showMessageDialog(this,
                    String.format("Loan application saved successfully!\n\n" +
                                "Loan ID: %d\n" +
                                "Borrower: %s\n" +
                                "Tax ID: %s\n" +
                                "Amount: %s",
                                 loanId,
                                 borrowerInfo.split("\\|")[0].trim(),
                                taxId,
                                             currencyFormat.format(amount)),
                     "Success",
                     JOptionPane.INFORMATION_MESSAGE);
                
                clearForm();
                
                java.awt.Window window = SwingUtilities.getWindowAncestor(this);
                if (window instanceof JDialog) {
                    window.dispose();
                }
                
                firePropertyChange("loanSaved", false, true);
                
            } else {
                JOptionPane.showMessageDialog(this,
                     "Failed to save loan application",
                     "Error",
                     JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                 "Database error: " + e.getMessage(),
                 "Database Error",
                 JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                 "Invalid amount format",
                 "Input Error",
                 JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void createLoanSchedules(int loanId, double amount, int months, double interestRate) {
        try {
            // Calculate payment details
            double totalInterest = amount * (interestRate / 100);
            double totalAmount = amount + totalInterest;
            double monthlyPayment = totalAmount / months;
            double principalPerMonth = amount / months;
            double interestPerMonth = totalInterest / months;
            
            String sql = """
                INSERT INTO loan_schedules 
                (loan_id, installment_number, due_date, principal_amount, interest_amount,
                 total_amount, remaining_amount, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 0, NOW())
                """;
            
            PreparedStatement pst = connection.prepareStatement(sql);
            
            // Create schedule for each month
            java.util.Calendar calendar = java.util.Calendar.getInstance();
            calendar.add(java.util.Calendar.MONTH, 1); // Start from next month
            
            for (int i = 1; i <= months; i++) {
                pst.setInt(1, loanId);
                pst.setInt(2, i);
                pst.setDate(3, new java.sql.Date(calendar.getTimeInMillis()));
                pst.setBigDecimal(4, new BigDecimal(principalPerMonth).setScale(2, RoundingMode.HALF_UP));
                pst.setBigDecimal(5, new BigDecimal(interestPerMonth).setScale(2, RoundingMode.HALF_UP));
                pst.setBigDecimal(6, new BigDecimal(monthlyPayment).setScale(2, RoundingMode.HALF_UP));
                pst.setBigDecimal(7, new BigDecimal(monthlyPayment).setScale(2, RoundingMode.HALF_UP));
                
                pst.addBatch();
                
                // Move to next month
                calendar.add(java.util.Calendar.MONTH, 1);
            }
            
            pst.executeBatch();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                 "Error creating loan schedules: " + e.getMessage(),
                 "Database Error",
                 JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void updateLoanSchedules(int loanId, double amount, int months, double interestRate) {
    try {
        // First delete existing schedules
        String deleteSql = "DELETE FROM loan_schedules WHERE loan_id = ?";
        PreparedStatement deletePst = connection.prepareStatement(deleteSql);
        deletePst.setInt(1, loanId);
        deletePst.executeUpdate();
        
        // Then create new schedules
        createLoanSchedules(loanId, amount, months, interestRate);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Error updating loan schedules: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}
    
    private void clearForm() {
        // Reset combo boxes to first item (placeholder)
        ComboBoxLender.setSelectedIndex(0);
        ComboBoxLendType.setSelectedIndex(0);
        ComboBoxLendPlan.setSelectedIndex(0);
        ComboBoxStatus.setSelectedIndex(0);
        
        // Clear text fields
        TextFieldLendAmount.setText("");
        TextFieldPurpose.setText("");
        
        // Reset calculation display
        updateCalculationDisplay(0.0, 0.0, 0.0);
        
        // Reset calculation variables
        loanAmount = 0.0;
        loanMonths = 0;
        interestRate = 0.0;
        penaltyRate = 0.0;
        
        isEditMode = false;
        editingLoanId = -1;
        ButtonUpdate.setText("Save");
    }
    
    // Method to refresh combo box data (can be called externally)
    public void refreshData() {
        ComboBoxLender.removeAllItems();
        ComboBoxLendType.removeAllItems();
        ComboBoxLendPlan.removeAllItems();
        
        ComboBoxLender.addItem("Select Borrower...");
        ComboBoxLendType.addItem("Select Loan Type...");
        ComboBoxLendPlan.addItem("Select Loan Plan...");
        
        loadComboBoxData();
    }
    
    // Method to set initial loan amount (if called from external source)
    public void setLoanAmount(double amount) {
        TextFieldLendAmount.setText(String.valueOf(amount));
    }
    
    // Method to set initial purpose (if called from external source)
    public void setPurpose(String purpose) {
        TextFieldPurpose.setText(purpose);
    }
    
    // Method to pre-select borrower by ID
    public void selectBorrower(int borrowerId) {
        for (int i = 1; i < ComboBoxLender.getItemCount(); i++) {
            String item = ComboBoxLender.getItemAt(i);
            if (item != null && item.startsWith(borrowerId + ":")) {
                ComboBoxLender.setSelectedIndex(i);
                break;
            }
        }
    }
    
   public void selectBorrowerByTaxId(String taxId) {
    for (int i = 1; i < ComboBoxLender.getItemCount(); i++) {
        String item = ComboBoxLender.getItemAt(i);
        if (item != null && item.endsWith(" - " + taxId)) {
            ComboBoxLender.setSelectedIndex(i);
            break;
        }
    }
}

    
    // Method to pre-select loan type by ID
  public void selectLoanType(int loanTypeId) {
    try {
        String sql = "SELECT type_name FROM loan_types WHERE id = ?";
        PreparedStatement pst = connection.prepareStatement(sql);
        pst.setInt(1, loanTypeId);
        ResultSet rs = pst.executeQuery();
        
        if (rs.next()) {
            String typeName = rs.getString("type_name");
            for (int i = 0; i < ComboBoxLendType.getItemCount(); i++) {
                if (ComboBoxLendType.getItemAt(i).equals(typeName)) {
                    ComboBoxLendType.setSelectedIndex(i);
                    break;
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    // Method to pre-select loan plan by ID
  public void selectLoanPlan(int planId) {
    try {
        String sql = "SELECT months, interest_percentage, penalty_rate FROM loan_plan WHERE id = ?";
        PreparedStatement pst = connection.prepareStatement(sql);
        pst.setInt(1, planId);
        ResultSet rs = pst.executeQuery();
        
        if (rs.next()) {
            int months = rs.getInt("months");
            double interest = rs.getDouble("interest_percentage");
            double penalty = rs.getDouble("penalty_rate");
            String planDisplay = String.format("%d Month/s [%.0f%%, %.0f%%]", months, interest, penalty);
            
            for (int i = 0; i < ComboBoxLendPlan.getItemCount(); i++) {
                if (ComboBoxLendPlan.getItemAt(i).equals(planDisplay)) {
                    ComboBoxLendPlan.setSelectedIndex(i);
                    loadPlanDetails();
                    break;
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    public void setStatus(int status) {
    ComboBoxStatus.setSelectedIndex(status);
}
    // Method to get current calculation results
    public LoanCalculation getCurrentCalculation() {
        if (isFormReadyForCalculation()) {
            try {
                double amount = Double.parseDouble(TextFieldLendAmount.getText().trim());
                double totalInterest = amount * (interestRate / 100);
                double totalPayable = amount + totalInterest;
                double monthlyPayment = totalPayable / loanMonths;
                double penaltyAmount = monthlyPayment * (penaltyRate / 100);
                
                return new LoanCalculation(amount, totalPayable, monthlyPayment, penaltyAmount, loanMonths, interestRate, penaltyRate);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }
    
    // Helper class for loan calculation results
    public static class LoanCalculation {
        public final double principalAmount;
        public final double totalPayable;
        public final double monthlyPayment;
        public final double penaltyAmount;
        public final int months;
        public final double interestRate;
        public final double penaltyRate;
        
        public LoanCalculation(double principalAmount, double totalPayable, double monthlyPayment,
                              double penaltyAmount, int months, double interestRate, double penaltyRate) {
            this.principalAmount = principalAmount;
            this.totalPayable = totalPayable;
            this.monthlyPayment = monthlyPayment;
            this.penaltyAmount = penaltyAmount;
            this.months = months;
            this.interestRate = interestRate;
            this.penaltyRate = penaltyRate;
        }
        
        @Override
        public String toString() {
            NumberFormat currency = NumberFormat.getCurrencyInstance(new Locale("en", "PH"));
            return String.format("Principal: %s, Total: %s, Monthly: %s, Penalty: %s",
                 currency.format(principalAmount),
                 currency.format(totalPayable),
                 currency.format(monthlyPayment),
                 currency.format(penaltyAmount));
        }
    }
    
    // Method to validate database connection
    public boolean isDatabaseConnected() {
        try {
            return connection != null && !connection.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }
    
    // Method to reconnect to database if connection is lost
    public void reconnectDatabase() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            // Ignore close errors
        }
        
        initializeDatabase();
        
        if (isDatabaseConnected()) {
            refreshData();
        }
    }
    
    // Method to get borrower info by Tax ID (for external use)
    public String getBorrowerInfoByTaxId(String taxId) {
        try {
            String sql = "SELECT firstname, middlename, lastname FROM borrowers WHERE tax_id = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, taxId);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                return String.format("%s, %s %s",
                     rs.getString("lastname"),
                    rs.getString("firstname"),
                    rs.getString("middlename") != null ? rs.getString("middlename") : ""
                ).trim();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // Method to get borrower name by ID (for external use)
    public String getBorrowerName(int borrowerId) {
        try {
            String sql = "SELECT firstname, middlename, lastname, tax_id FROM borrowers WHERE id = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, borrowerId);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                String fullName = String.format("%s, %s %s",
                     rs.getString("lastname"),
                    rs.getString("firstname"),
                    rs.getString("middlename") != null ? rs.getString("middlename") : ""
                ).trim();
                String taxId = rs.getString("tax_id") != null ? rs.getString("tax_id") : "N/A";
                return String.format("%s | Tax ID: %s", fullName, taxId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // Method to get loan type name by ID (for external use)
    public String getLoanTypeName(int loanTypeId) {
        try {
            String sql = "SELECT type_name FROM loan_types WHERE id = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, loanTypeId);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                return rs.getString("type_name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // Method to get loan plan details by ID (for external use)
    public String getLoanPlanDetails(int loanPlanId) {
        try {
            String sql = "SELECT months, interest_percentage, penalty_rate FROM loan_plan WHERE id = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, loanPlanId);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                int months = rs.getInt("months");
                return String.format("%d Month/s [%.1f%%, %.1f%%]",
                     months,
                    rs.getDouble("interest_percentage"),
                    rs.getDouble("penalty_rate")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // Method to check if a borrower exists by Tax ID
    public boolean borrowerExistsByTaxId(String taxId) {
        try {
            String sql = "SELECT COUNT(*) FROM borrowers WHERE tax_id = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, taxId);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Method to check if a borrower exists by ID
    public boolean borrowerExists(int borrowerId) {
        try {
            String sql = "SELECT COUNT(*) FROM borrowers WHERE id = ?";
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setInt(1, borrowerId);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Method to get the next available reference number
    public String getNextReferenceNumber() {
        try {
            String sql = "SELECT MAX(CAST(SUBSTRING(ref_no, 2) AS UNSIGNED)) as max_num FROM loan_list WHERE ref_no REGEXP '^L[0-9]+$'";
            PreparedStatement pst = connection.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                int nextNum = rs.getInt("max_num") + 1;
                return String.format("L%04d", nextNum);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "L0001"; // Default if no records found
    }
    
    // Method to export loan calculation to string
    public String exportCalculationSummary() {
        if (!isFormReadyForCalculation()) {
            return "No calculation available - please fill all required fields.";
        }
        
        LoanCalculation calc = getCurrentCalculation();
        if (calc == null) {
            return "Error in calculation.";
        }
        
        StringBuilder summary = new StringBuilder();
        summary.append("=== LOAN CALCULATION SUMMARY ===\n");
        summary.append("Borrower: ").append(getSelectedText(ComboBoxLender)).append("\n");
        summary.append("Tax ID: ").append(getSelectedTaxId()).append("\n");
         summary.append("Loan Type: ").append(getSelectedText(ComboBoxLendType)).append("\n");
        summary.append("Loan Plan: ").append(getSelectedText(ComboBoxLendPlan)).append("\n");
        summary.append("Purpose: ").append(TextFieldPurpose.getText().trim()).append("\n");
        summary.append("=====================================\n");
        summary.append("Principal Amount: ").append(currencyFormat.format(calc.principalAmount)).append("\n");
        summary.append("Interest Rate: ").append(String.format("%.1f%%", calc.interestRate)).append("\n");
        summary.append("Loan Term: ").append(calc.months).append(" months\n");
        summary.append("Total Payable: ").append(currencyFormat.format(calc.totalPayable)).append("\n");
        summary.append("Monthly Payment: ").append(currencyFormat.format(calc.monthlyPayment)).append("\n");
        summary.append("Penalty Rate: ").append(String.format("%.1f%%", calc.penaltyRate)).append("\n");
        summary.append("Penalty Amount: ").append(currencyFormat.format(calc.penaltyAmount)).append("\n");
        summary.append("=====================================\n");
        summary.append("Generated on: ").append(new java.util.Date().toString()).append("\n");
        
        return summary.toString();
    }
    
    // Method to validate loan amount against business rules
    public boolean validateLoanAmount(double amount) {
        // Add your business rules here
        if (amount <= 0) {
            JOptionPane.showMessageDialog(this, 
                "Loan amount must be greater than zero", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        if (amount > 10000000) { // 10 million limit
            JOptionPane.showMessageDialog(this, 
                "Loan amount cannot exceed ₱10,000,000", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        if (amount < 1000) { // Minimum 1000
            JOptionPane.showMessageDialog(this, 
                "Minimum loan amount is ₱1,000", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
            return false;
        }
        
        return true;
    }
    
    // Method to format amount with proper currency display
    public String formatCurrency(double amount) {
        return currencyFormat.format(amount);
    }
    
    // Method to get database connection (for external use if needed)
    public Connection getConnection() {
        return connection;
    }
    
    // Method to close database connection
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
   @SuppressWarnings("deprecation")

    // Method to handle window closing event
    public void handleWindowClosing() {
        closeConnection();
    }
    
    // Method to get current form state for debugging
    public String getFormState() {
        StringBuilder state = new StringBuilder();
        state.append("Form State:\n");
        state.append("Borrower Selected: ").append(getSelectedId(ComboBoxLender) > 0).append("\n");
        state.append("Loan Type Selected: ").append(getSelectedId(ComboBoxLendType) > 0).append("\n");
        state.append("Loan Plan Selected: ").append(getSelectedId(ComboBoxLendPlan) > 0).append("\n");
        state.append("Amount Entered: ").append(!TextFieldLendAmount.getText().trim().isEmpty()).append("\n");
        state.append("Purpose Entered: ").append(!TextFieldPurpose.getText().trim().isEmpty()).append("\n");
        state.append("Ready for Calculation: ").append(isFormReadyForCalculation()).append("\n");
        state.append("Database Connected: ").append(isDatabaseConnected()).append("\n");
        return state.toString();
    }
    
    // Method to log form activity (for debugging)
    public void logActivity(String activity) {
        System.out.println("[CreateNewApplication] " + new java.util.Date() + ": " + activity);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonCancel;
    private javax.swing.JButton ButtonUpdate;
    private javax.swing.JButton CalculateButton;
    private javax.swing.JComboBox<String> ComboBoxLendPlan;
    private javax.swing.JComboBox<String> ComboBoxLendType;
    private javax.swing.JComboBox<String> ComboBoxLender;
    private javax.swing.JComboBox<String> ComboBoxStatus;
    private javax.swing.JLabel LabelEditUser;
    private javax.swing.JLabel LabelLendAmount;
    private javax.swing.JLabel LabelLendPlan;
    private javax.swing.JLabel LabelLendType;
    private javax.swing.JLabel LabelLender;
    private javax.swing.JLabel LabelMonthlyPayable;
    private javax.swing.JLabel LabelMonthlyPayableAmount;
    private javax.swing.JLabel LabelPenalty;
    private javax.swing.JLabel LabelPenaltyAmount;
    private javax.swing.JLabel LabelPurpose;
    private javax.swing.JLabel LabelStatus;
    private javax.swing.JLabel LabelTotalPayable;
    private javax.swing.JLabel LabelTotalPayableAmount;
    private javax.swing.JTextField TextFieldLendAmount;
    private javax.swing.JTextField TextFieldPurpose;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
