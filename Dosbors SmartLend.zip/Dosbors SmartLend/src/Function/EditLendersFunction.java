package Function;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class EditLendersFunction extends JPanel {
    private int lenderId;
    
    public EditLendersFunction(int lenderId) {
        this.lenderId = lenderId;
        initComponents();
        loadLenderData();
    }
    
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/java_user_database", "root", "");
    }
    
    private void loadLenderData() {
        try (Connection conn = getConnection()) {
            String sql = "SELECT * FROM borrowers WHERE id = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, lenderId);
            ResultSet rs = pst.executeQuery();
            
            if (rs.next()) {
                TextFieldFirstName.setText(rs.getString("firstname"));
                TextFieldLastName.setText(rs.getString("lastname"));
                TextFieldMiddleName.setText(rs.getString("middlename"));
                TextFieldAddress.setText(rs.getString("address"));
                TextFieldContactNumber.setText(rs.getString("contact_no"));
                TextFieldEmail.setText(rs.getString("email"));
                TextFieldTaxID.setText(rs.getString("tax_id"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading lender data: " + e.getMessage(),
                                         "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void saveLenderData() {
        try (Connection conn = getConnection()) {
            String sql = "UPDATE borrowers SET firstname=?, lastname=?, middlename=?, address=?, contact_no=?, email=?, tax_id=? WHERE id=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            
            pst.setString(1, TextFieldFirstName.getText().trim());
            pst.setString(2, TextFieldLastName.getText().trim());
            pst.setString(3, TextFieldMiddleName.getText().trim());
            pst.setString(4, TextFieldAddress.getText().trim());
            pst.setString(5, TextFieldContactNumber.getText().trim());
            pst.setString(6, TextFieldEmail.getText().trim());
            pst.setString(7, TextFieldTaxID.getText().trim());
            pst.setInt(8, lenderId);
            
            int result = pst.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Lender updated successfully!",
                                             "Success", JOptionPane.INFORMATION_MESSAGE);
                closeDialog();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update lender.",
                                             "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error saving lender data: " + e.getMessage(),
                                         "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void closeDialog() {
        SwingUtilities.getWindowAncestor(this).dispose();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        LabelEditUser = new javax.swing.JLabel();
        LabelFirstName = new javax.swing.JLabel();
        LabelMiddleName = new javax.swing.JLabel();
        LabelLastName = new javax.swing.JLabel();
        LabelAddress = new javax.swing.JLabel();
        LabelContactNumber = new javax.swing.JLabel();
        LabelEmail = new javax.swing.JLabel();
        TextFieldFirstName = new javax.swing.JTextField();
        TextFieldMiddleName = new javax.swing.JTextField();
        TextFieldLastName = new javax.swing.JTextField();
        TextFieldAddress = new javax.swing.JTextField();
        TextFieldContactNumber = new javax.swing.JTextField();
        TextFieldEmail = new javax.swing.JTextField();
        ButtonSave = new javax.swing.JButton();
        ButtonCancel = new javax.swing.JButton();
        LabelTaxID = new javax.swing.JLabel();
        TextFieldTaxID = new javax.swing.JTextField();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(51, 255, 204));

        LabelEditUser.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelEditUser.setText("Edit Lender");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(LabelEditUser, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LabelEditUser, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        LabelFirstName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelFirstName.setText("First Name");

        LabelMiddleName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelMiddleName.setText("Middle Name");

        LabelLastName.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelLastName.setText("Last Name");

        LabelAddress.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelAddress.setText("Address");

        LabelContactNumber.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelContactNumber.setText("Contact Number");

        LabelEmail.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelEmail.setText("Email");

        TextFieldFirstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldFirstNameActionPerformed(evt);
            }
        });

        TextFieldMiddleName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldMiddleNameActionPerformed(evt);
            }
        });

        TextFieldLastName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldLastNameActionPerformed(evt);
            }
        });

        TextFieldAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldAddressActionPerformed(evt);
            }
        });

        TextFieldContactNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldContactNumberActionPerformed(evt);
            }
        });

        TextFieldEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldEmailActionPerformed(evt);
            }
        });

        ButtonSave.setBackground(new java.awt.Color(0, 255, 0));
        ButtonSave.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonSave.setText("Save");
        ButtonSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonSaveActionPerformed(evt);
            }
        });

        ButtonCancel.setBackground(new java.awt.Color(255, 0, 0));
        ButtonCancel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        ButtonCancel.setForeground(new java.awt.Color(255, 255, 255));
        ButtonCancel.setText("Cancel");
        ButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCancelActionPerformed(evt);
            }
        });

        LabelTaxID.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelTaxID.setText("Tax ID");

        TextFieldTaxID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldTaxIDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TextFieldFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(LabelAddress)
                                    .addComponent(LabelFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TextFieldMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(LabelMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(TextFieldAddress))
                        .addGap(54, 54, 54)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TextFieldLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LabelLastName)
                            .addComponent(LabelContactNumber)
                            .addComponent(TextFieldContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelEmail)
                            .addComponent(TextFieldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelTaxID)
                            .addComponent(TextFieldTaxID, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(98, 98, 98))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ButtonSave)
                .addGap(39, 39, 39)
                .addComponent(ButtonCancel)
                .addGap(52, 52, 52))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(LabelFirstName)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TextFieldFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(LabelMiddleName)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(TextFieldMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(LabelLastName)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(TextFieldLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LabelContactNumber)
                    .addComponent(LabelAddress))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextFieldContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextFieldAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(LabelTaxID, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(TextFieldTaxID, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(LabelEmail)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TextFieldEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ButtonCancel)
                    .addComponent(ButtonSave))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void TextFieldEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldEmailActionPerformed

    }//GEN-LAST:event_TextFieldEmailActionPerformed

    private void TextFieldLastNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldLastNameActionPerformed

    }//GEN-LAST:event_TextFieldLastNameActionPerformed

    private void ButtonSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonSaveActionPerformed
          if (TextFieldFirstName.getText().trim().isEmpty() || 
        TextFieldLastName.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "First Name and Last Name are required!", 
                                     "Validation Error", JOptionPane.WARNING_MESSAGE);
        return;
    }
    
    // Call the save method
    saveLenderData();
    }//GEN-LAST:event_ButtonSaveActionPerformed

    private void TextFieldTaxIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldTaxIDActionPerformed

    }//GEN-LAST:event_TextFieldTaxIDActionPerformed

    private void ButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonCancelActionPerformed
         closeDialog();
    }//GEN-LAST:event_ButtonCancelActionPerformed

    private void TextFieldMiddleNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldMiddleNameActionPerformed

    }//GEN-LAST:event_TextFieldMiddleNameActionPerformed

    private void TextFieldFirstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldFirstNameActionPerformed

    }//GEN-LAST:event_TextFieldFirstNameActionPerformed

    private void TextFieldAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldAddressActionPerformed

    }//GEN-LAST:event_TextFieldAddressActionPerformed

    private void TextFieldContactNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldContactNumberActionPerformed

    }//GEN-LAST:event_TextFieldContactNumberActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonCancel;
    private javax.swing.JButton ButtonSave;
    private javax.swing.JLabel LabelAddress;
    private javax.swing.JLabel LabelContactNumber;
    private javax.swing.JLabel LabelEditUser;
    private javax.swing.JLabel LabelEmail;
    private javax.swing.JLabel LabelFirstName;
    private javax.swing.JLabel LabelLastName;
    private javax.swing.JLabel LabelMiddleName;
    private javax.swing.JLabel LabelTaxID;
    private javax.swing.JTextField TextFieldAddress;
    private javax.swing.JTextField TextFieldContactNumber;
    private javax.swing.JTextField TextFieldEmail;
    private javax.swing.JTextField TextFieldFirstName;
    private javax.swing.JTextField TextFieldLastName;
    private javax.swing.JTextField TextFieldMiddleName;
    private javax.swing.JTextField TextFieldTaxID;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
