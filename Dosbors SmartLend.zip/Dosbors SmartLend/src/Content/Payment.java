package Content;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;

public class Payment extends javax.swing.JPanel {
    private Set<Integer> processedLoanIds = new HashSet<>();

    public Payment() {
        initComponents();
        setupTable();
        loadPaymentsData();
        customizeTableAppearance();
        connectSearchFunction();
        setupButtonActions();
    
    }

    private void setupButtonActions() {
        ButtonNewLender2.addActionListener(this::ButtonNewLender2ActionPerformed);
    }

    private void connectSearchFunction() {
        if (searchFunction1 != null) {
            searchFunction1.setTargetTable(TablePaymentList);
        }
    }
    
    private void refreshSearchConnection() {
        if (searchFunction1 != null) {
            searchFunction1.setTargetTable(TablePaymentList);
        }
    }

 private void setupTable() {
    TablePaymentList.setRowHeight(40);
    
    // Set preferred column widths
    TablePaymentList.getColumnModel().getColumn(0).setPreferredWidth(50);   // #
    TablePaymentList.getColumnModel().getColumn(1).setPreferredWidth(200); // Loan Reference No
    TablePaymentList.getColumnModel().getColumn(2).setPreferredWidth(250); // Payee
    TablePaymentList.getColumnModel().getColumn(3).setPreferredWidth(150); // Total Payable Amount
    TablePaymentList.getColumnModel().getColumn(4).setPreferredWidth(120); // Penalty
    TablePaymentList.getColumnModel().getColumn(5).setPreferredWidth(160); // Action
    
    // Override column names (since auto-generated code can't be modified)
    TablePaymentList.getColumnModel().getColumn(3).setHeaderValue("Total Payable Amount");
    
    TablePaymentList.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
    
    // Refresh the table header to apply changes
    TablePaymentList.getTableHeader().repaint();
}     
  private void customizeTableAppearance() {
    JTableHeader header = TablePaymentList.getTableHeader();
    header.setFont(new Font("SansSerif", Font.BOLD, 14));
    header.setForeground(Color.WHITE);
    header.setBackground(new Color(41, 128, 185));
    header.setPreferredSize(new Dimension(header.getPreferredSize().width, 35));
    
    // Restored detailed header renderer
    DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setHorizontalAlignment(JLabel.CENTER);
            setFont(new Font("SansSerif", Font.BOLD, 14));
            setForeground(Color.WHITE);
            setBackground(new Color(41, 128, 185));
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            return this;
        }
    };
    
    for (int i = 0; i < TablePaymentList.getColumnCount(); i++) {
        TablePaymentList.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
    }
    
    // Rest of table styling remains...
}
    
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/java_user_database", "root", "");
    }
private void loadPaymentsData() {
    processedLoanIds.clear();
    
    try (Connection conn = getConnection()) {
        String sql = "SELECT p.id, l.ref_no, CONCAT(b.lastname, ', ', b.firstname) AS payee, " +
                     "l.amount AS total_payable, p.penalty_amount, p.loan_id " +  // Changed from p.amount to l.amount
                     "FROM payments p " +
                     "JOIN loan_list l ON p.loan_id = l.id " +
                     "JOIN borrowers b ON l.borrower_id = b.id " +
                     "ORDER BY p.date_created DESC";

        try (PreparedStatement pst = conn.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

           DefaultTableModel model = new DefaultTableModel(
                new Object[]{"#", "Loan Reference No", "Payee", "Total Payable Amount", "Penalty", "Action", "ID", "Loan ID"}, 
                0
            ) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return column == 5;
                }
            };

            int sequence = 1;
            while (rs.next()) {
                int loanId = rs.getInt("loan_id");
                
                if (processedLoanIds.contains(loanId)) {
                    continue;
                }
                
                processedLoanIds.add(loanId);
                
                String totalPayable = String.format("₱%,.2f", rs.getDouble("total_payable"));  // Changed from amount to total_payable
                String penalty = String.format("₱%,.2f", rs.getDouble("penalty_amount"));

                model.addRow(new Object[]{
                    sequence++,
                    rs.getString("ref_no"),
                    rs.getString("payee"),
                    totalPayable,  // Now showing loan amount instead of payment amount
                    penalty,
                    "buttons",
                    rs.getInt("id"),
                    loanId
                });
            }

            if (sequence == 1) {
                model.addRow(new Object[]{1, "No payments found", "", "", "", "buttons", -1, -1});
            }

            TablePaymentList.setModel(model);

            // Remove hidden columns instead of just hiding them
            TablePaymentList.removeColumn(TablePaymentList.getColumnModel().getColumn(6));
            TablePaymentList.removeColumn(TablePaymentList.getColumnModel().getColumn(6));

            // Set renderers
            CenteredTableCellRenderer centerRenderer = new CenteredTableCellRenderer();
            TablePaymentList.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
            TablePaymentList.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);

            RightAlignedTableCellRenderer rightRenderer = new RightAlignedTableCellRenderer();
            TablePaymentList.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);
            TablePaymentList.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);

            TablePaymentList.getColumnModel().getColumn(5).setCellRenderer(new ButtonRenderer());
            TablePaymentList.getColumnModel().getColumn(5).setCellEditor(new ButtonEditor(new JCheckBox()));
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error loading payment data: " + e.getMessage(), 
            "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}
    private void deletePayment(int paymentId) {
    int confirm = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to delete this payment?",
        "Confirm Deletion",
        JOptionPane.YES_NO_OPTION
    );
    
    if (confirm == JOptionPane.YES_OPTION) {
        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                // First get the loan_id and amount from the payment
                String getPaymentSql = "SELECT loan_id, amount FROM payments WHERE id = ?";
                int loanId;
                double amount;
                
                try (PreparedStatement pst = conn.prepareStatement(getPaymentSql)) {
                    pst.setInt(1, paymentId);
                    try (ResultSet rs = pst.executeQuery()) {
                        if (rs.next()) {
                            loanId = rs.getInt("loan_id");
                            amount = rs.getDouble("amount");
                        } else {
                            throw new SQLException("Payment not found");
                        }
                    }
                }
                
                // Restore the amount to the loan
                String updateLoanSql = "UPDATE loan_list SET amount = amount + ? WHERE id = ?";
                try (PreparedStatement pst = conn.prepareStatement(updateLoanSql)) {
                    pst.setDouble(1, amount);
                    pst.setInt(2, loanId);
                    pst.executeUpdate();
                }
                
                // Delete the payment
                String deleteSql = "DELETE FROM payments WHERE id = ?";
                try (PreparedStatement pst = conn.prepareStatement(deleteSql)) {
                    pst.setInt(1, paymentId);
                    pst.executeUpdate();
                }
                
                conn.commit();
                JOptionPane.showMessageDialog(
                    this,
                    "Payment deleted successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
                );
                
                // Refresh the table
                loadPaymentsData();
                refreshSearchConnection();
                
            } catch (SQLException e) {
                conn.rollback();
                JOptionPane.showMessageDialog(
                    this,
                    "Error deleting payment: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                this,
                "Database connection error: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablePaymentList = new javax.swing.JTable();
        LabelPaymentList = new javax.swing.JLabel();
        searchFunction1 = new Function.SearchFunction();
        ButtonNewLender2 = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        TablePaymentList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "#", "Loan References No", "Payee", "Total Payable Amount", "Penalty", "Action"
            }
        ));
        jScrollPane1.setViewportView(TablePaymentList);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 516, Short.MAX_VALUE)
                .addContainerGap())
        );

        LabelPaymentList.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelPaymentList.setText("Payment List");

        ButtonNewLender2.setBackground(new java.awt.Color(0, 102, 255));
        ButtonNewLender2.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        ButtonNewLender2.setForeground(new java.awt.Color(255, 255, 255));
        ButtonNewLender2.setText("+ New Payment");
        ButtonNewLender2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonNewLender2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(LabelPaymentList)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(searchFunction1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ButtonNewLender2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(21, 21, 21))
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(LabelPaymentList))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(ButtonNewLender2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchFunction1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(34, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonNewLender2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonNewLender2ActionPerformed
         Function.NewPayment newPaymentPanel = new Function.NewPayment();
    
    JDialog dialog = new JDialog(
        (JFrame)SwingUtilities.getWindowAncestor(this), 
        "New Payment", 
        Dialog.ModalityType.APPLICATION_MODAL
    );
    
    dialog.setContentPane(newPaymentPanel);
    dialog.pack();
    dialog.setLocationRelativeTo(this);
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    dialog.setVisible(true);
    
    // Only refresh if payment was successfully made
    if (newPaymentPanel.wasPaymentSuccessful()) {
        loadPaymentsData();
    }
    }//GEN-LAST:event_ButtonNewLender2ActionPerformed
        public void refreshData() {
               loadPaymentsData();
           }
        
     
    // Inner classes
    class CenteredTableCellRenderer extends DefaultTableCellRenderer {
        public CenteredTableCellRenderer() {
            setHorizontalAlignment(JLabel.CENTER);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (isSelected) {
                setBackground(new Color(52, 152, 219, 100));
                setForeground(Color.BLACK);
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
                setForeground(Color.BLACK);
            }
            
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            return this;
        }
    }
    
    class RightAlignedTableCellRenderer extends DefaultTableCellRenderer {
        public RightAlignedTableCellRenderer() {
            setHorizontalAlignment(JLabel.RIGHT);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (isSelected) {
                setBackground(new Color(52, 152, 219, 100));
                setForeground(Color.BLACK);
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
                setForeground(Color.BLACK);
            }
            
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            return this;
        }
    }
    
    class ButtonRenderer extends JPanel implements TableCellRenderer {
        private JButton editButton;
        private JButton deleteButton;
        
        public ButtonRenderer() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            
            editButton = new JButton("✏️");
            editButton.setPreferredSize(new Dimension(45, 30));
            editButton.setToolTipText("Edit");
            editButton.setFocusPainted(false);
            editButton.setBorder(BorderFactory.createRaisedBevelBorder());
            editButton.setBackground(new Color(76, 175, 80));
            editButton.setOpaque(true);
            editButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
            
            deleteButton = new JButton("🗑️");
            deleteButton.setPreferredSize(new Dimension(45, 30));
            deleteButton.setToolTipText("Delete");
            deleteButton.setFocusPainted(false);
            deleteButton.setBorder(BorderFactory.createRaisedBevelBorder());
            deleteButton.setBackground(new Color(244, 67, 54));
            deleteButton.setOpaque(true);
            deleteButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
            
            gbc.gridx = 0;
            gbc.insets = new Insets(0, 5, 0, 5);
            add(editButton, gbc);
            
            gbc.gridx = 1;
            add(deleteButton, gbc);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            
            if (isSelected) {
                setBackground(new Color(52, 152, 219, 100));
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
            }
            
            return this;
        }
    }
    
    class ButtonEditor extends DefaultCellEditor {
        private JPanel panel;
        private JButton editButton;
        private JButton deleteButton;
        private int currentRow;
        
        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            panel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            
            editButton = new JButton("✏️");
            editButton.setPreferredSize(new Dimension(45, 30));
            editButton.setBackground(new Color(76, 175, 80));
            editButton.setOpaque(true);
            editButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
            
            deleteButton = new JButton("🗑️");
            deleteButton.setPreferredSize(new Dimension(45, 30));
            deleteButton.setBackground(new Color(244, 67, 54));
            deleteButton.setOpaque(true);
            deleteButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
            
            editButton.addActionListener(e -> {
                fireEditingStopped();
                openEditDialog();
            });
            
            deleteButton.addActionListener(e -> {
                fireEditingStopped();
                openDeleteDialog();
            });
            
            gbc.gridx = 0;
            gbc.insets = new Insets(0, 5, 0, 5);
            panel.add(editButton, gbc);
            
            gbc.gridx = 1;
            panel.add(deleteButton, gbc);
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            currentRow = row;
            return panel;
        }
        
        @Override
        public Object getCellEditorValue() {
            return "buttons";
        }
        
       private void openEditDialog() {
    DefaultTableModel model = (DefaultTableModel) TablePaymentList.getModel();
    int modelRow = TablePaymentList.convertRowIndexToModel(currentRow);
    int paymentId = (Integer) model.getValueAt(modelRow, 6);
    
  Function.EditPaymentFunction editPaymentPanel = new Function.EditPaymentFunction(paymentId);
    JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(Payment.this), 
                               "Edit Payment", true);
    dialog.setContentPane(editPaymentPanel);
    dialog.pack();
    dialog.setLocationRelativeTo(Payment.this);
    dialog.setVisible(true);
    loadPaymentsData();
    refreshSearchConnection();
}
        
       private void openDeleteDialog() {
        DefaultTableModel model = (DefaultTableModel) TablePaymentList.getModel();
        int modelRow = TablePaymentList.convertRowIndexToModel(currentRow);
        int paymentId = (Integer) model.getValueAt(modelRow, 6);
        
        deletePayment(paymentId);
    
            
            // Function.DeletePayment deletePaymentPanel = new Function.DeletePayment(paymentId);
           // JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(Payment.this), 
            //                           "Delete Payment", true);
            // dialog.setContentPane(deletePaymentPanel);
//            dialog.pack();
//            dialog.setLocationRelativeTo(Payment.this);
//            dialog.setVisible(true);
//            loadPaymentsData();
//            refreshSearchConnection();
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonNewLender2;
    private javax.swing.JLabel LabelPaymentList;
    private javax.swing.JTable TablePaymentList;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private Function.SearchFunction searchFunction1;
    // End of variables declaration//GEN-END:variables
}

