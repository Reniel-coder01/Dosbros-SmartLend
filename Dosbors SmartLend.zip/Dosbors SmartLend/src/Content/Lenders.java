package Content;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableCellEditor;
import javax.swing.table.JTableHeader;
import javax.swing.JOptionPane;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Lenders extends javax.swing.JPanel {
    
    public Lenders() {
        initComponents();
        setupTable();
        loadLendersData();
        customizeTableAppearance();
        connectSearchFunction();
    }
    
    private void connectSearchFunction() {
        if (searchFunction2 != null) {
            searchFunction2.setTargetTable(jTable1);
        }
    }
    
    // Refresh search connection after loading data
    private void refreshSearchConnection() {
        if (searchFunction2 != null) {
            searchFunction2.setTargetTable(jTable1);
        }
    }
    
    private void setupTable() {
        jTable1.setRowHeight(150);
        
        jTable1.getColumnModel().getColumn(0).setPreferredWidth(50);
        jTable1.getColumnModel().getColumn(1).setPreferredWidth(300);
        jTable1.getColumnModel().getColumn(2).setPreferredWidth(120);
        jTable1.getColumnModel().getColumn(3).setPreferredWidth(150);
        jTable1.getColumnModel().getColumn(4).setPreferredWidth(160);
        
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
    }
    
    private void customizeTableAppearance() {
        JTableHeader header = jTable1.getTableHeader();
        header.setFont(new Font("SansSerif", Font.BOLD, 14));
        header.setForeground(Color.WHITE);
        header.setBackground(new Color(41, 128, 185));
        header.setPreferredSize(new Dimension(header.getPreferredSize().width, 45));
        
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setFont(new Font("SansSerif", Font.BOLD, 14));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setBackground(new Color(41, 128, 185));
        header.setDefaultRenderer(headerRenderer);
        
        jTable1.setFont(new Font("SansSerif", Font.PLAIN, 15));
        jTable1.setSelectionBackground(new Color(52, 152, 219, 100));
        jTable1.setSelectionForeground(Color.BLACK);
        jTable1.setShowGrid(true);
        jTable1.setGridColor(new Color(230, 230, 230));
        jTable1.setIntercellSpacing(new Dimension(1, 1));
        
        jTable1.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int row = jTable1.rowAtPoint(e.getPoint());
                if (row >= 0) {
                    jTable1.setRowSelectionInterval(row, row);
                } else {
                    jTable1.clearSelection();
                }
            }
        });
        
        jTable1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
                jTable1.clearSelection();
            }
        });
    }
    
    class CenteredTableCellRenderer extends DefaultTableCellRenderer {
        public CenteredTableCellRenderer() {
            setHorizontalAlignment(JLabel.CENTER);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (isSelected) {
                setBackground(new Color(52, 152, 219, 100));
                setForeground(Color.BLACK);
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
                setForeground(Color.BLACK);
            }
            
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            return this;
        }
    }
    
    class ButtonRenderer extends JPanel implements TableCellRenderer {
        private JButton editButton;
        private JButton deleteButton;
        
        public ButtonRenderer() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            
            editButton = new JButton("✏️");
            editButton.setPreferredSize(new Dimension(45, 45));
            editButton.setMinimumSize(new Dimension(45, 45));
            editButton.setMaximumSize(new Dimension(45, 45));
            editButton.setToolTipText("Edit");
            editButton.setFocusPainted(false);
            editButton.setBorder(BorderFactory.createRaisedBevelBorder());
            editButton.setBackground(new Color(76, 175, 80));
            editButton.setOpaque(true);
            editButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16));
            editButton.setHorizontalAlignment(SwingConstants.CENTER);
            editButton.setVerticalAlignment(SwingConstants.CENTER);
            editButton.setMargin(new Insets(0, 0, 0, 0));
            
            deleteButton = new JButton("🗑️");
            deleteButton.setPreferredSize(new Dimension(45, 45));
            deleteButton.setMinimumSize(new Dimension(45, 45));
            deleteButton.setMaximumSize(new Dimension(45, 45));
            deleteButton.setToolTipText("Delete");
            deleteButton.setFocusPainted(false);
            deleteButton.setBorder(BorderFactory.createRaisedBevelBorder());
            deleteButton.setBackground(new Color(244, 67, 54));
            deleteButton.setOpaque(true);
            deleteButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16));
            deleteButton.setHorizontalAlignment(SwingConstants.CENTER);
            deleteButton.setVerticalAlignment(SwingConstants.CENTER);
            deleteButton.setMargin(new Insets(0, 0, 0, 0));
            
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.insets = new Insets(0, 5, 0, 5);
            add(editButton, gbc);
            
            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.insets = new Insets(0, 5, 0, 5);
            add(deleteButton, gbc);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            
            if (isSelected) {
                setBackground(new Color(52, 152, 219, 100));
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
            }
            
            return this;
        }
    }
    
    class ButtonEditor extends DefaultCellEditor {
        private JPanel panel;
        private JButton editButton;
        private JButton deleteButton;
        private int currentRow;
        
        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            panel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            
            editButton = new JButton("✏️");
            editButton.setPreferredSize(new Dimension(45, 45));
            editButton.setBackground(new Color(76, 175, 80));
            editButton.setOpaque(true);
            editButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16));
            editButton.setMargin(new Insets(0, 0, 0, 0));
            
            deleteButton = new JButton("🗑️");
            deleteButton.setPreferredSize(new Dimension(45, 45));
            deleteButton.setBackground(new Color(244, 67, 54));
            deleteButton.setOpaque(true);
            deleteButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16));
            deleteButton.setMargin(new Insets(0, 0, 0, 0));
            
            editButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    openEditDialog();
                }
            });
            
            deleteButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    openDeleteDialog();
                }
            });
            
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.insets = new Insets(0, 5, 0, 5);
            panel.add(editButton, gbc);
            
            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.insets = new Insets(0, 5, 0, 5);
            panel.add(deleteButton, gbc);
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            currentRow = row;
            return panel;
        }
        
        @Override
        public Object getCellEditorValue() {
            return "buttons";
        }
        
        private void openEditDialog() {
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            // Convert view row to model row (important for filtered tables)
            int modelRow = jTable1.convertRowIndexToModel(currentRow);
            int lenderId = (Integer) model.getValueAt(modelRow, 5);
            
            Function.EditLendersFunction editLenderPanel = new Function.EditLendersFunction(lenderId);
            JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(Lenders.this), "Edit Lender", true);
            dialog.setContentPane(editLenderPanel);
            dialog.pack();
            dialog.setLocationRelativeTo(Lenders.this);
            dialog.setVisible(true);
            loadLendersData();
            refreshSearchConnection();
        }
        
        private void openDeleteDialog() {
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            // Convert view row to model row (important for filtered tables)
            int modelRow = jTable1.convertRowIndexToModel(currentRow);
            int lenderId = (Integer) model.getValueAt(modelRow, 5);
            
            Function.DeleteLenders deleteLenderPanel = new Function.DeleteLenders(lenderId);
            JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(Lenders.this), "Delete Lender", true);
            dialog.setContentPane(deleteLenderPanel);
            dialog.pack();
            dialog.setLocationRelativeTo(Lenders.this);
            dialog.setVisible(true);
            loadLendersData();
            refreshSearchConnection();
        }
    }
    
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/java_user_database", "root", "");
    }
    
private void loadLendersData() {
    try (Connection conn = getConnection()) {
        // Query to get lenders with their loan information
        String sql = "SELECT b.id, b.lastname, b.firstname, b.middlename, b.address, " +
                     "b.contact_no, b.email, b.tax_id, " +
                     "ll.amount, ll.status, ll.date_released, " +
                     "lp.months, lp.interest_percentage " +
                     "FROM borrowers b " +
                     "LEFT JOIN loan_list ll ON b.id = ll.borrower_id " +
                     "LEFT JOIN loan_plan lp ON ll.plan_id = lp.id " +
                     "ORDER BY b.id DESC";
        
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);
        model.setColumnIdentifiers(new String[]{"#", "Lenders", "Current Lend", "Next Payment Schedule", "Action", "ID"});
        
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("en", "PH"));
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
        
        int sequence = 1;
        while (rs.next()) {
            String lenderInfo = String.format(
                "<html><div style='padding:8px; font-family:Arial;'>" +
                "<b>%s, %s %s</b><br/>" +
                "<small>📍 %s<br/>" +
                "📞 %s<br/>" +
                "✉️ %s<br/>" +
                "🆔 %s</small></div></html>",
                rs.getString("lastname") != null ? rs.getString("lastname") : "N/A",
                rs.getString("firstname") != null ? rs.getString("firstname") : "N/A",
                rs.getString("middlename") != null ? rs.getString("middlename") : "",
                rs.getString("address") != null ? rs.getString("address") : "N/A",
                rs.getString("contact_no") != null ? rs.getString("contact_no") : "N/A",
                rs.getString("email") != null ? rs.getString("email") : "N/A",
                rs.getString("tax_id") != null ? rs.getString("tax_id") : "N/A"
            );
            
            // Current Lend details
            String currentLend = "No active loan";
            if (rs.getDouble("amount") > 0) {
                currentLend = String.format(
                    "<html><div style='padding:5px; font-family:Arial;'>" +
                    "<b>Amount: %s</b><br/>" +
                    "<small>Status: %s<br/>" +
                    "Term: %d months<br/>" +
                    "Rate: %.1f%%</small></div></html>",
                    currencyFormat.format(rs.getDouble("amount")),
                    getStatusText(rs.getInt("status")),
                    rs.getInt("months"),
                    rs.getFloat("interest_percentage")
                );
            }
            
            // Next Payment details
            String nextPayment = "N/A";
if (rs.getInt("status") == 2) { // Released status
    Timestamp releasedDate = rs.getTimestamp("date_released");
    if (releasedDate != null) {
        Calendar nextPaymentDate = Calendar.getInstance();
        nextPaymentDate.setTime(releasedDate);
        nextPaymentDate.add(Calendar.DATE, 30);

        // ✅ Simple interest calculation
        double amount = rs.getDouble("amount"); // principal
        int months = rs.getInt("months");
        float interestRate = rs.getFloat("interest_percentage");

        double totalInterest = amount * (interestRate / 100);
        double totalPayable = amount + totalInterest;
        double monthlyPayment = totalPayable / months;

        nextPayment = String.format(
            "<html><div style='padding:5px; font-family:Arial;'>" +
            "<b>Next Payment: %s</b><br/>" +
            "<small>Amount: %s</small></div></html>",
            dateFormat.format(nextPaymentDate.getTime()),
            currencyFormat.format(monthlyPayment)
        );
    }
}

            
            Object[] row = {
                sequence++, 
                lenderInfo, 
                currentLend, 
                nextPayment, 
                "buttons", 
                rs.getInt("id")
            };
            model.addRow(row);
        }
        
        if (model.getRowCount() == 0) {
            Object[] emptyRow = {1, "No lenders found", "N/A", "N/A", "buttons", -1};
            model.addRow(emptyRow);
        }
        
        // Hide the ID column
        jTable1.getColumnModel().getColumn(5).setMinWidth(0);
        jTable1.getColumnModel().getColumn(5).setMaxWidth(0);
        jTable1.getColumnModel().getColumn(5).setWidth(0);
        
        jTable1.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer());
        jTable1.getColumnModel().getColumn(4).setCellEditor(new ButtonEditor(new JCheckBox()));
        
        CenteredTableCellRenderer centerRenderer = new CenteredTableCellRenderer();
        jTable1.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, 
            "Database error: " + e.getMessage(), 
            "Error", 
            JOptionPane.ERROR_MESSAGE);
    }
}
// Helper method to convert status code to text
private String getStatusText(int status) {
    switch (status) {
        case 0: return "Request";
        case 1: return "Confirmed";
        case 2: return "Released";
        case 3: return "Completed";
        case 4: return "Denied";
        default: return "Unknown";
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        searchFunction2 = new Function.SearchFunction();
        ButtonNewLender = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "#", "Lenders", "Current Lend", "Next Payment Schedule", "Action"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(73, 73, 73))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setText("Lenders List");

        searchFunction2.setBackground(new java.awt.Color(255, 255, 255));

        ButtonNewLender.setBackground(new java.awt.Color(0, 102, 255));
        ButtonNewLender.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        ButtonNewLender.setForeground(new java.awt.Color(255, 255, 255));
        ButtonNewLender.setText("+ New Lender");
        ButtonNewLender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonNewLenderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ButtonNewLender)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(searchFunction2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(ButtonNewLender)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchFunction2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(101, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(133, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonNewLenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonNewLenderActionPerformed
         Function.NewLendersFunction newLenderPanel = new Function.NewLendersFunction();
        JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), "New Lender", true);
        dialog.setContentPane(newLenderPanel);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
        // Refresh table after dialog closes
        loadLendersData();
        refreshSearchConnection();
    }//GEN-LAST:event_ButtonNewLenderActionPerformed

public void refreshData() {
        loadLendersData();
        refreshSearchConnection();
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonNewLender;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private Function.SearchFunction searchFunction2;
    // End of variables declaration//GEN-END:variables
}
