package Content;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import Function.EditFunction;
import Function.DeleteFunction;
import Function.AddUser;

public class Users extends javax.swing.JPanel {
    
    public Users() {
        initComponents();
        fetchUserData();
        customizeTableAppearance();
    }
    
    private void fetchUserData() {
        DefaultTableModel model = new DefaultTableModel(new Object[]{"User ID", "Full Name", "Email Address", "User Role", "Actions"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return (columnIndex == 4) ? JPanel.class : String.class;
            }
            
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4;
            }
        };
        
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_user_database", "root", "");
            st = con.createStatement();
            rs = st.executeQuery("SELECT * FROM user");
            
            while (rs.next()) {
                int id = rs.getInt("id");
                String fullName = rs.getString("full_name");
                String email = rs.getString("email");
                int type = rs.getInt("type");
                String userRole = (type == 1) ? "Admin" : "Staff";
                
                JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 3, 2));
                buttonPanel.setOpaque(true);
                
                JButton editBtn = createStyledButton("Edit", new Color(52, 152, 219), Color.WHITE);
                JButton deleteBtn = createStyledButton("Delete", new Color(231, 76, 60), Color.WHITE);
                
                editBtn.addActionListener(e -> {
                    JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), true);
                    dialog.setUndecorated(true);
                    
                    EditFunction editPanel = new EditFunction(id, fullName, email, type);
                    
                    JPanel containerPanel = new JPanel(new BorderLayout());
                    containerPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
                    containerPanel.setBackground(Color.WHITE);
                    containerPanel.add(editPanel, BorderLayout.CENTER);
                    
                    dialog.setContentPane(containerPanel);
                    dialog.setSize(424, 466);
                    dialog.setLocationRelativeTo(null);
                    dialog.setVisible(true);
                    
                    // Refresh table after dialog closes
                    SwingUtilities.invokeLater(() -> {
                        fetchUserData();
                        applyCenterAlignment();
                    });
                });
                
                deleteBtn.addActionListener(e -> {
                    JDialog deleteDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), true);
                    deleteDialog.setUndecorated(true);
                    
                    DeleteFunction deletePanel = new DeleteFunction(id, fullName, deleteDialog, this);
                    
                    JPanel containerPanel = new JPanel(new BorderLayout());
                    containerPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
                    containerPanel.setBackground(Color.WHITE);
                    containerPanel.add(deletePanel, BorderLayout.CENTER);
                    
                    deleteDialog.setContentPane(containerPanel);
                    deleteDialog.setSize(422, 185);
                    deleteDialog.setLocationRelativeTo(null);
                    deleteDialog.setVisible(true);
                });
                
                buttonPanel.add(editBtn);
                buttonPanel.add(deleteBtn);
                
                model.addRow(new Object[]{id, fullName, email, userRole, buttonPanel});
            }
            
            jTable1.setModel(model);
            jTable1.getColumn("Actions").setCellRenderer(new ButtonPanelRenderer());
            jTable1.getColumn("Actions").setCellEditor(new ButtonPanelEditor());
            
            applyCenterAlignment();
            
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading user data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Always close resources
            try {
                if (rs != null) rs.close();
                if (st != null) st.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void refreshTable() {
        SwingUtilities.invokeLater(() -> {
            fetchUserData();
            applyCenterAlignment();
        });
    }
    
    private JButton createStyledButton(String text, Color bgColor, Color fgColor) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(text.equals("Edit") ? 65 : 75, 28));
        button.setFont(new Font("SansSerif", Font.PLAIN, 12));
        button.setBackground(bgColor);
        button.setForeground(fgColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        Color originalBg = bgColor;
        Color hoverBg = bgColor.darker();
        
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(hoverBg);
                Point p = SwingUtilities.convertPoint(button, e.getPoint(), jTable1);
                int row = jTable1.rowAtPoint(p);
                if (row >= 0) {
                    jTable1.setRowSelectionInterval(row, row);
                }
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(originalBg);
                jTable1.clearSelection();
            }
        });
        
        return button;
    }
    
    private void customizeTableAppearance() {
        JTableHeader header = jTable1.getTableHeader();
        header.setFont(new Font("SansSerif", Font.BOLD, 14));
        header.setForeground(Color.WHITE);
        header.setBackground(new Color(41, 128, 185));
        header.setPreferredSize(new Dimension(header.getPreferredSize().width, 45));
        
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setFont(new Font("SansSerif", Font.BOLD, 14));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setBackground(new Color(41, 128, 185));
        header.setDefaultRenderer(headerRenderer);
        
        jTable1.setRowHeight(40);
        jTable1.setFont(new Font("SansSerif", Font.PLAIN, 14));
        jTable1.setSelectionBackground(new Color(52, 152, 219, 100));
        jTable1.setSelectionForeground(Color.BLACK);
        jTable1.setShowGrid(true);
        jTable1.setGridColor(new Color(230, 230, 230));
        jTable1.setIntercellSpacing(new Dimension(1, 1));
        
        jTable1.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int row = jTable1.rowAtPoint(e.getPoint());
                if (row >= 0) {
                    jTable1.setRowSelectionInterval(row, row);
                } else {
                    jTable1.clearSelection();
                }
            }
        });
        
        jTable1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
                jTable1.clearSelection();
            }
        });
    }
    
    private void applyCenterAlignment() {
        if (jTable1.getColumnCount() > 0) {
            CenteredTableCellRenderer centerRenderer = new CenteredTableCellRenderer();
            
            for (int i = 0; i < jTable1.getColumnCount() - 1; i++) {
                jTable1.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
                jTable1.getColumnModel().getColumn(i).setPreferredWidth(150);
            }
            jTable1.getColumnModel().getColumn(4).setPreferredWidth(180);
        }
    }
    
    class CenteredTableCellRenderer extends DefaultTableCellRenderer {
        public CenteredTableCellRenderer() {
            setHorizontalAlignment(JLabel.CENTER);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (isSelected) {
                setBackground(new Color(52, 152, 219, 100));
                setForeground(Color.BLACK);
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
                setForeground(Color.BLACK);
            }
            
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            return this;
        }
    }
    
    class ButtonPanelRenderer implements TableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            if (value instanceof JPanel) {
                JPanel panel = (JPanel) value;
                
                if (isSelected) {
                    panel.setBackground(new Color(52, 152, 219, 100));
                } else {
                    panel.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
                }
                
                return panel;
            }
            return new JPanel();
        }
    }
    
    class ButtonPanelEditor extends DefaultCellEditor {
        private JPanel currentPanel;
        
        public ButtonPanelEditor() {
            super(new JCheckBox());
            setClickCountToStart(1);
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            if (value instanceof JPanel) {
                currentPanel = (JPanel) value;
                return currentPanel;
            }
            return new JPanel();
        }
        
        @Override
        public Object getCellEditorValue() {
            return currentPanel;
        }
        
        @Override
        public boolean stopCellEditing() {
            return super.stopCellEditing();
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "#", "Name", "Username", "Role", "Action"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton2.setBackground(new java.awt.Color(0, 102, 255));
        jButton2.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("+ Add User");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton2)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1101, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(59, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 555, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), true);
    dialog.setUndecorated(true);
    
    AddUser addPanel = new AddUser();
    
    JPanel containerPanel = new JPanel(new BorderLayout());
    containerPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
    containerPanel.setBackground(Color.WHITE);
    containerPanel.add(addPanel, BorderLayout.CENTER);
    
    dialog.setContentPane(containerPanel);
    dialog.setSize(413, 523);
    dialog.setLocationRelativeTo(null);
    dialog.setVisible(true);
    
    // Refresh the table after the dialog is closed
    fetchUserData();
    SwingUtilities.invokeLater(() -> applyCenterAlignment());
    }//GEN-LAST:event_jButton2ActionPerformed

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
