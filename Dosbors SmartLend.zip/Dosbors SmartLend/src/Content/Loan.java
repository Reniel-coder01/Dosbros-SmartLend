package Content;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.JOptionPane;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.util.Locale;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
//import Function.ContractPaperPanel;

public class Loan extends javax.swing.JPanel {
    private double interestRate;

    
    public Loan() {
        initComponents();
        setupTable();
        loadLoanData();
        customizeTableAppearance();
        connectSearchFunction();
        
        Timer refreshTimer = new Timer(5000, e -> loadLoanData());
        refreshTimer.start();
    }
    
    private void connectSearchFunction() {
        if (searchFunction1 != null) {
            searchFunction1.setTargetTable(SmartlendListTable);
        }
    }
    
    // Refresh search connection after loading data
    private void refreshSearchConnection() {
        if (searchFunction1 != null) {
            searchFunction1.setTargetTable(SmartlendListTable);
        }
    }
    
    private void setupTable() {
        SmartlendListTable.setRowHeight(150);
        
        SmartlendListTable.getColumnModel().getColumn(0).setPreferredWidth(80);  // Number
        SmartlendListTable.getColumnModel().getColumn(1).setPreferredWidth(300); // Lenders
        SmartlendListTable.getColumnModel().getColumn(2).setPreferredWidth(200); // Lend Details
        SmartlendListTable.getColumnModel().getColumn(3).setPreferredWidth(180); // Next Payment Details
        SmartlendListTable.getColumnModel().getColumn(4).setPreferredWidth(100); // Status
        SmartlendListTable.getColumnModel().getColumn(5).setPreferredWidth(160); // Action
        
        SmartlendListTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
    }
    
    private void customizeTableAppearance() {
        JTableHeader header = SmartlendListTable.getTableHeader();
        header.setFont(new Font("SansSerif", Font.BOLD, 14));
        header.setForeground(Color.WHITE);
        header.setBackground(new Color(41, 128, 185));
        header.setPreferredSize(new Dimension(header.getPreferredSize().width, 45));
        
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setFont(new Font("SansSerif", Font.BOLD, 14));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setBackground(new Color(41, 128, 185));
        header.setDefaultRenderer(headerRenderer);
        
        SmartlendListTable.setFont(new Font("SansSerif", Font.PLAIN, 14)); 
        SmartlendListTable.setSelectionBackground(new Color(52, 152, 219, 100));
        SmartlendListTable.setSelectionForeground(Color.BLACK);
        SmartlendListTable.setShowGrid(true);
        SmartlendListTable.setGridColor(new Color(230, 230, 230));
        SmartlendListTable.setIntercellSpacing(new Dimension(1, 1));
        
        SmartlendListTable.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int row = SmartlendListTable.rowAtPoint(e.getPoint());
                if (row >= 0) {
                    SmartlendListTable.setRowSelectionInterval(row, row);
                } else {
                    SmartlendListTable.clearSelection();
                }
            }
        });
        
        SmartlendListTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
                SmartlendListTable.clearSelection();
            }
        });
    }
    
    class CenteredTableCellRenderer extends DefaultTableCellRenderer {
        public CenteredTableCellRenderer() {
            setHorizontalAlignment(JLabel.CENTER);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (isSelected) {
                setBackground(new Color(52, 152, 219, 100));
                setForeground(Color.BLACK);
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
                setForeground(Color.BLACK);
            }
            
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            return this;
        }
    }
    
    class StatusCellRenderer extends DefaultTableCellRenderer {
        public StatusCellRenderer() {
            setHorizontalAlignment(JLabel.CENTER);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            String status = value.toString();
            Color statusColor = Color.BLACK;
            
            switch (status) {
                case "Request":
                    statusColor = new Color(255, 193, 7); // Yellow
                    break;
                case "Confirmed":
                    statusColor = new Color(0, 123, 255); // Blue
                    break;
                case "Released":
                    statusColor = new Color(40, 167, 69); // Green
                    break;
                case "Completed":
                    statusColor = new Color(108, 117, 125); // Gray
                    break;
                case "Denied":
                    statusColor = new Color(220, 53, 69); // Red
                    break;
            }
            
            setForeground(statusColor);
            setFont(new Font("SansSerif", Font.BOLD, 12));
            
            if (isSelected) {
                setBackground(new Color(52, 152, 219, 100));
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
            }
            
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            return this;
        }
    }
    
    class ButtonRenderer extends JPanel implements TableCellRenderer {
        private JButton viewButton;
        private JButton editButton;
        private JButton deleteButton;
        
        public ButtonRenderer() {
            setLayout(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            
            viewButton = new JButton("👁️");
            viewButton.setPreferredSize(new Dimension(35, 35));
            viewButton.setToolTipText("View");
            viewButton.setFocusPainted(false);
            viewButton.setBorder(BorderFactory.createRaisedBevelBorder());
            viewButton.setBackground(new Color(23, 162, 184));
            viewButton.setOpaque(true);
            viewButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
            viewButton.setMargin(new Insets(0, 0, 0, 0));
            
            editButton = new JButton("✏️");
            editButton.setPreferredSize(new Dimension(35, 35));
            editButton.setToolTipText("Edit");
            editButton.setFocusPainted(false);
            editButton.setBorder(BorderFactory.createRaisedBevelBorder());
            editButton.setBackground(new Color(76, 175, 80));
            editButton.setOpaque(true);
            editButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
            editButton.setMargin(new Insets(0, 0, 0, 0));
            
            deleteButton = new JButton("🗑️");
            deleteButton.setPreferredSize(new Dimension(35, 35));
            deleteButton.setToolTipText("Delete");
            deleteButton.setFocusPainted(false);
            deleteButton.setBorder(BorderFactory.createRaisedBevelBorder());
            deleteButton.setBackground(new Color(244, 67, 54));
            deleteButton.setOpaque(true);
            deleteButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
            deleteButton.setMargin(new Insets(0, 0, 0, 0));
            
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.insets = new Insets(0, 2, 0, 2);
            add(viewButton, gbc);
            
            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.insets = new Insets(0, 2, 0, 2);
            add(editButton, gbc);
            
            gbc.gridx = 2;
            gbc.gridy = 0;
            gbc.insets = new Insets(0, 2, 0, 2);
            add(deleteButton, gbc);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            
            if (isSelected) {
                setBackground(new Color(52, 152, 219, 100));
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
            }
            
            return this;
        }
    }
    
    class ButtonEditor extends DefaultCellEditor {
        private JPanel panel;
        private JButton viewButton;
        private JButton editButton;
        private JButton deleteButton;
        private int currentRow;
        
        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            panel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            
            viewButton = new JButton("👁️");
            viewButton.setPreferredSize(new Dimension(35, 35));
            viewButton.setBackground(new Color(23, 162, 184));
            viewButton.setOpaque(true);
            viewButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
            viewButton.setMargin(new Insets(0, 0, 0, 0));
            
            editButton = new JButton("✏️");
            editButton.setPreferredSize(new Dimension(35, 35));
            editButton.setBackground(new Color(76, 175, 80));
            editButton.setOpaque(true);
            editButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
            editButton.setMargin(new Insets(0, 0, 0, 0));
            
            deleteButton = new JButton("🗑️");
            deleteButton.setPreferredSize(new Dimension(35, 35));
            deleteButton.setBackground(new Color(244, 67, 54));
            deleteButton.setOpaque(true);
            deleteButton.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
            deleteButton.setMargin(new Insets(0, 0, 0, 0));
            
            viewButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    openViewDialog();
                }
            });
            
            editButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    openEditDialog();
                }
            });
            
            deleteButton.addActionListener(e -> {
                fireEditingStopped();
                
                DefaultTableModel model = (DefaultTableModel) SmartlendListTable.getModel();
                int modelRow = SmartlendListTable.convertRowIndexToModel(currentRow);
                int loanId = (Integer) model.getValueAt(modelRow, 6); // Column 6 = hidden ID
                
                JDialog dialog = new JDialog(
                    (JFrame)SwingUtilities.getWindowAncestor(Loan.this), 
                    "Delete Confirmation", 
                    true
                );
                dialog.add(new Function.DeleteLenders(loanId, false)); // false = loan mode
                dialog.pack();
                dialog.setLocationRelativeTo(Loan.this);
                dialog.setVisible(true);
                
                loadLoanData(); // Refresh table after dialog closes
            });
            
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.insets = new Insets(0, 2, 0, 2);
            panel.add(viewButton, gbc);
            
            gbc.gridx = 1;
            gbc.gridy = 0;
            gbc.insets = new Insets(0, 2, 0, 2);
            panel.add(editButton, gbc);
            
            gbc.gridx = 2;
            gbc.gridy = 0;
            gbc.insets = new Insets(0, 2, 0, 2);
            panel.add(deleteButton, gbc);
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            currentRow = row;
            return panel;
        }
        
        @Override
        public Object getCellEditorValue() {
            return "buttons";
        }

        private void openViewDialog() {
    DefaultTableModel model = (DefaultTableModel) SmartlendListTable.getModel();
    int modelRow = SmartlendListTable.convertRowIndexToModel(currentRow);
    int loanId = (Integer) model.getValueAt(modelRow, 6); // Hidden ID column

    try {
        // Get loan details from the database
        ResultSet loanDetails = getLoanDetails(loanId);

        if (loanDetails != null && loanDetails.next()) {
            // Create the contract panel
            Function.ContractPaperPanel contractPanel = new Function.ContractPaperPanel();

            // Generate the contract text and set it to the panel
            String contractText = contractPanel.generateContractText(loanDetails);
            contractPanel.setContractText(contractText); // You must implement this in ContractPaperPanel

            // Create the dialog
            JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(SmartlendListTable), "Loan Contract", true);
            dialog.setContentPane(contractPanel);
            dialog.setSize(650, 600);
            dialog.setLocationRelativeTo(SmartlendListTable); // Or Loan.this if accessible
            dialog.setResizable(false);
            dialog.setVisible(true);
            
        } else {
            JOptionPane.showMessageDialog(SmartlendListTable,
                "Could not load loan details for contract view.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(SmartlendListTable,
            "Database error: " + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}
        
        private void openEditDialog() {
             DefaultTableModel model = (DefaultTableModel) SmartlendListTable.getModel();
    int modelRow = SmartlendListTable.convertRowIndexToModel(currentRow);
    int loanId = (Integer) model.getValueAt(modelRow, 6); // Hidden ID column
    
    try {
        ResultSet loanDetails = getLoanDetails(loanId);
        
        if (loanDetails != null && loanDetails.next()) {
            Function.EditApplication editLoanPanel = new Function.EditApplication();
            editLoanPanel.setEditingLoanId(loanId); // Add this line to initialize edit mode
            
            editLoanPanel.setLoanAmount(loanDetails.getDouble("amount"));
            editLoanPanel.setPurpose(loanDetails.getString("purpose"));
                    
                    String taxId = loanDetails.getString("tax_id");
                    if (taxId != null) {
                        editLoanPanel.selectBorrowerByTaxId(taxId);
                    }
                    
                    int loanTypeId = loanDetails.getInt("loan_type_id");
                    editLoanPanel.selectLoanType(loanTypeId);
                    
                    int planId = loanDetails.getInt("plan_id");
                    editLoanPanel.selectLoanPlan(planId);
                    
                    int status = loanDetails.getInt("status");
                    editLoanPanel.setStatus(status);
                    
                    JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(Loan.this), "Edit Loan Application", true);
                    dialog.setContentPane(editLoanPanel);
                    dialog.setSize(650, 600);
                    dialog.setLocationRelativeTo(Loan.this);
                    dialog.setResizable(false);
                    
                    editLoanPanel.addPropertyChangeListener("loanSaved", evt -> {
                        if ((Boolean) evt.getNewValue()) {
                            loadLoanData();
                            refreshSearchConnection();
                        }
                    });
                    
                    dialog.setVisible(true);
                    
                } else {
                    JOptionPane.showMessageDialog(Loan.this,
                        "Could not load loan details for editing.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(Loan.this,
                    "Database error: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }
    
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/java_user_database", "root", "");
    }
    
   private void deleteLoan(int loanId) {
    try (Connection conn = getConnection()) {
        // First delete payment history
        String deletePayments = "DELETE FROM payment_history WHERE loan_id = ?";
        try (PreparedStatement pst = conn.prepareStatement(deletePayments)) {
            pst.setInt(1, loanId);
            pst.executeUpdate();
        }
        
        // Then delete the loan
        String deleteLoan = "DELETE FROM loan_list WHERE id = ?";
        try (PreparedStatement pst = conn.prepareStatement(deleteLoan)) {
            pst.setInt(1, loanId);
            
            int result = pst.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Loan deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadLoanData();
                refreshSearchConnection();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete loan.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    
    private String getStatusText(int status) {
        switch (status) {
            case 0: return "Request";
            case 1: return "Confirmed";
            case 2: return "Released";
            case 3: return "Completed";
            case 4: return "Denied";
            default: return "Unknown";
        }
    }
    
    // Updated loan details calculation (using amortized interest)
     private String getLoanDetailsHtml(ResultSet rs, NumberFormat currencyFormat, SimpleDateFormat dateFormat) throws SQLException {
    double amount = rs.getDouble("amount");
    int months = rs.getInt("months");
    float interestRate = rs.getFloat("interest_percentage");

    // Simple interest calculation (to match calculateLoan)
    double totalInterest = amount * (interestRate / 100);
    double totalPayable = amount + totalInterest;
    double monthlyPayment = totalPayable / months;

    return String.format(
        "<html><div style='padding:8px; font-family:Arial;'>" +
        "<b>Ref: %s</b><br/>" +
        "<b>Amount: %s</b><br/>" +
        "<small>Type: %s<br/>" +
        "Purpose: %s<br/>" +
        "Plan: %d months @ %.1f%%<br/>" +
        "Total Payable: %s (Interest: %s)<br/>" +
        "Monthly Payment: %s<br/>" +
        "Date Released: %s<br/>" +
        "Applied: %s</small></div></html>",
        rs.getString("ref_no") != null ? rs.getString("ref_no") : "N/A",
        currencyFormat.format(amount),
        rs.getString("type_name") != null ? rs.getString("type_name") : "N/A",
        rs.getString("purpose") != null ? rs.getString("purpose") : "N/A",
        months,
        interestRate,
        currencyFormat.format(totalPayable),
        currencyFormat.format(totalInterest),
        currencyFormat.format(monthlyPayment),
        rs.getTimestamp("date_released") != null ? 
            dateFormat.format(rs.getTimestamp("date_released")) : "Not Released",
        rs.getTimestamp("date_created") != null ? 
            dateFormat.format(rs.getTimestamp("date_created")) : "N/A"
    );
}

    
    // Updated loadLoanData() method
    private void loadLoanData() {
        DefaultTableModel model = (DefaultTableModel) SmartlendListTable.getModel();
        model.setRowCount(0);
        model.setColumnIdentifiers(new String[]{"Number", "Lenders", "Lend Details", "Next Payment Details", "Status", "Action", "ID"});
        
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("en", "PH"));
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
        
        try (Connection conn = getConnection();
             PreparedStatement pst = conn.prepareStatement(getLoanQuery());
             ResultSet rs = pst.executeQuery()) {
            
            int sequence = 1;
            while (rs.next()) {
                String borrowerInfo = getBorrowerInfoHtml(rs);
                String loanDetails = getLoanDetailsHtml(rs, currencyFormat, dateFormat);
                String nextPayment = getNextPaymentHtml(rs, currencyFormat, dateFormat);
                
                model.addRow(new Object[]{
                    sequence++,
                    borrowerInfo,
                    loanDetails,
                    nextPayment,
                    getStatusText(rs.getInt("status")),
                    "buttons",
                    rs.getInt("id")
                });
            }
            
            if (model.getRowCount() == 0) {
                model.addRow(new Object[]{1, "No loans found", "N/A", "N/A", "N/A", "N/A", -1});
            }
            
            configureTableColumns();
            
        } catch (SQLException e) {
            showDatabaseError(e);
        }
    }
    
    // Helper methods
    private String getLoanQuery() {
        return """
            SELECT ll.id, ll.ref_no, ll.amount, ll.purpose, ll.status, 
                   ll.date_created, ll.date_released, lp.penalty_rate,
                   b.firstname, b.middlename, b.lastname, b.contact_no, 
                   b.address, b.email, lt.type_name, lp.months, 
                   lp.interest_percentage
            FROM loan_list ll
            LEFT JOIN borrowers b ON ll.borrower_id = b.id
            LEFT JOIN loan_types lt ON ll.loan_type_id = lt.id
            LEFT JOIN loan_plan lp ON ll.plan_id = lp.id
            ORDER BY ll.id DESC""";
    }
    
    private String getBorrowerInfoHtml(ResultSet rs) throws SQLException {
        return String.format(
            "<html><div style='padding:8px; font-family:Arial;'>" +
            "<b>%s, %s %s</b><br/>" +
            "<small>📍 %s<br/>📞 %s<br/>✉️ %s</small></div></html>",
            rs.getString("lastname") != null ? rs.getString("lastname") : "N/A",
            rs.getString("firstname") != null ? rs.getString("firstname") : "N/A",
            rs.getString("middlename") != null ? rs.getString("middlename") : "",
            rs.getString("address") != null ? rs.getString("address") : "N/A",
            rs.getString("contact_no") != null ? rs.getString("contact_no") : "N/A",
            rs.getString("email") != null ? rs.getString("email") : "N/A"
        );
    }
    
private String getNextPaymentHtml(ResultSet rs, NumberFormat currencyFormat, SimpleDateFormat dateFormat) throws SQLException {
    int status = rs.getInt("status");
    
    switch(status) {
        case 0: return "<html><div style='padding:5px'>Waiting for approval</div></html>";
        case 1: return "<html><div style='padding:5px'>Ready for release</div></html>";
        case 4: return "<html><div style='padding:5px'>Loan denied</div></html>";
        case 3: return "<html><div style='padding:5px'>Loan fully paid</div></html>";
        
        case 2: // Released
            Timestamp releasedDate = rs.getTimestamp("date_released");
            if (releasedDate == null) return "<html>Release date missing</html>";

            // Next payment date = 30 days after release
            Calendar nextPayment = Calendar.getInstance();
            nextPayment.setTime(releasedDate);
            nextPayment.add(Calendar.DATE, 30);

            // Loan info
            double amount = rs.getDouble("amount"); // This should be principal
            int months = rs.getInt("months");
            float interestRate = rs.getFloat("interest_percentage");
            
            double totalInterest = amount * (interestRate / 100);
            double totalPayable = amount + totalInterest;
            double monthlyPayment = totalPayable / months;

            return String.format("<html>"
                + "<b>Date:</b> %s<br>"
                + "<b>Monthly amount:</b> %s<br>"
                + "<b>Penalty:</b> %s<br>"
                + "<b>Payable Amount:</b> %s"
                + "</html>",
                dateFormat.format(nextPayment.getTime()),
                currencyFormat.format(monthlyPayment),
                currencyFormat.format(0), // you can replace 0 with actual penalty logic later
                currencyFormat.format(totalPayable));

        default:
            return "<html><div style='padding:5px'>N/A</div></html>";
    }
}

    
        
    private void showDatabaseError(SQLException e) {
        JOptionPane.showMessageDialog(this, 
            "Database error: " + e.getMessage(), 
            "Error", 
            JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    
    private void configureTableColumns() {
        // Hide the ID column
        SmartlendListTable.getColumnModel().getColumn(6).setMinWidth(0);
        SmartlendListTable.getColumnModel().getColumn(6).setMaxWidth(0);
        SmartlendListTable.getColumnModel().getColumn(6).setWidth(0);
        
        // Set renderers and editors
        SmartlendListTable.getColumnModel().getColumn(5).setCellRenderer(new ButtonRenderer());
        SmartlendListTable.getColumnModel().getColumn(5).setCellEditor(new ButtonEditor(new JCheckBox()));
        
        CenteredTableCellRenderer centerRenderer = new CenteredTableCellRenderer();
        SmartlendListTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        
        StatusCellRenderer statusRenderer = new StatusCellRenderer();
        SmartlendListTable.getColumnModel().getColumn(4).setCellRenderer(statusRenderer);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        PanelContainer = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        SmartlendListTable = new javax.swing.JTable();
        LabelSmartLendList = new javax.swing.JLabel();
        ButtonCreateNewApplication = new javax.swing.JButton();
        searchFunction1 = new Function.SearchFunction();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        PanelContainer.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        SmartlendListTable.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        SmartlendListTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Number", "Lenders", "Lend Details", "Next Payment Details", "Status", "Action"
            }
        ));
        jScrollPane1.setViewportView(SmartlendListTable);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1140, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE)
                .addContainerGap())
        );

        LabelSmartLendList.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        LabelSmartLendList.setText("SmartLend List:");

        ButtonCreateNewApplication.setBackground(new java.awt.Color(0, 102, 255));
        ButtonCreateNewApplication.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        ButtonCreateNewApplication.setForeground(new java.awt.Color(255, 255, 255));
        ButtonCreateNewApplication.setText("+ Create New Application");
        ButtonCreateNewApplication.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonCreateNewApplicationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelContainerLayout = new javax.swing.GroupLayout(PanelContainer);
        PanelContainer.setLayout(PanelContainerLayout);
        PanelContainerLayout.setHorizontalGroup(
            PanelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PanelContainerLayout.createSequentialGroup()
                .addGroup(PanelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelContainerLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(LabelSmartLendList)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(searchFunction1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelContainerLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ButtonCreateNewApplication)))
                .addContainerGap())
        );
        PanelContainerLayout.setVerticalGroup(
            PanelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ButtonCreateNewApplication)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addGroup(PanelContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LabelSmartLendList, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchFunction1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(PanelContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(47, 47, 47))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(PanelContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

        
    private void ButtonCreateNewApplicationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonCreateNewApplicationActionPerformed
          Function.CreateNewApplication newLoanPanel = new Function.CreateNewApplication();
    
    // Create dialog
    JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this), "New Loan Application", true);
    dialog.setContentPane(newLoanPanel);
    dialog.setSize(650, 600);
    dialog.setLocationRelativeTo(this);
    dialog.setResizable(false);
    
    // Add property change listener to refresh data when loan is saved
    newLoanPanel.addPropertyChangeListener("loanSaved", evt1 -> {
        if ((Boolean) evt1.getNewValue()) {
            loadLoanData();
            refreshSearchConnection();
        }
    });
    
    dialog.setVisible(true);
    }//GEN-LAST:event_ButtonCreateNewApplicationActionPerformed
    
    
    public void refreshData() {
        loadLoanData();
        refreshSearchConnection();
    }
    
    public void refreshTable() {
    loadLoanData(); // Your existing method that reloads table data
}
    
 public void updateLoanStatus(int loanId, int newStatus) {
    try (Connection conn = getConnection()) {
        String sql = "UPDATE loan_list SET status = ?" + 
                    (newStatus == 2 ? ", date_released = NOW()" : "") + 
                    " WHERE id = ?";
        
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, newStatus);
        pst.setInt(2, loanId);
        pst.executeUpdate();
        loadLoanData(); // Refresh the table
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

private Date getReleaseDate(int loanId) throws SQLException {
    try (Connection conn = getConnection()) {
        PreparedStatement pst = conn.prepareStatement("SELECT date_released FROM loan_list WHERE id = ?");
        pst.setInt(1, loanId);
        ResultSet rs = pst.executeQuery();
        return rs.next() ? rs.getDate("date_released") : null;
    }
}

    // Method to get loan details by ID
    public ResultSet getLoanDetails(int loanId) {
        try {
            Connection conn = getConnection();
            String sql = """
                SELECT 
                    ll.*,
                    b.firstname, b.middlename, b.lastname, b.contact_no, b.address, b.email, b.tax_id,
                    lt.type_name, lt.description,
                    lp.months, lp.interest_percentage, lp.penalty_rate
                FROM loan_list ll
                LEFT JOIN borrowers b ON ll.borrower_id = b.id
                LEFT JOIN loan_types lt ON ll.loan_type_id = lt.id
                LEFT JOIN loan_plan lp ON ll.plan_id = lp.id
                WHERE ll.id = ?
                """;
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, loanId);
            return pst.executeQuery();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonCreateNewApplication;
    private javax.swing.JLabel LabelSmartLendList;
    private javax.swing.JPanel PanelContainer;
    private javax.swing.JTable SmartlendListTable;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private Function.SearchFunction searchFunction1;
    // End of variables declaration//GEN-END:variables
}
