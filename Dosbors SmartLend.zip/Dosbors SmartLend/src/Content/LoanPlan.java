package Content;

import Dashboard.Home;
import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.*;

public class LoanPlan extends javax.swing.JPanel {
    
    private Connection conn;
    private JButton btnSave;
    private JButton btnCancel;
    private int editingId = -1; // Track which record is being edited
    
    public LoanPlan() {
        initComponents();
        addButtonsToRoundPanel1();
        connectDatabase();
        loadTableData();
        setupButtonActions();
        setupTableStyling();
        customizeTableAppearance();
        
        // Disable hover and focus on roundPanel1
        roundPanel1.setFocusable(false);
        roundPanel1.setRequestFocusEnabled(false);
    }
    
    private void addButtonsToRoundPanel1() {
        btnSave = new JButton("Save");
        btnCancel = new JButton("Cancel");
        
        btnSave.setBackground(new Color(52, 152, 219));
        btnSave.setForeground(Color.WHITE);
        btnSave.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnSave.setFocusPainted(false);
        btnSave.setBorderPainted(false);
        btnSave.setPreferredSize(new Dimension(80, 35));
        
        btnCancel.setBackground(new Color(231, 76, 60));
        btnCancel.setForeground(Color.WHITE);
        btnCancel.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnCancel.setFocusPainted(false);
        btnCancel.setBorderPainted(false);
        btnCancel.setPreferredSize(new Dimension(80, 35));
        
        // Create button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(new Color(51, 51, 51));
        buttonPanel.add(btnSave);
        buttonPanel.add(btnCancel);
        
        // Add button panel to the bottom of roundPanel1
        GroupLayout layout = (GroupLayout) roundPanel1.getLayout();
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(LabelPlanForm)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonPanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(LabelPlanForm)
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(buttonPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }
    
    private void customizeTableAppearance() {
        JTableHeader header = jTable1.getTableHeader();
        header.setFont(new Font("SansSerif", Font.BOLD, 14));
        header.setForeground(Color.WHITE);
        header.setBackground(new Color(41, 128, 185));
        header.setPreferredSize(new Dimension(header.getPreferredSize().width, 45));
        
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setFont(new Font("SansSerif", Font.BOLD, 14));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setBackground(new Color(41, 128, 185));
        header.setDefaultRenderer(headerRenderer);
        
        jTable1.setRowHeight(40);
        jTable1.setFont(new Font("SansSerif", Font.PLAIN, 14));
        jTable1.setSelectionBackground(new Color(52, 152, 219, 100));
        jTable1.setSelectionForeground(Color.BLACK);
        jTable1.setShowGrid(true);
        jTable1.setGridColor(new Color(230, 230, 230));
        jTable1.setIntercellSpacing(new Dimension(1, 1));
    }
    
    private void setupTableStyling() {
        CenteredTableCellRenderer centerRenderer = new CenteredTableCellRenderer();
        
        for (int i = 0; i < jTable1.getColumnCount() - 1; i++) {
            jTable1.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        
        jTable1.getColumnModel().getColumn(4).setCellRenderer(new ActionButtonRenderer());
        jTable1.getColumnModel().getColumn(4).setCellEditor(new ActionButtonEditor());
    }
    
    class CenteredTableCellRenderer extends DefaultTableCellRenderer {
        public CenteredTableCellRenderer() {
            setHorizontalAlignment(JLabel.CENTER);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (isSelected) {
                setBackground(new Color(52, 152, 219, 100));
                setForeground(Color.BLACK);
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
                setForeground(Color.BLACK);
            }
            
            return this;
        }
    }
    
    class ActionButtonRenderer implements TableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            
            JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 3, 2));
            
            JButton editBtn = new JButton("Edit");
            editBtn.setBackground(new Color(52, 152, 219));
            editBtn.setForeground(Color.WHITE);
            editBtn.setFont(new Font("SansSerif", Font.PLAIN, 12));
            editBtn.setFocusPainted(false);
            editBtn.setBorderPainted(false);
            editBtn.setPreferredSize(new Dimension(65, 28));
            
            JButton deleteBtn = new JButton("Delete");
            deleteBtn.setBackground(new Color(231, 76, 60));
            deleteBtn.setForeground(Color.WHITE);
            deleteBtn.setFont(new Font("SansSerif", Font.PLAIN, 12));
            deleteBtn.setFocusPainted(false);
            deleteBtn.setBorderPainted(false);
            deleteBtn.setPreferredSize(new Dimension(75, 28));
            
            panel.add(editBtn);
            panel.add(deleteBtn);
            panel.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
            
            return panel;
        }
    }
    
    class ActionButtonEditor extends DefaultCellEditor {
        private JPanel panel;
        private int currentRow;
        
        public ActionButtonEditor() {
            super(new JCheckBox());
            setClickCountToStart(1);
            
            panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 3, 2));
            
            JButton editBtn = new JButton("Edit");
            editBtn.setBackground(new Color(52, 152, 219));
            editBtn.setForeground(Color.WHITE);
            editBtn.setFont(new Font("SansSerif", Font.PLAIN, 12));
            editBtn.setFocusPainted(false);
            editBtn.setBorderPainted(false);
            editBtn.setPreferredSize(new Dimension(65, 28));
            editBtn.addActionListener(e -> {
                editRecord(currentRow);
                fireEditingStopped();
            });
            
            JButton deleteBtn = new JButton("Delete");
            deleteBtn.setBackground(new Color(231, 76, 60));
            deleteBtn.setForeground(Color.WHITE);
            deleteBtn.setFont(new Font("SansSerif", Font.PLAIN, 12));
            deleteBtn.setFocusPainted(false);
            deleteBtn.setBorderPainted(false);
            deleteBtn.setPreferredSize(new Dimension(75, 28));
            deleteBtn.addActionListener(e -> {
                deleteRecord(currentRow);
                fireEditingStopped();
            });
            
            panel.add(editBtn);
            panel.add(deleteBtn);
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            currentRow = row;
            return panel;
        }
        
        @Override
        public Object getCellEditorValue() {
            return "";
        }
    }
    
    private void editRecord(int row) {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        // Get the actual ID from hidden column (column 5)
        editingId = (Integer) model.getValueAt(row, 5);
        jTextField1.setText(model.getValueAt(row, 1).toString());
        textField1.setText(model.getValueAt(row, 2).toString());
        textField2.setText(model.getValueAt(row, 3).toString());
        
        // Change button text to indicate editing mode
        btnSave.setText("Update");
    }
    
    private void deleteRecord(int row) {
        if (conn == null) return;
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete this record?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
                // Get the actual ID from hidden column (column 5)
                int id = (Integer) model.getValueAt(row, 5);
                
                String sql = "DELETE FROM loan_plan WHERE id = ?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setInt(1, id);
                pst.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "Record deleted successfully!");
                loadTableData();
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting record: " + e.getMessage());
            }
        }
    }
    
    private void connectDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_user_database", "root", "");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage());
        }
    }
    
    private void loadTableData() {
        if (conn == null) return;
        
        DefaultTableModel model = new DefaultTableModel(new Object[]{"Number", "Months", "Interest %", "Penalty Rate", "Action", "ID"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 4;
            }
        };
        
        try {
            String sql = "SELECT id, months, interest_percentage, penalty_rate FROM loan_plan ORDER BY id";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            int sequenceNumber = 1;
            while (rs.next()) {
                model.addRow(new Object[]{
                    sequenceNumber++, // Sequential number starting from 1
                    rs.getInt("months"),
                    rs.getFloat("interest_percentage"),
                    rs.getInt("penalty_rate"),
                    "",
                    rs.getInt("id") // Hidden ID column for database operations
                });
            }
            
            jTable1.setModel(model);
            
            // Hide the ID column
            jTable1.getColumnModel().getColumn(5).setMinWidth(0);
            jTable1.getColumnModel().getColumn(5).setMaxWidth(0);
            jTable1.getColumnModel().getColumn(5).setWidth(0);
            
            setupTableStyling();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }
    
    private void setupButtonActions() {
        btnSave.addActionListener(e -> saveLoanPlan());
        btnCancel.addActionListener(e -> clearFields());
    }
    
    private void saveLoanPlan() {
        if (conn == null) return;
        
        try {
            if (jTextField1.getText().trim().isEmpty() ||
                textField1.getText().trim().isEmpty() ||
                textField2.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields!");
                return;
            }
            
            String sql;
            PreparedStatement pst;
            
            if (editingId != -1) {
                // Update existing record
                sql = "UPDATE loan_plan SET months = ?, interest_percentage = ?, penalty_rate = ? WHERE id = ?";
                pst = conn.prepareStatement(sql);
                pst.setInt(1, Integer.parseInt(jTextField1.getText().trim()));
                pst.setFloat(2, Float.parseFloat(textField1.getText().trim()));
                pst.setInt(3, Integer.parseInt(textField2.getText().trim()));
                pst.setInt(4, editingId);
                
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Loan plan updated successfully!");
                
            } else {
                // Insert new record
                sql = "INSERT INTO loan_plan (months, interest_percentage, penalty_rate) VALUES (?, ?, ?)";
                pst = conn.prepareStatement(sql);
                pst.setInt(1, Integer.parseInt(jTextField1.getText().trim()));
                pst.setFloat(2, Float.parseFloat(textField1.getText().trim()));
                pst.setInt(3, Integer.parseInt(textField2.getText().trim()));
                
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Loan plan saved successfully!");
            }
            
            clearFields();
            loadTableData();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
this, "Database error: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers!");
        }
    }
    
    private void clearFields() {
        jTextField1.setText("");
        textField1.setText("");
        textField2.setText("");
        editingId = -1; // Reset editing mode
        btnSave.setText("Save"); // Reset button text
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        roundPanel2 = new Round.RoundPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        LabelPlan = new javax.swing.JLabel();
        roundPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        textField1 = new Function.TextField();
        textField2 = new Function.TextField();
        LabelDuePenalty = new javax.swing.JLabel();
        LabelInterest = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        LabelPlanMonths = new javax.swing.JLabel();
        LabelPlanForm = new javax.swing.JLabel();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        roundPanel2.setBackground(new java.awt.Color(255, 255, 255));
        roundPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        roundPanel2.setRound(15);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Number", "Months", "Interest %", "Penalty Rate", "Action"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        LabelPlan.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelPlan.setText("Plan");

        javax.swing.GroupLayout roundPanel2Layout = new javax.swing.GroupLayout(roundPanel2);
        roundPanel2.setLayout(roundPanel2Layout);
        roundPanel2Layout.setHorizontalGroup(
            roundPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 828, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(roundPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(LabelPlan)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundPanel2Layout.setVerticalGroup(
            roundPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundPanel2Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(LabelPlan)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46))
        );

        roundPanel1.setBackground(new java.awt.Color(0, 0, 0));
        roundPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        LabelDuePenalty.setText("Monthly Over  Due's Penalty ");

        LabelInterest.setText("Interest");

        LabelPlanMonths.setText("Plan (Months)");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textField1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(textField2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTextField1)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelDuePenalty)
                            .addComponent(LabelInterest)
                            .addComponent(LabelPlanMonths))
                        .addGap(0, 195, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addComponent(LabelPlanMonths)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(LabelInterest)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(textField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(LabelDuePenalty)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(textField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );

        LabelPlanForm.setBackground(new java.awt.Color(255, 255, 255));
        LabelPlanForm.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelPlanForm.setForeground(new java.awt.Color(255, 255, 255));
        LabelPlanForm.setText("Plan Form");

        javax.swing.GroupLayout roundPanel1Layout = new javax.swing.GroupLayout(roundPanel1);
        roundPanel1.setLayout(roundPanel1Layout);
        roundPanel1Layout.setHorizontalGroup(
            roundPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(roundPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundPanel1Layout.createSequentialGroup()
                        .addComponent(LabelPlanForm)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(roundPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(24, 24, 24))))
        );
        roundPanel1Layout.setVerticalGroup(
            roundPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(LabelPlanForm)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(roundPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addComponent(roundPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(roundPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(roundPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(432, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LabelDuePenalty;
    private javax.swing.JLabel LabelInterest;
    private javax.swing.JLabel LabelPlan;
    private javax.swing.JLabel LabelPlanForm;
    private javax.swing.JLabel LabelPlanMonths;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JPanel roundPanel1;
    private Round.RoundPanel roundPanel2;
    private Function.TextField textField1;
    private Function.TextField textField2;
    // End of variables declaration//GEN-END:variables
}
