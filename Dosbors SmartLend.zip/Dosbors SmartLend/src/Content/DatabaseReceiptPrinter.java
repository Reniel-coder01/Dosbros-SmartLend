//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.print.*;
//import java.sql.*;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//
//public class DatabaseReceiptPrinter {
//    private static final String DB_URL = "jdbc:mysql://localhost:3306/java_user_database";
//    private static final String DB_USER = "root"; // Change to your DB username
//    private static final String DB_PASS = ""; // Change to your DB password
//
//    public static void main(String[] args) {
//        try {
//            // Load MySQL JDBC Driver
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            
//            // Connect to database
//            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
//            
//            // Get the latest payment (for demo purposes)
//            String query = "SELECT p.*, b.firstname, b.middlename, b.lastname, b.contact_no, " +
//                          "b.address, b.email, b.tax_id, l.ref_no, l.purpose, lt.type_name " +
//                          "FROM payments p " +
//                          "JOIN loan_list l ON p.loan_id = l.id " +
//                          "JOIN borrowers b ON l.borrower_id = b.id " +
//                          "JOIN loan_types lt ON l.loan_type_id = lt.id " +
//                          "ORDER BY p.id DESC LIMIT 1";
//            
//            Statement stmt = conn.createStatement();
//            ResultSet rs = stmt.executeQuery(query);
//            
//            if (rs.next()) {
//                // Get data from database
//                String receiptNumber = rs.getString("reference_number");
//                Date paymentDate = rs.getTimestamp("date_created");
//                String lenderName = rs.getString("firstname") + " " + 
//                                  rs.getString("middlename") + " " + 
//                                  rs.getString("lastname");
//                String contact = rs.getString("contact_no");
//                String address = rs.getString("address");
//                String email = rs.getString("email");
//                String taxId = rs.getString("tax_id");
//                String loanAccount = rs.getString("ref_no");
//                String loanType = rs.getString("type_name");
//                String loanPurpose = rs.getString("purpose");
//                double principal = rs.getDouble("amount") * 0.64; // Example calculation
//                double interest = rs.getDouble("amount") * 0.36; // Example calculation
//                double penalty = rs.getDouble("penalty_amount");
//                double total = rs.getDouble("amount") + penalty;
//                double updatedBalance = total * 2.83; // Example calculation
//                int remainingMonths = 5; // Example value
//                
//                // Format date
//                String formattedDate = new SimpleDateFormat("MMMM d, yyyy HH:mm:ss").format(paymentDate);
//                
//                // Build receipt
//                String receipt = buildReceipt(
//                    receiptNumber, formattedDate, lenderName, contact, address, 
//                    email, taxId, loanAccount, loanType, loanPurpose, 
//                    principal, interest, penalty, total, updatedBalance, remainingMonths
//                );
//                
//                // Create and show receipt dialog
//                showReceiptDialog(receipt);
//            } else {
//                JOptionPane.showMessageDialog(null, "No payment records found", "Error", JOptionPane.ERROR_MESSAGE);
//            }
//            
//            // Close connections
//            rs.close();
//            stmt.close();
//            conn.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//        }
//    }
//    
//    private static String buildReceipt(String receiptNumber, String date, String lenderName, 
//                                     String contact, String address, String email, String taxId,
//                                     String loanAccount, String loanType, String loanPurpose,
//                                     double principal, double interest, double penalty,
//                                     double total, double updatedBalance, int remainingMonths) {
//        return String.format("""
//            ==========================================
//                      LEND PAYMENT RECEIPT
//            ==========================================
//            Receipt Number: %s
//            Date of Payment: %s
//            
//            Lender Details:
//            Name: %s
//            Contact: %s
//            Address: %s
//            Email: %s
//            Tax ID: %s
//            
//            Loan Account Number: %s
//            Loan Type: %s
//            Loan Purpose: %s
//            
//            Payment Details:
//            ------------------------------------------
//            Principal Amount: PHP %.2f
//            Interest Amount: PHP %.2f
//            Penalty Amount: PHP %.2f
//            ------------------------------------------
//            Total Amount Paid: PHP %.2f
//            
//            Updated Balance: PHP %.2f
//            Remaining Months to Pay: %d
//            ==========================================
//                      THANK YOU FOR YOUR PAYMENT
//            ==========================================
//            """, 
//            receiptNumber, date, lenderName, contact, address, email, taxId,
//            loanAccount, loanType, loanPurpose, principal, interest, penalty,
//            total, updatedBalance, remainingMonths);
//    }
//    
//    private static void showReceiptDialog(String receipt) {
//        JTextArea textArea = new JTextArea(receipt);
//        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
//        textArea.setEditable(false);
//        
//        JButton printButton = new JButton("Print Receipt");
//        printButton.addActionListener(e -> printReceipt(textArea));
//        
//        JPanel panel = new JPanel(new BorderLayout());
//        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
//        panel.add(printButton, BorderLayout.SOUTH);
//        
//        JOptionPane.showMessageDialog(null, panel, "Payment Receipt", JOptionPane.PLAIN_MESSAGE);
//    }
//    
//    private static void printReceipt(JTextArea textArea) {
//        try {
//            PrinterJob job = PrinterJob.getPrinterJob();
//            job.setJobName("Loan Payment Receipt");
//            
//            // Define printable content
//            job.setPrintable((graphics, pageFormat, pageIndex) -> {
//                if (pageIndex > 0) {
//                    return Printable.NO_SUCH_PAGE;
//                }
//                
//                Graphics2D g2d = (Graphics2D) graphics;
//                g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
//                
//                // Print the text with proper formatting
//                String[] lines = textArea.getText().split("\n");
//                int y = 50;
//                for (String line : lines) {
//                    g2d.drawString(line, 50, y);
//                    y += 15;
//                }
//                
//                return Printable.PAGE_EXISTS;
//            });
//            
//            // Show print dialog
//            if (job.printDialog()) {
//                job.print();
//            }
//        } catch (PrinterException e) {
//            JOptionPane.showMessageDialog(null, "Printing error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//        }
//    }
//}