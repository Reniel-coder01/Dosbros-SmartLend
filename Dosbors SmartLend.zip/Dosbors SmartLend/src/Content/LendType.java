package Content;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.*;

public class LendType extends javax.swing.JPanel {
    
    private Connection conn;
    private JButton btnSave;
    private JButton btnCancel;
    private int editingId = -1;
    private JTextArea textAreaDescription;
    private JScrollPane scrollPaneDescription;
    
    public LendType() {
        initComponents();
        replaceDescriptionField();
        addButtonsToForm();
        connectDatabase();
        loadTableData();
        setupButtonActions();
        setupTableStyling();
        customizeTableAppearance();
        
        // Disable hover and focus
        PanelLendTypeForm.setFocusable(false);
        PanelLendTypeForm.setRequestFocusEnabled(false);
    }
    
    private void replaceDescriptionField() {
        // Remove the original text field
        jPanelTypeDesContainer.remove(TextFieldDescription);
        
        // Create resizable text area with scroll pane
        textAreaDescription = new JTextArea(4, 20);
        textAreaDescription.setLineWrap(true);
        textAreaDescription.setWrapStyleWord(true);
        textAreaDescription.setFont(new Font("SansSerif", Font.PLAIN, 12));
        textAreaDescription.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        scrollPaneDescription = new JScrollPane(textAreaDescription);
        scrollPaneDescription.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPaneDescription.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPaneDescription.setBorder(BorderFactory.createLoweredBevelBorder());
        
        // Update the layout to include the new text area
        GroupLayout layout = (GroupLayout) jPanelTypeDesContainer.getLayout();
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(scrollPaneDescription)
                    .addComponent(TextFieldLendType)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(LabelDescription)
                            .addComponent(LabelType))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LabelType)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TextFieldLendType, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(LabelDescription)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPaneDescription, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
    }
    
    private void addButtonsToForm() {
        btnSave = new JButton("Save");
        btnCancel = new JButton("Cancel");
        
        btnSave.setBackground(new Color(52, 152, 219));
        btnSave.setForeground(Color.WHITE);
        btnSave.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnSave.setFocusPainted(false);
        btnSave.setBorderPainted(false);
        btnSave.setPreferredSize(new Dimension(80, 35));
        
        btnCancel.setBackground(new Color(231, 76, 60));
        btnCancel.setForeground(Color.WHITE);
        btnCancel.setFont(new Font("SansSerif", Font.BOLD, 12));
        btnCancel.setFocusPainted(false);
        btnCancel.setBorderPainted(false);
        btnCancel.setPreferredSize(new Dimension(80, 35));
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(new Color(0, 0, 0));
        buttonPanel.add(btnSave);
        buttonPanel.add(btnCancel);
        
        GroupLayout layout = (GroupLayout) PanelLendTypeForm.getLayout();
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(LabelTypeForm)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanelTypeDesContainer, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonPanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jPanelTypeDesContainer, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(buttonPanel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(LabelTypeForm)
                        .addGap(0, 300, Short.MAX_VALUE)))
                .addContainerGap())
        );
    }
    
    private void customizeTableAppearance() {
        JTableHeader header = TypeFormTable.getTableHeader();
        header.setFont(new Font("SansSerif", Font.BOLD, 14));
        header.setForeground(Color.WHITE);
        header.setBackground(new Color(41, 128, 185));
        header.setPreferredSize(new Dimension(header.getPreferredSize().width, 45));
        
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);
        headerRenderer.setFont(new Font("SansSerif", Font.BOLD, 14));
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setBackground(new Color(41, 128, 185));
        header.setDefaultRenderer(headerRenderer);
        
        TypeFormTable.setRowHeight(40);
        TypeFormTable.setFont(new Font("SansSerif", Font.PLAIN, 14));
        TypeFormTable.setSelectionBackground(new Color(52, 152, 219, 100));
        TypeFormTable.setSelectionForeground(Color.BLACK);
        TypeFormTable.setShowGrid(true);
        TypeFormTable.setGridColor(new Color(230, 230, 230));
        TypeFormTable.setIntercellSpacing(new Dimension(1, 1));
    }
    
    private void setupTableStyling() {
        CenteredTableCellRenderer centerRenderer = new CenteredTableCellRenderer();
        
        for (int i = 0; i < TypeFormTable.getColumnCount() - 1; i++) {
            TypeFormTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        
        TypeFormTable.getColumnModel().getColumn(3).setCellRenderer(new ActionButtonRenderer());
        TypeFormTable.getColumnModel().getColumn(3).setCellEditor(new ActionButtonEditor());
    }
    
    class CenteredTableCellRenderer extends DefaultTableCellRenderer {
        public CenteredTableCellRenderer() {
            setHorizontalAlignment(JLabel.CENTER);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            
            if (isSelected) {
                setBackground(new Color(52, 152, 219, 100));
                setForeground(Color.BLACK);
            } else {
                setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
                setForeground(Color.BLACK);
            }
            
            return this;
        }
    }
    
    class ActionButtonRenderer implements TableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            
            JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 3, 2));
            
            JButton editBtn = new JButton("Edit");
            editBtn.setBackground(new Color(52, 152, 219));
            editBtn.setForeground(Color.WHITE);
            editBtn.setFont(new Font("SansSerif", Font.PLAIN, 12));
            editBtn.setFocusPainted(false);
            editBtn.setBorderPainted(false);
            editBtn.setPreferredSize(new Dimension(65, 28));
            
            JButton deleteBtn = new JButton("Delete");
            deleteBtn.setBackground(new Color(231, 76, 60));
            deleteBtn.setForeground(Color.WHITE);
            deleteBtn.setFont(new Font("SansSerif", Font.PLAIN, 12));
            deleteBtn.setFocusPainted(false);
            deleteBtn.setBorderPainted(false);
            deleteBtn.setPreferredSize(new Dimension(75, 28));
            
            panel.add(editBtn);
            panel.add(deleteBtn);
            panel.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 248, 248));
            
            return panel;
        }
    }
    
    class ActionButtonEditor extends DefaultCellEditor {
        private JPanel panel;
        private int currentRow;
        
        public ActionButtonEditor() {
            super(new JCheckBox());
            setClickCountToStart(1);
            
            panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 3, 2));
            
            JButton editBtn = new JButton("Edit");
            editBtn.setBackground(new Color(52, 152, 219));
            editBtn.setForeground(Color.WHITE);
            editBtn.setFont(new Font("SansSerif", Font.PLAIN, 12));
            editBtn.setFocusPainted(false);
            editBtn.setBorderPainted(false);
            editBtn.setPreferredSize(new Dimension(65, 28));
            editBtn.addActionListener(e -> {
                editRecord(currentRow);
                fireEditingStopped();
            });
            
            JButton deleteBtn = new JButton("Delete");
            deleteBtn.setBackground(new Color(231, 76, 60));
            deleteBtn.setForeground(Color.WHITE);
            deleteBtn.setFont(new Font("SansSerif", Font.PLAIN, 12));
            deleteBtn.setFocusPainted(false);
            deleteBtn.setBorderPainted(false);
            deleteBtn.setPreferredSize(new Dimension(75, 28));
            deleteBtn.addActionListener(e -> {
                deleteRecord(currentRow);
                fireEditingStopped();
            });
            
            panel.add(editBtn);
            panel.add(deleteBtn);
        }
        
        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            currentRow = row;
            return panel;
        }
        
        @Override
        public Object getCellEditorValue() {
            return "";
        }
    }
    
    private void editRecord(int row) {
        DefaultTableModel model = (DefaultTableModel) TypeFormTable.getModel();
        editingId = (Integer) model.getValueAt(row, 4); // Hidden ID column
        TextFieldLendType.setText(model.getValueAt(row, 1).toString());
        textAreaDescription.setText(model.getValueAt(row, 2).toString());
        
        btnSave.setText("Update");
    }
    
    private void deleteRecord(int row) {
        if (conn == null) return;
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete this record?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                DefaultTableModel model = (DefaultTableModel) TypeFormTable.getModel();
                int id = (Integer) model.getValueAt(row, 4); // Hidden ID column
                
                String sql = "DELETE FROM loan_types WHERE id = ?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setInt(1, id);
                pst.executeUpdate();
                
                JOptionPane.showMessageDialog(this, "Record deleted successfully!");
                loadTableData();
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting record: " + e.getMessage());
            }
        }
    }
    
    private void connectDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_user_database", "root", "");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage());
        }
    }
    
    private void loadTableData() {
        if (conn == null) return;
        
        DefaultTableModel model = new DefaultTableModel(new Object[]{"Number", "Lend Type", "Description", "Action", "ID"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3;
            }
        };
        
        try {
            String sql = "SELECT id, type_name, description FROM loan_types ORDER BY id";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            int sequenceNumber = 1;
            while (rs.next()) {
                model.addRow(new Object[]{
                    sequenceNumber++,
                    rs.getString("type_name"),
                    rs.getString("description"),
                    "",
                    rs.getInt("id")
                });
            }
            
            TypeFormTable.setModel(model);
            // Hide the ID column
            TypeFormTable.getColumnModel().getColumn(4).setMinWidth(0);
            TypeFormTable.getColumnModel().getColumn(4).setMaxWidth(0);
            TypeFormTable.getColumnModel().getColumn(4).setWidth(0);
            
            setupTableStyling();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }
    
    private void setupButtonActions() {
        btnSave.addActionListener(e -> saveLendType());
        btnCancel.addActionListener(e -> clearFields());
    }
    
    private void saveLendType() {
        if (conn == null) return;
        
        try {
            if (TextFieldLendType.getText().trim().isEmpty() ||
                textAreaDescription.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields!");
                return;
            }
            
            String sql;
            PreparedStatement pst;
            
            if (editingId != -1) {
                // Update existing record
                sql = "UPDATE loan_types SET type_name = ?, description = ? WHERE id = ?";
                pst = conn.prepareStatement(sql);
                pst.setString(1, TextFieldLendType.getText().trim());
                pst.setString(2, textAreaDescription.getText().trim());
                pst.setInt(3, editingId);
                
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Lend type updated successfully!");
                
            } else {
                // Insert new record
                sql = "INSERT INTO loan_types (type_name, description) VALUES (?, ?)";
                pst = conn.prepareStatement(sql);
                pst.setString(1, TextFieldLendType.getText().trim());
                pst.setString(2, textAreaDescription.getText().trim());
                
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Lend type saved successfully!");
            }
            
            clearFields();
            loadTableData();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }
    
    private void clearFields() {
        TextFieldLendType.setText("");
        textAreaDescription.setText("");
        editingId = -1;
        btnSave.setText("Save");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel = new javax.swing.JPanel();
        TableContainer = new Round.RoundPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TypeFormTable = new javax.swing.JTable();
        PanelLendTypeForm = new javax.swing.JPanel();
        jPanelTypeDesContainer = new javax.swing.JPanel();
        LabelDescription = new javax.swing.JLabel();
        TextFieldDescription = new javax.swing.JTextField();
        LabelType = new javax.swing.JLabel();
        TextFieldLendType = new javax.swing.JTextField();
        LabelTypeForm = new javax.swing.JLabel();

        jPanel.setBackground(new java.awt.Color(255, 255, 255));

        TableContainer.setBackground(new java.awt.Color(255, 255, 255));
        TableContainer.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        TableContainer.setRound(15);

        TypeFormTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Number", "Lend Type", "Description", "Action"
            }
        ));
        jScrollPane1.setViewportView(TypeFormTable);

        javax.swing.GroupLayout TableContainerLayout = new javax.swing.GroupLayout(TableContainer);
        TableContainer.setLayout(TableContainerLayout);
        TableContainerLayout.setHorizontalGroup(
            TableContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TableContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 789, Short.MAX_VALUE)
                .addContainerGap())
        );
        TableContainerLayout.setVerticalGroup(
            TableContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TableContainerLayout.createSequentialGroup()
                .addContainerGap(48, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46))
        );

        PanelLendTypeForm.setBackground(new java.awt.Color(0, 0, 0));

        jPanelTypeDesContainer.setBackground(new java.awt.Color(255, 255, 255));

        LabelDescription.setText("Description");

        LabelType.setText("Type");

        javax.swing.GroupLayout jPanelTypeDesContainerLayout = new javax.swing.GroupLayout(jPanelTypeDesContainer);
        jPanelTypeDesContainer.setLayout(jPanelTypeDesContainerLayout);
        jPanelTypeDesContainerLayout.setHorizontalGroup(
            jPanelTypeDesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelTypeDesContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelTypeDesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextFieldDescription)
                    .addGroup(jPanelTypeDesContainerLayout.createSequentialGroup()
                        .addGroup(jPanelTypeDesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LabelDescription)
                            .addComponent(LabelType))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanelTypeDesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelTypeDesContainerLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(TextFieldLendType)
                    .addContainerGap()))
        );
        jPanelTypeDesContainerLayout.setVerticalGroup(
            jPanelTypeDesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelTypeDesContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LabelType)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 89, Short.MAX_VALUE)
                .addComponent(LabelDescription)
                .addGap(18, 18, 18)
                .addComponent(TextFieldDescription, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
            .addGroup(jPanelTypeDesContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelTypeDesContainerLayout.createSequentialGroup()
                    .addGap(31, 31, 31)
                    .addComponent(TextFieldLendType, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(150, Short.MAX_VALUE)))
        );

        LabelTypeForm.setBackground(new java.awt.Color(255, 255, 255));
        LabelTypeForm.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        LabelTypeForm.setForeground(new java.awt.Color(255, 255, 255));
        LabelTypeForm.setText("Lend Type Form");

        javax.swing.GroupLayout PanelLendTypeFormLayout = new javax.swing.GroupLayout(PanelLendTypeForm);
        PanelLendTypeForm.setLayout(PanelLendTypeFormLayout);
        PanelLendTypeFormLayout.setHorizontalGroup(
            PanelLendTypeFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelLendTypeFormLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelLendTypeFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanelTypeDesContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(PanelLendTypeFormLayout.createSequentialGroup()
                        .addComponent(LabelTypeForm)
                        .addGap(0, 300, Short.MAX_VALUE)))
                .addContainerGap())
        );
        PanelLendTypeFormLayout.setVerticalGroup(
            PanelLendTypeFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelLendTypeFormLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(LabelTypeForm)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanelTypeDesContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanelLayout = new javax.swing.GroupLayout(jPanel);
        jPanel.setLayout(jPanelLayout);
        jPanelLayout.setHorizontalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(PanelLendTypeForm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TableContainer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );
        jPanelLayout.setVerticalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(PanelLendTypeForm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(TableContainer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(388, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LabelDescription;
    private javax.swing.JLabel LabelType;
    private javax.swing.JLabel LabelTypeForm;
    private javax.swing.JPanel PanelLendTypeForm;
    private Round.RoundPanel TableContainer;
    private javax.swing.JTextField TextFieldDescription;
    private javax.swing.JTextField TextFieldLendType;
    private javax.swing.JTable TypeFormTable;
    private javax.swing.JPanel jPanel;
    private javax.swing.JPanel jPanelTypeDesContainer;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
