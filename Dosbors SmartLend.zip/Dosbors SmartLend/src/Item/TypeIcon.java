package Item;

import javax.swing.*;
import java.awt.*;

public class TypeIcon extends JPanel {
    private final JLabel iconLabel;
    private final JLabel textLabel;
    private final Icon normalIcon;
    private final Icon hoverIcon;
    
    public TypeIcon() {
        setOpaque(false);
        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
        
        // Create custom grid icons
        normalIcon = createGridIcon(Color.LIGHT_GRAY);
        hoverIcon = createGridIcon(Color.BLACK);
        
        iconLabel = new JLabel(normalIcon);
        textLabel = new JLabel("Lend Type");
        textLabel.setForeground(Color.WHITE);
        
        add(iconLabel);
        add(textLabel);
    }
    
    private Icon createGridIcon(Color color) {
        return new Icon() {
            public int getIconWidth() { return 16; }
            public int getIconHeight() { return 16; }
            
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(color);
                // Draw a 2x2 grid
                g2.drawRect(x+1, y+1, 6, 6);
                g2.drawRect(x+8, y+1, 6, 6);
                g2.drawRect(x+1, y+8, 6, 6);
                g2.drawRect(x+8, y+8, 6, 6);
                g2.dispose();
            }
        };
    }
    
    public void setHover(boolean isHover) {
        iconLabel.setIcon(isHover ? hoverIcon : normalIcon);
        textLabel.setForeground(isHover ? Color.BLACK : Color.WHITE);
        repaint();
    }
    
    public void setText(String text) {
        textLabel.setText(text);
    }
}
