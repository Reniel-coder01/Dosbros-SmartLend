package Item;

import javax.swing.*;
import java.awt.*;

public class LoanIcon extends JPanel {
    private final JLabel iconLabel;
    private final JLabel textLabel;
    private final Icon normalIcon;
    private final Icon hoverIcon;
    
    public LoanIcon() {
        setOpaque(false);
        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
        
        // Create custom loan icons
        normalIcon = createLoanIcon(Color.LIGHT_GRAY);
        hoverIcon = createLoanIcon(Color.BLACK);
        
        iconLabel = new JLabel(normalIcon);
        textLabel = new JLabel("Lend");
        textLabel.setForeground(Color.WHITE);
        
        add(iconLabel);
        add(textLabel);
    }
    
    private Icon createLoanIcon(Color color) {
        return new Icon() {
            public int getIconWidth() { return 16; }
            public int getIconHeight() { return 16; }
            
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setStroke(new BasicStroke(1.2f));
                g2.setColor(color);
                
                // Dollar bill outline (rectangle)
                g2.drawRect(x + 1, y + 3, 14, 9);
                
                // Dollar sign
                g2.drawLine(x + 8, y + 4, x + 8, y + 11); // Vertical line
                g2.drawArc(x + 6, y + 4, 4, 3, 0, 180); // Top curve
                g2.drawArc(x + 6, y + 7, 4, 3, 180, 180); // Bottom curve
                
                // Horizontal lines (bill details)
                g2.drawLine(x + 3, y + 6, x + 5, y + 6);
                g2.drawLine(x + 11, y + 6, x + 13, y + 6);
                g2.drawLine(x + 3, y + 9, x + 5, y + 9);
                g2.drawLine(x + 11, y + 9, x + 13, y + 9);
                
                g2.dispose();
            }
        };
    }
    
    public void setHover(boolean isHover) {
        iconLabel.setIcon(isHover ? hoverIcon : normalIcon);
        textLabel.setForeground(isHover ? Color.BLACK : Color.WHITE);
        repaint();
    }
    
    public void setText(String text) {
        textLabel.setText(text);
    }
}
