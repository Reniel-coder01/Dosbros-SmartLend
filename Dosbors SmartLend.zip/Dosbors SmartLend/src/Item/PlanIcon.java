package Item;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.EmptyBorder;

public class PlanIcon extends JPanel {
    private final JLabel iconLabel;
    private final JLabel textLabel;
    private final Icon normalIcon;
    private final Icon hoverIcon;
    
    public PlanIcon() {
        // Make panel transparent
        setOpaque(false);
        
        // Use BoxLayout for better text display
        setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
        
        // Create custom paper sheet icons
        normalIcon = createPaperSheetIcon(Color.LIGHT_GRAY);
        hoverIcon = createPaperSheetIcon(Color.BLACK);
        
        iconLabel = new JLabel(normalIcon);
        iconLabel.setBorder(new EmptyBorder(0, 5, 0, 5)); // Add padding
        
        // Create text label
        textLabel = new JLabel("Lend Plan");
        textLabel.setForeground(Color.WHITE);
        
        // Add components
        add(iconLabel);
        add(textLabel);
        
        // Set size
        setPreferredSize(new Dimension(150, 30));
    }
    
    private Icon createPaperSheetIcon(Color color) {
        return new Icon() {
            public int getIconWidth() { return 16; }
            public int getIconHeight() { return 16; }
            
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(color);
                
                // Draw paper sheet outline
                g2.drawRect(x+2, y+1, 12, 14);
                
                // Draw folded corner
                g2.drawLine(x+11, y+1, x+11, y+4);
                g2.drawLine(x+11, y+4, x+14, y+4);
                
                // Draw text lines
                g2.drawLine(x+4, y+6, x+12, y+6);   // Line 1
                g2.drawLine(x+4, y+8, x+12, y+8);   // Line 2
                g2.drawLine(x+4, y+10, x+12, y+10); // Line 3
                g2.drawLine(x+4, y+12, x+10, y+12); // Line 4 (shorter)
                
                g2.dispose();
            }
        };
    }
    
    public void setHover(boolean isHover) {
        iconLabel.setIcon(isHover ? hoverIcon : normalIcon);
        textLabel.setForeground(isHover ? Color.BLACK : Color.WHITE);
        repaint();
    }
    
    public void setText(String text) {
        textLabel.setText(text);
    }
}
