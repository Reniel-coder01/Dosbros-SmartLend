package Item;

import javax.swing.*;
import java.awt.*;

public class Home extends JPanel {
    private final JLabel iconLabel;
    private final JLabel textLabel;
    private final Icon normalIcon;
    private final Icon hoverIcon;
    
    public Home() {
        setOpaque(false);
        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
        
        // Create custom home icons
        normalIcon = createHomeIcon(Color.LIGHT_GRAY);
        hoverIcon = createHomeIcon(Color.BLACK);
        
        iconLabel = new JLabel(normalIcon);
        textLabel = new JLabel("Home");
        textLabel.setForeground(Color.WHITE);
        
        add(iconLabel);
        add(textLabel);
    }
    
    private Icon createHomeIcon(Color color) {
        return new Icon() {
            public int getIconWidth() { return 16; }
            public int getIconHeight() { return 16; }
            
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setStroke(new BasicStroke(1.2f));
                g2.setColor(color);
                
                // Roof (triangle)
                int[] xPoints = {x + 8, x + 1, x + 15};
                int[] yPoints = {y + 1, y + 7, y + 7};
                g2.drawPolygon(xPoints, yPoints, 3);
                
                // House body (rectangle)
                g2.drawRect(x + 3, y + 7, 10, 8);
                
                // Door
                g2.drawRect(x + 7, y + 11, 2, 4);
                
                // Window
                g2.drawRect(x + 5, y + 9, 2, 2);
                g2.drawRect(x + 9, y + 9, 2, 2);
                
                g2.dispose();
            }
        };
    }
    
    public void setHover(boolean isHover) {
        iconLabel.setIcon(isHover ? hoverIcon : normalIcon);
        textLabel.setForeground(isHover ? Color.BLACK : Color.WHITE);
        repaint();
    }
    
    public void setText(String text) {
        textLabel.setText(text);
    }
}
