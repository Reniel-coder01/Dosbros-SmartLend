package Item;

import javax.swing.*;
import java.awt.*;

public class PlanIconTest {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("PlanIcon Test");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(300, 200);
            
            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.setBackground(Color.DARK_GRAY);
            
            PlanIcon planIcon = new PlanIcon();
            
            mainPanel.add(planIcon, BorderLayout.NORTH);
            frame.add(mainPanel);
            
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
