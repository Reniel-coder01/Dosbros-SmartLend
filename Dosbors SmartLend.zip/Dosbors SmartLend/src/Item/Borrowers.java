package Item;

import javax.swing.*;
import java.awt.*;

public class Borrowers extends JPanel {
    private final JLabel iconLabel;
    private final JLabel textLabel;
    private final Icon normalIcon;
    private final Icon hoverIcon;
    
    public Borrowers() {
        setOpaque(false);
        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
        
        // Create custom payment icons
        normalIcon = createPaymentIcon(Color.LIGHT_GRAY);
        hoverIcon = createPaymentIcon(Color.BLACK);
        
        iconLabel = new JLabel(normalIcon);
        textLabel = new JLabel("Lender");
        textLabel.setForeground(Color.WHITE);
        
        add(iconLabel);
        add(textLabel);
    }
    
    private Icon createPaymentIcon(Color color) {
        return new Icon() {
            public int getIconWidth() { return 16; }
            public int getIconHeight() { return 16; }
            
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(color);
                
                // Draw dollar bill
                g2.drawRect(x+1, y+3, 14, 10);
                
                // Draw circle in the middle
                g2.drawOval(x+6, y+6, 4, 4);
                
                // Draw dollar sign
                g2.drawLine(x+8, y+5, x+8, y+11);  // vertical line
                
                // Draw horizontal lines representing bill details
                g2.drawLine(x+2, y+5, x+5, y+5);
                g2.drawLine(x+11, y+5, x+14, y+5);
                g2.drawLine(x+2, y+11, x+5, y+11);
                g2.drawLine(x+11, y+11, x+14, y+11);
                
                g2.dispose();
            }
        };
    }
    
    public void setHover(boolean isHover) {
        iconLabel.setIcon(isHover ? hoverIcon : normalIcon);
        textLabel.setForeground(isHover ? Color.BLACK : Color.WHITE);
        repaint();
    }
    
    public void setText(String text) {
        textLabel.setText(text);
    }
}
