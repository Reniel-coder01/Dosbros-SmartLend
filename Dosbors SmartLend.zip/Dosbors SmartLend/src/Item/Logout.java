package Item;

import javax.swing.*;
import java.awt.*;

public class Logout extends JPanel {
    private final JLabel iconLabel;
    private final JLabel textLabel;
    private final Icon normalIcon;
    private final Icon hoverIcon;
    
    public Logout() {
        setOpaque(false);
        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
        
        // Create custom logout icons
        normalIcon = createLogoutIcon(Color.LIGHT_GRAY);
        hoverIcon = createLogoutIcon(Color.BLACK);
        
        iconLabel = new JLabel(normalIcon);
        textLabel = new JLabel("Logout");
        textLabel.setForeground(Color.WHITE);
        
        add(iconLabel);
        add(textLabel);
    }
    
    private Icon createLogoutIcon(Color color) {
        return new Icon() {
            public int getIconWidth() { return 16; }
            public int getIconHeight() { return 16; }
            
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(color);
                
                // Draw door with arrow
                g2.drawRect(x+2, y+1, 10, 14);  // door outline
                g2.drawLine(x+8, y+8, x+14, y+8);  // arrow line
                g2.drawLine(x+12, y+5, x+14, y+8);  // arrow top
                g2.drawLine(x+12, y+11, x+14, y+8);  // arrow bottom
                
                g2.dispose();
            }
        };
    }
    
    public void setHover(boolean isHover) {
        iconLabel.setIcon(isHover ? hoverIcon : normalIcon);
        textLabel.setForeground(isHover ? Color.BLACK : Color.WHITE);
        repaint();
    }
    
    public void setText(String text) {
        textLabel.setText(text);
    }
}
