package Item;

import javax.swing.*;
import java.awt.*;

public class PaymentIcon extends JPanel {
    private final JLabel iconLabel;
    private final JLabel textLabel;
    private final Icon normalIcon;
    private final Icon hoverIcon;
    
    public PaymentIcon() {
        setOpaque(false);
        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 0));
        
        // Create custom payment icons with improved human figures
        normalIcon = createEnhancedPaymentIcon(Color.LIGHT_GRAY);
        hoverIcon = createEnhancedPaymentIcon(Color.BLACK);
        
        iconLabel = new JLabel(normalIcon);
        textLabel = new JLabel("Payment");
        textLabel.setForeground(Color.WHITE);
        
        add(iconLabel);
        add(textLabel);
    }
    
    private Icon createEnhancedPaymentIcon(Color color) {
        return new Icon() {
            public int getIconWidth() { return 16; }
            public int getIconHeight() { return 16; }
            
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setStroke(new BasicStroke(1.2f));
                g2.setColor(color);
                
                // First person (payer)
                g2.fillOval(x+1, y+2, 4, 4);  // head
                g2.drawLine(x+3, y+6, x+3, y+10);  // body
                g2.drawLine(x+3, y+7, x+1, y+9);  // left arm
                g2.drawLine(x+3, y+7, x+5, y+8);  // right arm (extended for payment)
                g2.drawLine(x+3, y+10, x+1, y+13);  // left leg
                g2.drawLine(x+3, y+10, x+4, y+13);  // right leg
                
                // Second person (recipient)
                g2.fillOval(x+11, y+2, 4, 4);  // head
                g2.drawLine(x+13, y+6, x+13, y+10);  // body
                g2.drawLine(x+13, y+7, x+11, y+8);  // left arm (extended to receive)
                g2.drawLine(x+13, y+7, x+15, y+9);  // right arm
                g2.drawLine(x+13, y+10, x+12, y+13);  // left leg
                g2.drawLine(x+13, y+10, x+15, y+13);  // right leg
                
                // Dollar/coin being exchanged
                g2.fillOval(x+7, y+7, 2, 2);  // coin
                g2.drawLine(x+8, y+6, x+8, y+10);  // dollar sign vertical
                
                // Movement lines (indicating transaction)
                g2.drawLine(x+5, y+8, x+7, y+8);  // from first person to coin
                g2.drawLine(x+9, y+8, x+11, y+8);  // from coin to second person
                
                g2.dispose();
            }
        };
    }
    
    public void setHover(boolean isHover) {
        iconLabel.setIcon(isHover ? hoverIcon : normalIcon);
        textLabel.setForeground(isHover ? Color.BLACK : Color.WHITE);
        repaint();
    }
    
    public void setText(String text) {
        textLabel.setText(text);
    }
}
