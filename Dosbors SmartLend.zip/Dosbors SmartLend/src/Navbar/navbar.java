package Navbar;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class navbar extends JPanel {
    private Color primaryColor = new Color(41, 128, 185); // A nice blue color
    private Color textColor = Color.WHITE;
    private Font brandFont = new Font("Arial", Font.BOLD, 18);
    private Font menuFont = new Font("Arial", Font.PLAIN, 14);

    private JLabel brandLabel;
    private JButton hamburgerButton;
    private JPopupMenu popupMenu;

    // Define an interface for menu item selection callbacks
    public interface MenuSelectionListener {
        void onMenuSelected(String menuName);
    }

    private MenuSelectionListener menuSelectionListener;

    public void setMenuSelectionListener(MenuSelectionListener listener) {
        this.menuSelectionListener = listener;
    }

    public navbar() {
        setLayout(new BorderLayout());
        setBackground(primaryColor);
        setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Create brand panel (left side)
        JPanel brandPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        brandPanel.setOpaque(false);
        brandLabel = new JLabel("Dosbros SmartLend");
        brandLabel.setFont(brandFont);
        brandLabel.setForeground(textColor);
        brandPanel.add(brandLabel);

        // Create hamburger button (right side) with custom painting to draw three lines
        hamburgerButton = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(textColor);
                int width = getWidth();
                int height = getHeight();
                int lineWidth = width / 2;
                int lineHeight = 3;
                int space = 6;
                int x = (width - lineWidth) / 2;
                int yStart = (height - (lineHeight * 3 + space * 2)) / 2;

                // Draw three horizontal lines
                for (int i = 0; i < 3; i++) {
                    g2.fillRect(x, yStart + i * (lineHeight + space), lineWidth, lineHeight);
                }
                g2.dispose();
            }

            @Override
            public Dimension getPreferredSize() {
                return new Dimension(40, 30);
            }
        };

        hamburgerButton.setOpaque(false);
        hamburgerButton.setContentAreaFilled(false);
        hamburgerButton.setBorder(BorderFactory.createEmptyBorder());
        hamburgerButton.setFocusPainted(false);
        hamburgerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                popupMenu.show(hamburgerButton, 0, hamburgerButton.getHeight());
            }
        });

        // Create popup menu for additional functions
        popupMenu = new JPopupMenu();
        JMenuItem recordsItem = new JMenuItem("Records");
        JMenuItem ledgerItem = new JMenuItem("Ledger");

        // Add action listeners for menu items, notify listener if set
        recordsItem.addActionListener(e -> {
            if (menuSelectionListener != null) {
                menuSelectionListener.onMenuSelected("Records");
            }
            showRecordsDialog();
        });

        ledgerItem.addActionListener(e -> {
            if (menuSelectionListener != null) {
                menuSelectionListener.onMenuSelected("Ledger");
            }
            showLedgerDialog();
        });

        popupMenu.add(recordsItem);
        popupMenu.add(ledgerItem);

        // Add components to the navbar
        add(brandPanel, BorderLayout.WEST);
        add(hamburgerButton, BorderLayout.EAST);
    }

    private void showRecordsDialog() {
        // Create a custom dialog
        JDialog recordsDialog = new JDialog();
        recordsDialog.setTitle("Records");
        recordsDialog.setModal(true);
        recordsDialog.setSize(600, 400);
        recordsDialog.setLocationRelativeTo(this); // Center relative to the navbar

        // Create the RecordsPanel content
        JPanel recordsPanel = new Hamburger.RecordsPanel(); // Ensure this class exists!
        recordsDialog.add(recordsPanel);

        // Add close button at the bottom
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> recordsDialog.dispose());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(closeButton);

        recordsDialog.add(buttonPanel, BorderLayout.SOUTH);
        recordsDialog.setVisible(true);
    }

    private void showLedgerDialog() {
        // Create a custom dialog
        JDialog ledgerDialog = new JDialog();
        ledgerDialog.setTitle("Ledger");
        ledgerDialog.setModal(true);
        ledgerDialog.setSize(900, 600);
        ledgerDialog.setLocationRelativeTo(this); // Center relative to the navbar

        // Create the Ledger content
        JPanel ledgerPanel = new Hamburger.Ledger(); // Ensure this class exists!
        ledgerDialog.add(ledgerPanel);

        // Add close button at the bottom
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> ledgerDialog.dispose());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(closeButton);

        ledgerDialog.add(buttonPanel, BorderLayout.SOUTH);
        ledgerDialog.setVisible(true);
    }
}